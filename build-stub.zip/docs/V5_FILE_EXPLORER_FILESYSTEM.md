name: SentinelOS build
on:
  push:
    branches:
      - main
      - gpu-bootvid-initialization
  pull_request:
    branches:
      - main
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Install build dependencies
        run: |
          sudo apt-get update
          sudo apt-get install -y clang lld llvm qemu-utils qemu-system-x86 ovmf dosfstools e2fsprogs mtools
      - name: Fetch EDK2 headers
        run: git clone --depth 1 https://github.com/tianocore/edk2.git "$RUNNER_TEMP/edk2"
      - name: Test File Explorer filesystem contract
        run: bash tests/fileexplorer_filesystem_contract_test.sh
      - name: Test File Explorer navigation contract
        run: bash tests/fileexplorer_navigation_test.sh
      - name: Test File Explorer file-operation contract
        run: bash tests/fileexplorer_operations_test.sh
      - name: Test CPU Vulkan runtime subset
        run: |
          clang -std=c11 -Wall -Wextra -Wno-unused-function -Wno-ignored-attributes -fdeclspec -Iuser tests/vulkan_test.c -o "$RUNNER_TEMP/vulkan-test"
          "$RUNNER_TEMP/vulkan-test"
      - name: Test software 3D renderer
        run: |
          clang -std=c11 -Wall -Wextra -Iuser user/soft3d.c tests/soft3d_test.c -o "$RUNNER_TEMP/soft3d-test"
          "$RUNNER_TEMP/soft3d-test"
      - name: Build SentinelOS
        run: EDK2="$RUNNER_TEMP/edk2" JOBS="$(nproc)" bash ./scripts/build.sh
      - name: Validate compatibility DLL exports and packaging
        run: bash tests/compatibility_exports_test.sh build/rootfs
      - name: Boot smoke test with VirtIO-VGA
        shell: bash
        run: |
          set +e
          timeout 45s env SENTINELOS_DISPLAY=vnc bash ./scripts/run.sh > "$RUNNER_TEMP/sentinel-qemu.log" 2>&1
          rc=$?
          set -e
          if [[ "$rc" -ne 0 && "$rc" -ne 124 ]]; then
            cat "$RUNNER_TEMP/sentinel-qemu.log"
            exit "$rc"
          fi
          if ! grep -Eq 'gfx: VirtIO-GPU 2D scanout active|gfx: using firmware framebuffer fallback' "$RUNNER_TEMP/sentinel-qemu.log"; then
            echo "Graphics initialization did not report a working backend."
            cat "$RUNNER_TEMP/sentinel-qemu.log"
            exit 1
          fi
          if ! grep -Eq 'bootvid: sentlogon\\.exe created|bootvid: splash complete; launching sentlogon' "$RUNNER_TEMP/sentinel-qemu.log"; then
            echo "bootvid.exe did not finish and launch sentlogon.exe."
            cat "$RUNNER_TEMP/sentinel-qemu.log"
            exit 1
          fi
