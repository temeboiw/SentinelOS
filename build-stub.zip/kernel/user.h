#pragma once
#include <stdint.h>
#include "serial.h"
#include "cpu.h"
#include "vmm.h"
#include "pmm.h"
#include "heap.h"
#include "bootinfo.h"
#include "ps2.h"
#include "ext4k.h"
#include "ntfsk.h"
#include "virtio_input.h"
#include "uthread.h"
#include "wm.h"
#include "ntabi.h"
#include "gfx.h"
#include "sha256.h"

#define SYS_NtTerminateProcess      0
#define SYS_NtWriteFile             1
#define SYS_NtGetCurrentProcessId   2
#define SYS_NtAllocateVirtualMemory 3
#define SYS_NtCreateProcess         4
#define SYS_NtOpenFile              5
#define SYS_NtReadFile              6
#define SYS_NtQueryDirectoryFile    7
#define SYS_NtMapFramebuffer        8
#define SYS_NtGetProcAddress        9
#define SYS_NtGetInput              10
#define SYS_NtShutdown              11
#define SYS_NtSetCurrentDirectory   12
#define SYS_NtCreateThread          13
#define SYS_NtWaitForSingleObject   14
#define SYS_WmRegister              15
#define SYS_WmSetMin                16
#define SYS_WmUnregister            17
#define SYS_WmQuery                 18
#define SYS_WmRestore               19
#define SYS_WmSetRect                20
#define SYS_NtYield                  21
#define SYS_WmGetDirty               53
#define SYS_WmCursor                54
#define SYS_NtGetSystemTime           23
#define SYS_NtGetTickCount             24
#define SYS_NtFreeVirtualMemory        27
#define SYS_NtProtectVirtualMemory     28
#define SYS_NtQueryVirtualMemory       29
#define SYS_NtQueryFileMetadata        30
#define SYS_NtQueryVolumeMetadata       31
#define SYS_NtInitializeGraphics        32
#define SYS_NtFlushGraphics              33
#define SYS_NtSubmit3D                    34
#define SYS_NtPresent3D                   35
#define SYS_NtUploadVirGLBuffer            36
#define SYS_NtQueryInstallerDisk            60
#define SYS_NtInstallerDiskIo               61
#define SYS_NtReadInstallerPayload          62
#define SYS_NtQueryInstallerPayload         63
#define SYS_NtVerifyInstallerPayload        64
#define SYS_NtInstallerInstallImage         65
#define SYS_NtGetGameKeyState               38
#define SYS_NtGetGameMouseDelta              39
#define SYS_NtLoadLibrary                    43
#define SYS_NtNetworkInfo 49
#define SYS_NtPing 50
#define SYS_NtCreateOutputFile 51
#define SYS_NtWriteOutputFile 52
typedef struct { uint32_t ip,mask,gateway,dns; uint32_t dhcp_state,link_up; uint8_t mac[6]; uint16_t reserved; } NT_NETWORK_INFO;
typedef struct { uint64_t sectors; uint32_t sector_size,present,index; char name[32]; } InstallerDiskInfo;

#define UP_MAX 8
#define USER_IMAGE_MAX (UP_MAX * BOOT_MAX_MODULES)
#define USER_IMAGE_PAGE 0x1000ULL
#define USER_VM_ALLOCATION_MAX 64
typedef struct { KPROCESS *process; uint64_t base,size; uint32_t allocation_protect; int used; } UserVmAllocation;
static UserVmAllocation user_vm_allocations[USER_VM_ALLOCATION_MAX];
static void user_vm_forget_process(KPROCESS *proc) {
    if(!proc)return;
    for(int i=0;i<USER_VM_ALLOCATION_MAX;i++)if(user_vm_allocations[i].used&&user_vm_allocations[i].process==proc) {
        user_vm_allocations[i].used=0;user_vm_allocations[i].process=0;user_vm_allocations[i].base=0;user_vm_allocations[i].size=0;user_vm_allocations[i].allocation_protect=0;
    }
}
static int user_vm_set_page_writable(KPROCESS *proc,uint64_t va,int writable) {
    if(!proc||va<0x10000ULL||va>=0x0000800000000000ULL||(va&0xFFFULL))return 0;
    uint64_t *root=PHYS_TO_VIRT(proc->DirectoryTableBase&PTE_ADDR);
    uint64_t e4=root[(va>>39)&511];if(!(e4&PTE_P)||!(e4&PTE_U))return 0;
    uint64_t *pdpt=PHYS_TO_VIRT(e4&PTE_ADDR);uint64_t e3=pdpt[(va>>30)&511];
    if(!(e3&PTE_P)||!(e3&PTE_U)||(e3&PTE_PS))return 0;
    uint64_t *pd=PHYS_TO_VIRT(e3&PTE_ADDR);uint64_t e2=pd[(va>>21)&511];
    if(!(e2&PTE_P)||!(e2&PTE_U)||(e2&PTE_PS))return 0;
    uint64_t *pt=PHYS_TO_VIRT(e2&PTE_ADDR);unsigned int idx=(unsigned int)((va>>12)&511);uint64_t e=pt[idx];
    if(!(e&PTE_P)||!(e&PTE_U)||!(e&PTE_OWNED))return 0;
    pt[idx]=writable?(e|PTE_RW):(e&~PTE_RW);
    if(MmCurrentProcess==proc)__asm__ volatile("invlpg (%0)"::"r"(va):"memory");
    return 1;
}

static uint8_t user_kstack[16 * 1024] __attribute__((aligned(16)));
static uint64_t user_saved_ksp, user_saved_rip;
static BootInfo *user_bootinfo;
static KPROCESS *user_pending;
static uint64_t user_pending_entry;

typedef struct {
    KPROCESS *proc;
    uint64_t entry;
    uint64_t rip, rsp, rflags, rax;
    int alive;
    int fresh;
    int parent;
    int system_app;
    char image_name[64];
    uint64_t gpr[14];
} UserProc;

/* Minimal x64 thread environment used by Windows startup code. */
static int user_setup_teb(KPROCESS *proc, uint64_t stack_lo, uint64_t stack_top) {
    if (!proc) return 0;
    uint64_t teb_pa = pmm_alloc_zeroed();
    uint64_t peb_pa = pmm_alloc_zeroed();
    if (!teb_pa || !peb_pa) {
        if (teb_pa) pmm_free(teb_pa);
        if (peb_pa) pmm_free(peb_pa);
        return 0;
    }
    map_4k_in(proc->Pml4, USER_TEB_BASE, teb_pa, PTE_U | PTE_RW | PTE_OWNED);
    map_4k_in(proc->Pml4, USER_PEB_BASE, peb_pa, PTE_U | PTE_RW | PTE_OWNED);
    uint64_t *teb = (uint64_t *)(uintptr_t)PHYS_TO_VIRT(teb_pa);
    teb[1] = stack_top;
    teb[2] = stack_lo;
    teb[6] = USER_TEB_BASE;
    teb[12] = USER_PEB_BASE;
    return 1;
}

typedef struct {
    uint32_t pid, parent_pid, state, reserved;
    char image_name[64];
} UserProcessSnapshot;

static UserProc up_tab[UP_MAX];
static int up_n;
static int up_cur = -1;


/* Kernel-owned crash queue. The faulting process is already terminated before
 * the shell receives this record; no code in the failed image handles it. */
typedef struct {
    uint32_t pid;
    uint32_t reserved;
    uint64_t vector, rip, error, cr2;
    char image_name[64];
    char exception_name[32];
} UserApplicationError;
#define USER_APP_ERROR_QUEUE_SIZE 8
static UserApplicationError user_app_errors[USER_APP_ERROR_QUEUE_SIZE];
static unsigned int user_app_error_head, user_app_error_count;

static void user_app_error_push(const UserApplicationError *event) {
    if (!event) return;
    unsigned int at;
    if (user_app_error_count == USER_APP_ERROR_QUEUE_SIZE) {
        /* Preserve the newest failures if the shell was absent for a while. */
        user_app_error_head = (user_app_error_head + 1u) % USER_APP_ERROR_QUEUE_SIZE;
        at = (user_app_error_head + user_app_error_count - 1u) % USER_APP_ERROR_QUEUE_SIZE;
    } else {
        at = (user_app_error_head + user_app_error_count) % USER_APP_ERROR_QUEUE_SIZE;
        user_app_error_count++;
    }
    user_app_errors[at] = *event;
}

static void up_set_image_name(UserProc *u, const char *name) {
    if (!u) return;
    unsigned int i = 0;
    if (name) while (name[i] && i < sizeof(u->image_name) - 1) {
        u->image_name[i] = name[i];
        i++;
    }
    u->image_name[i] = 0;
}

/*
 * Each process/module pair has its own physical image allocation.
 * BootModule is shared boot metadata and must never be modified by
 * user image relocation or import resolution.
 */
typedef struct {
    KPROCESS *proc;
    BootModule *source;
    uint64_t phys;
    uint64_t base;
    uint64_t entry;
    uint64_t size;
    int resolving;
    int resolved;
    int import_failed;
} UserImage;


static UserImage user_images[USER_IMAGE_MAX];

typedef struct {
    BootModule module;
    KPROCESS *owner;
    uint64_t source_phys;
    uint64_t source_pages;
    char image_path[224];
    /* Full requested basename; BootModule.name is only 32 bytes and truncates
       API-set names, which otherwise defeats dependency-cache comparisons. */
    char dependency_name[160];
    int used;
} UserDiskModule;
#define USER_DISK_MODULE_MAX 64
static UserDiskModule user_disk_modules[USER_DISK_MODULE_MAX];


static uint64_t user_fb_base;
static uint32_t user_fb_w, user_fb_h, user_fb_pitch;
static int fb_map_logged;

/* ------------------------------------------------------------ scheduler */

static void up_snap(Frame *f, UserProc *u) {
    u->gpr[0]  = f->r15;
    u->gpr[1]  = f->r14;
    u->gpr[2]  = f->r13;
    u->gpr[3]  = f->r12;
    u->gpr[4]  = f->r11;
    u->gpr[5]  = f->r10;
    u->gpr[6]  = f->r9;
    u->gpr[7]  = f->r8;
    u->gpr[8]  = f->rbp;
    u->gpr[9]  = f->rdi;
    u->gpr[10] = f->rsi;
    u->gpr[11] = f->rdx;
    u->gpr[12] = f->rcx;
    u->gpr[13] = f->rbx;
}

static void up_restore_gpr(Frame *f, const UserProc *u) {
    f->r15 = u->gpr[0];
    f->r14 = u->gpr[1];
    f->r13 = u->gpr[2];
    f->r12 = u->gpr[3];
    f->r11 = u->gpr[4];
    f->r10 = u->gpr[5];
    f->r9  = u->gpr[6];
    f->r8  = u->gpr[7];
    f->rbp = u->gpr[8];
    f->rdi = u->gpr[9];
    f->rsi = u->gpr[10];
    f->rdx = u->gpr[11];
    f->rcx = u->gpr[12];
    f->rbx = u->gpr[13];
}

static void up_clear_gpr(Frame *f) {
    f->r15 = f->r14 = f->r13 = f->r12 = f->r11 = f->r10 = 0;
    f->r9 = f->r8 = f->rbp = f->rdi = f->rsi = f->rdx = f->rcx = f->rbx = 0;
}

static void up_save(Frame *f, int idx) {
    if (idx < 0 || idx >= UP_MAX || !up_tab[idx].alive) return;

    up_tab[idx].rip = f->rip;
    up_tab[idx].rsp = f->rsp;
    up_tab[idx].rflags = f->rflags;
    up_tab[idx].rax = f->rax;
    up_snap(f, &up_tab[idx]);
}

static void up_save_full(Frame *f, int idx) {
    if (idx < 0 || idx >= UP_MAX || !up_tab[idx].alive) return;

    up_tab[idx].rip = f->rip;
    up_tab[idx].rsp = f->rsp;
    up_tab[idx].rflags = f->rflags;
    up_tab[idx].rax = f->rax;
    up_snap(f, &up_tab[idx]);
}

static void up_load(Frame *f, int idx) {
    UserProc *u = &up_tab[idx];
    if (!u->alive || !u->proc) return;

    if (ki_current) ki_current->Process = u->proc;
    MmSwitchToProcess(u->proc);
    cpu_set_user_gs_base(USER_TEB_BASE);

    f->cs = USER_CS;
    f->ss = USER_DS;

    if (u->fresh || u->rip < 0x10000) {
        f->rip = u->entry ? u->entry : u->rip;
        f->rsp = USER_STACK_TOP - sizeof(uint64_t);
        f->rflags = 0x202;
        f->rax = 0;
        up_clear_gpr(f);
        u->fresh = 0;
    } else {
        f->rip = u->rip;
        f->rsp = u->rsp;
        f->rflags = u->rflags ? u->rflags : 0x202;
        f->rax = u->rax;
        up_restore_gpr(f, u);
    }

    up_cur = idx;
}

static int up_find_proc(KPROCESS *p) {
    for (int i = 0; i < UP_MAX; i++) {
        if (up_tab[i].alive && up_tab[i].proc == p)
            return i;
    }
    return -1;
}

static int up_pick_next(void) {
    int start = (up_cur < 0) ? 0 : up_cur;

    for (int k = 1; k <= UP_MAX; k++) {
        int i = (start + k) % UP_MAX;

        if (!up_tab[i].alive || !up_tab[i].proc)
            continue;

        int has_live_child = 0;

        for (int j = 0; j < UP_MAX; j++) {
            if (up_tab[j].alive && up_tab[j].proc &&
                up_tab[j].parent == i) {
                has_live_child = 1;
                break;
            }
        }

        if (!has_live_child)
            return i;
    }

    return -1;
}

/* ------------------------------------------------------------ PE helpers */

/* System images are explicitly trusted session/boot components.
 * Ordinary user applications cannot create these processes. */
/* Return the final path component so protected image names cannot be
 * bypassed by supplying an absolute or mixed-separator path. */
static const char *PspImageBaseName(const char *name) {
    if (!name) return "";
    const char *base = name;
    for (const char *p = name; *p; p++)
        if (*p == '\\' || *p == '/') base = p + 1;
    return base;
}

/* Explicit paths into the system image directory are never executable via
 * NtCreateProcess. Trusted boot components launch permitted system processes
 * by basename, while File Explorer cannot execute files by browsing System32.
 * Match path components case-insensitively and accept either separator. */
static int PspIsExplicitSystemPath(const char *name) {
    if (!name) return 0;
    const char *p = name;
    while (*p) {
        while (*p == '\\' || *p == '/' || *p == ':' ) p++;
        const char *start = p;
        while (*p && *p != '\\' && *p != '/' && *p != ':') p++;
        size_t len = (size_t)(p - start);
        if (len == 7) {
            static const char system32[] = "system32";
            size_t i = 0;
            for (; i < len; i++) {
                char ch = start[i];
                if (ch >= 'A' && ch <= 'Z') ch = (char)(ch + ('a' - 'A'));
                if (ch != system32[i]) break;
            }
            if (i == len) return 1;
        }
        if (!*p) break;
    }
    return 0;
}

static int PspIsSystemAppName(const char *name) {
    static const char *const names[] = {
        "smss.exe", "bootvid.exe", "sentlogon.exe",
        "instlr.exe", "screen.exe"
    };
    name = PspImageBaseName(name);
    if (!*name) return 0;
    for (unsigned int i = 0; i < sizeof(names) / sizeof(names[0]); i++) {
        const char *a = name;
        const char *b = names[i];
        int equal = 1;
        while (*a || *b) {
            char ca = *a, cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca = (char)(ca + ('a' - 'A'));
            if (cb >= 'A' && cb <= 'Z') cb = (char)(cb + ('a' - 'A'));
            if (ca != cb) {
                equal = 0;
                break;
            }
            if (*a) a++;
            if (*b) b++;
        }
        if (equal) return 1;
    }
    return 0;
}

/* Protected launch targets include native boot components and the
 * Win32 desktop shell. Keep this separate from PspIsSystemAppName: the latter
 * also determines PE subsystem policy, and explorer.exe is a Win32 image. */
static int PspIsProtectedLaunchName(const char *name) {
    if (PspIsSystemAppName(name)) return 1;
    name = PspImageBaseName(name);
    static const char target[] = "explorer.exe";
    for (size_t i = 0; i < sizeof(target); i++) {
        char a = name[i], b = target[i];
        if (a >= 'A' && a <= 'Z') a = (char)(a + ('a' - 'A'));
        if (a != b) return 0;
        if (!b) return 1;
    }
    return 0;
}

static int PspIsSystemProcess(KPROCESS *proc) {
    int idx = up_find_proc(proc);
    return idx >= 0 && up_tab[idx].alive && up_tab[idx].system_app;
}

static int PspIsInstallerProcess(KPROCESS *proc) {
    int idx=up_find_proc(proc);
    if(idx<0||!up_tab[idx].alive||!up_tab[idx].system_app)return 0;
    const char *name=PspImageBaseName(up_tab[idx].image_name);
    static const char expected[]="instlr.exe";
    for(unsigned i=0;i<sizeof(expected);i++) {
        char c=name[i]; if(c>='A'&&c<='Z')c=(char)(c+('a'-'A'));
        if(c!=expected[i])return 0;
    }
    return 1;
}

static int pe_is_image(const uint8_t *image, uint64_t size) {
    if (!image || size < 0x40) return 0;
    if (image[0] != 'M' || image[1] != 'Z') return 0;

    int32_t lfanew = *(const int32_t *)(image + 0x3C);
    if (lfanew < 0 || (uint64_t)lfanew + 4 + 20 + 2 > size)
        return 0;

    if (*(const uint32_t *)(image + lfanew) != 0x00004550)
        return 0;

    const uint8_t *opt = image + lfanew + 4 + 20;
    return *(const uint16_t *)opt == 0x20B;
}

/* Safely read the PE32+ Optional Header subsystem field. */
static int pe_get_subsystem(const uint8_t *image, uint64_t size) {
    if (!image || size < 0x40 || image[0] != 'M' || image[1] != 'Z')
        return -1;
    int32_t lfanew = *(const int32_t *)(image + 0x3C);
    if (lfanew < 0 || (uint64_t)lfanew > size ||
        size - (uint64_t)lfanew < 24)
        return -1;
    const uint8_t *nt = image + lfanew;
    if (*(const uint32_t *)nt != 0x00004550)
        return -1;
    uint16_t opt_size = *(const uint16_t *)(nt + 20);
    uint64_t opt_off = (uint64_t)lfanew + 24;
    if (opt_size < 70 || opt_off > size || opt_size > size - opt_off)
        return -1;
    const uint8_t *opt = image + opt_off;
    if (*(const uint16_t *)opt != 0x20B)
        return -1;
    return (int)*(const uint16_t *)(opt + 68);
}

static uint8_t *PspImageBytes(UserImage *image) {
    if (!image || !image->phys) return 0;
    return (uint8_t *)(HHDM_BASE + image->phys);
}

static UserImage *PspGetUserImage(KPROCESS *proc, BootModule *mod) {
    if (!proc || !mod) return 0;

    for (int i = 0; i < USER_IMAGE_MAX; i++) {
        if (user_images[i].proc == proc &&
            user_images[i].source == mod &&
            user_images[i].phys) {
            return &user_images[i];
        }
    }

    return 0;
}

static void PspForgetUserImages(KPROCESS *proc) {
    if (!proc) return;
    for (int i = 0; i < USER_IMAGE_MAX; i++) {
        if (user_images[i].proc != proc) continue;
        user_images[i].proc = 0;
        user_images[i].source = 0;
        user_images[i].phys = 0;
        user_images[i].base = 0;
        user_images[i].entry = 0;
        user_images[i].size = 0;
        user_images[i].resolving = 0;
        user_images[i].resolved = 0;
    }
}

/*
 * Apply PE base relocations to the private copy only.
 * The source BootModule bytes are never changed.
 */
static int pe_apply_relocs(uint8_t *image, uint64_t size, int64_t delta) {
    if (!delta) return 1;
    if (!pe_is_image(image, size)) return 0;

    int32_t lfanew = *(int32_t *)(image + 0x3C);
    uint8_t *nt = image + lfanew;
    uint16_t opt_size = *(uint16_t *)(nt + 20);
    uint64_t opt_off = (uint64_t)lfanew + 24;
    if (opt_size < 112 + 6 * 8 || opt_off > size || opt_size > size - opt_off)
        return 0;
    uint8_t *opt = image + opt_off;
    uint32_t reloc_rva = *(uint32_t *)(opt + 112 + 5 * 8);
    uint32_t reloc_sz  = *(uint32_t *)(opt + 112 + 5 * 8 + 4);
    if (!reloc_rva || !reloc_sz || reloc_rva >= size || reloc_sz > size - reloc_rva)
        return 0;

    /* Validate the entire directory before changing any image bytes. PE32+
       AMD64 images use DIR64 relocations; silently skipping other types can
       leave a partially relocated executable that appears loadable. */
    uint64_t pos = reloc_rva, end = (uint64_t)reloc_rva + reloc_sz;
    while (pos < end) {
        if (end - pos < 8) return 0;
        uint32_t page_rva = *(uint32_t *)(image + pos);
        uint32_t block_sz = *(uint32_t *)(image + pos + 4);
        if ((page_rva & 0xFFF) || page_rva >= size || block_sz < 8 ||
            (block_sz & 1) || block_sz > end - pos) return 0;
        uint32_t count = (block_sz - 8) / 2;
        uint16_t *entries = (uint16_t *)(image + pos + 8);
        for (uint32_t i = 0; i < count; i++) {
            uint16_t type = entries[i] >> 12;
            uint64_t target = (uint64_t)page_rva + (entries[i] & 0xFFF);
            if (type == 0) continue;
            if (type != 10 || target > size || sizeof(uint64_t) > size - target)
                return 0;
        }
        pos += block_sz;
    }

    pos = reloc_rva;
    while (pos < end) {
        uint32_t block_sz = *(uint32_t *)(image + pos + 4);
        uint32_t count = (block_sz - 8) / 2;
        uint32_t page_rva = *(uint32_t *)(image + pos);
        uint16_t *entries = (uint16_t *)(image + pos + 8);
        for (uint32_t i = 0; i < count; i++) {
            if ((entries[i] >> 12) == 10) {
                uint64_t target = (uint64_t)page_rva + (entries[i] & 0xFFF);
                *(uint64_t *)(image + target) += (uint64_t)delta;
            }
        }
        pos += block_sz;
    }
    return 1;
}

static BootModule *PspFindModule(BootInfo *bi, const char *name) {
    if (!bi || !name) return 0;

    for (uint32_t i = 0; i < bi->module_count && i < BOOT_MAX_MODULES; i++) {
        const char *n = bi->modules[i].name;
        int match = 1;

        for (int k = 0; name[k] || n[k]; k++) {
            char a = name[k];
            char b = n[k];

            if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
            if (b >= 'A' && b <= 'Z') b = (char)(b + 32);

            if (a != b) {
                match = 0;
                break;
            }
        }

        if (match) return &bi->modules[i];
    }

    return 0;
}

/*
 * Map a private image for this process.
 *
 * IMPORTANT: call this while the system/kernel address space is active,
 * because pmm_alloc_n() returns physical addresses and map_4k_in() relies
 * on the current address space for page-table access.
 */
static int PspMapUserImage(KPROCESS *proc, BootModule *mod) {
    if (!proc || !mod || !mod->phys || !mod->size)
        return -1;

    UserImage *existing = PspGetUserImage(proc, mod);
    if (existing)
        return 0;

    uint64_t size = mod->size;
    if (size > UINT64_MAX - (USER_IMAGE_PAGE - 1))
        return -1;

    uint64_t rounded = (size + USER_IMAGE_PAGE - 1) & ~(USER_IMAGE_PAGE - 1);
    uint64_t pages = rounded / USER_IMAGE_PAGE;
    uint64_t base = mod->base ? mod->base : 0x40000000ULL;
    uint64_t preferred_base = 0;
    int relocatable = 0;

    /*
     * Boot DLLs can share the same recorded/default base. If no explicit
     * base is supplied, use the PE ImageBase. When that range is occupied,
     * move the image only if its PE has a bounded base-relocation directory.
     */
    if (pe_is_image((const uint8_t *)(HHDM_BASE + mod->phys), size)) {
        const uint8_t *raw = (const uint8_t *)(HHDM_BASE + mod->phys);
        int32_t peoff = *(const int32_t *)(raw + 0x3C);
        const uint8_t *opt = raw + peoff + 4 + 20;
        preferred_base = *(const uint64_t *)(opt + 24);
        uint32_t reloc_rva = *(const uint32_t *)(opt + 112 + 5 * 8);
        uint32_t reloc_size = *(const uint32_t *)(opt + 112 + 5 * 8 + 4);
        relocatable = reloc_rva && reloc_size &&
                      reloc_rva < size && reloc_size <= size - reloc_rva;
        if (!mod->base && preferred_base) base = preferred_base;
    }

    if (!pages || (base & (USER_IMAGE_PAGE - 1)) ||
        base < 0x10000ULL || base >= 0x0000800000000000ULL ||
        rounded > 0x0000800000000000ULL - base) {
        DbgPrint("user: invalid image range for %s\n", mod->name);
        return -1;
    }

    if (!MmUserRangeUnmapped(proc, base, rounded)) {
        if (!relocatable) {
            DbgPrint("user: image VA collision and no relocations for %s\n",
                     mod->name);
            return -1;
        }

        /* Probe complete image ranges, not just their first page. */
        uint64_t candidate = 0x50000000ULL;
        int found = 0;
        while (candidate < 0x0000800000000000ULL &&
               rounded <= 0x0000800000000000ULL - candidate) {
            if (MmUserRangeUnmapped(proc, candidate, rounded)) {
                base = candidate;
                found = 1;
                break;
            }
            if (candidate > UINT64_MAX - 0x02000000ULL) break;
            candidate += 0x02000000ULL;
        }
        if (!found) {
            DbgPrint("user: no free relocatable image range for %s\n",
                     mod->name);
            return -1;
        }
    }

    int slot = -1;
    for (int i = 0; i < USER_IMAGE_MAX; i++) {
        if (!user_images[i].phys && !user_images[i].proc &&
            !user_images[i].source) {
            slot = i;
            break;
        }
    }

    if (slot < 0) {
        DbgPrint("user: image table full for %s\n", mod->name);
        return -1;
    }

    uint64_t private_pa = pmm_alloc_n(pages);
    if (!private_pa) {
        DbgPrint("user: image allocation failed for %s (%llu pages)\n",
                 mod->name, (unsigned long long)pages);
        return -1;
    }

    uint8_t *src = (uint8_t *)(HHDM_BASE + mod->phys);
    uint8_t *dst = (uint8_t *)(HHDM_BASE + private_pa);

    for (uint64_t i = 0; i < size; i++)
        dst[i] = src[i];

    for (uint64_t i = size; i < rounded; i++)
        dst[i] = 0;

    uint64_t entry = base;

    /*
     * Save the record before resolving imports. This lets recursive DLL
     * dependencies detect that the image is already mapped.
     */
    UserImage *image = &user_images[slot];
    image->proc = proc;
    image->source = mod;
    image->phys = private_pa;
    image->base = base;
    image->entry = entry;
    image->size = rounded;
    image->resolving = 0;
    image->resolved = 0;

    /*
     * The allocation is contiguous, so every virtual image page maps to
     * the corresponding private physical page.
     */
    for (uint64_t off = 0; off < rounded; off += USER_IMAGE_PAGE) {
        map_4k_in(proc->Pml4, base + off,
                  private_pa + off, PTE_U | PTE_RW | PTE_OWNED);
    }

    if (pe_is_image(dst, size)) {
        int32_t lfanew = *(int32_t *)(dst + 0x3C);
        uint8_t *opt = dst + lfanew + 4 + 20;

        uint64_t preferred_base = *(uint64_t *)(opt + 24);
        int64_t delta = (int64_t)base - (int64_t)preferred_base;

        if (delta && !pe_apply_relocs(dst, size, delta)) {
            DbgPrint("user: invalid or unsupported PE relocations in %s\n", mod->name);
            for (uint64_t off = 0; off < rounded; off += USER_IMAGE_PAGE)
                MmUnmapAllocatedUserPage(proc, base + off);
            image->proc = 0;
            image->source = 0;
            image->phys = 0;
            image->base = 0;
            image->entry = 0;
            image->size = 0;
            return -1;
        }

        uint32_t ep_rva = *(uint32_t *)(opt + 16);

        if (ep_rva >= size) {
            DbgPrint("user: invalid PE entry point in %s\n", mod->name);
            for (uint64_t off = 0; off < rounded; off += USER_IMAGE_PAGE)
                MmUnmapAllocatedUserPage(proc, base + off);

            image->proc = 0;
            image->source = 0;
            image->phys = 0;
            image->base = 0;
            image->entry = 0;
            image->size = 0;
            return -1;
        }

        image->entry = base + ep_rva;
    }

    DbgPrint("user: private image %s pid=%lu va=%p pa=%p size=%llu\n",
             mod->name,
             (unsigned long)proc->Pid,
             (void *)image->base,
             (void *)image->phys,
             (unsigned long long)image->size);

    return 0;
}

/*
 * Resolve PE exports by name or ordinal and follow forwarded exports.
 * Forwarders are used throughout Windows DLLs; returning their RVA as if it
 * were executable code leads directly to null or invalid indirect calls.
 */
static BootModule *PspLoadProcessDiskDependency(KPROCESS *proc, const char *name);
static void pe_resolve_imports(KPROCESS *proc, BootModule *mod);
static uint64_t pe_get_export(KPROCESS *proc, BootModule *mod, const char *func);
static uint64_t pe_get_export_depth(KPROCESS *proc, BootModule *mod, const char *func, unsigned int depth);

static uint64_t pe_get_export_ordinal(KPROCESS *proc, BootModule *mod,
                                      uint32_t ordinal, unsigned int depth) {
    if (!proc || !mod || depth > 12) return 0;
    UserImage *image = PspGetUserImage(proc, mod);
    if (!image) return 0;
    uint8_t *bytes = PspImageBytes(image);
    uint64_t size = image->size;
    if (!pe_is_image(bytes, size)) return 0;
    int32_t peoff = *(int32_t *)(bytes + 0x3C);
    uint8_t *opt = bytes + peoff + 4 + 20;
    uint32_t er = *(uint32_t *)(opt + 112);
    if (!er || er >= size || size - er < 40) return 0;
    uint32_t es = *(uint32_t *)(opt + 112 + 4);
    if (es < 40 || es > size - er) return 0;
    uint8_t *exp = bytes + er;
    uint32_t base = *(uint32_t *)(exp + 16);
    uint32_t nf = *(uint32_t *)(exp + 20);
    uint32_t fr = *(uint32_t *)(exp + 28);
    if (ordinal < base || ordinal - base >= nf || fr >= size ||
        (uint64_t)nf * 4 > size - fr) return 0;
    uint32_t rva = *(uint32_t *)(bytes + fr + (uint64_t)(ordinal - base) * 4);
    if (!rva || rva >= size) return 0;
    if (rva < er || (uint64_t)rva >= (uint64_t)er + es)
        return image->base + rva;

    const char *fwd = (const char *)(bytes + rva);
    uint64_t remain = (uint64_t)er + es - rva, len = 0, dot = UINT64_MAX;
    while (len < remain && fwd[len]) {
        if (fwd[len] == '.') dot = len;
        len++;
    }
    if (!len || len >= remain || dot == UINT64_MAX || dot == 0 ||
        dot + 1 >= len || dot > 59) return 0;
    char dll[64];
    for (uint64_t i = 0; i < dot; i++) dll[i] = fwd[i];
    dll[dot] = 0;
    int has_dll = 0;
    if (dot >= 4) {
        const char *x = dll + dot - 4;
        has_dll = x[0] == '.' &&
            (x[1] == 'd' || x[1] == 'D') &&
            (x[2] == 'l' || x[2] == 'L') &&
            (x[3] == 'l' || x[3] == 'L');
    }
    if (!has_dll) {
        if (dot + 4 >= sizeof(dll)) return 0;
        dll[dot] = '.'; dll[dot+1] = 'd'; dll[dot+2] = 'l';
        dll[dot+3] = 'l'; dll[dot+4] = 0;
    }
    BootModule *target = PspFindModule(user_bootinfo, dll);
    if (!target) target = PspLoadProcessDiskDependency(proc, dll);
    if (!target || PspMapUserImage(proc, target) != 0) return 0;
    pe_resolve_imports(proc, target);

    const char *symbol = fwd + dot + 1;
    if (symbol[0] == '#') {
        uint32_t n = 0;
        if (symbol[1] == 0) return 0;
        for (uint64_t i = 1; i < len - dot - 1; i++) {
            if (symbol[i] < '0' || symbol[i] > '9') return 0;
            if (n > (UINT32_MAX - 9u) / 10u) return 0;
            n = n * 10u + (uint32_t)(symbol[i] - '0');
        }
        return pe_get_export_ordinal(proc, target, n, depth + 1);
    }
    /* Name lookup can itself lead to another forwarder. */
    return pe_get_export_depth(proc, target, symbol, depth + 1);
}

static uint64_t pe_get_export_depth(KPROCESS *proc, BootModule *mod, const char *func, unsigned int depth) {
    if (!proc || !mod || !func || depth > 12) return 0;
    UserImage *image = PspGetUserImage(proc, mod);
    if (!image) return 0;
    uint8_t *bytes = PspImageBytes(image);
    uint64_t size = image->size;
    if (!pe_is_image(bytes, size)) return 0;
    int32_t peoff = *(int32_t *)(bytes + 0x3C);
    uint8_t *opt = bytes + peoff + 4 + 20;
    uint32_t er = *(uint32_t *)(opt + 112);
    if (!er || er >= size || size - er < 40) return 0;
    uint8_t *exp = bytes + er;
    uint32_t nf = *(uint32_t *)(exp + 20);
    uint32_t nn = *(uint32_t *)(exp + 24);
    uint32_t fr = *(uint32_t *)(exp + 28);
    uint32_t nr = *(uint32_t *)(exp + 32);
    uint32_t or = *(uint32_t *)(exp + 36);
    uint32_t base = *(uint32_t *)(exp + 16);
    if (fr >= size || nr >= size || or >= size ||
        (uint64_t)nf * 4 > size - fr ||
        (uint64_t)nn * 4 > size - nr ||
        (uint64_t)nn * 2 > size - or) return 0;
    for (uint32_t i = 0; i < nn; i++) {
        uint32_t name_rva = *(uint32_t *)(bytes + nr + (uint64_t)i * 4);
        if (name_rva >= size) continue;
        const char *name = (const char *)(bytes + name_rva);
        uint64_t k = 0, remain = size - name_rva;
        while (k < remain && func[k] && name[k] && func[k] == name[k]) k++;
        if (k >= remain || func[k] || name[k]) continue;
        uint16_t index = *(uint16_t *)(bytes + or + (uint64_t)i * 2);
        if (index >= nf) return 0;
        return pe_get_export_ordinal(proc, mod, base + index, depth);
    }
    return 0;
}

static uint64_t pe_get_export(KPROCESS *proc, BootModule *mod, const char *func) {
    if (!proc || !mod || !func || !func[0]) return 0;

    /* GetProcAddress encodes an ordinal as a low-valued pointer. The user-mode
       wrapper converts that pointer to "#<ordinal>" before crossing the syscall
       boundary, so support the same representation in the PE export resolver. */
    if (func[0] == '#') {
        uint32_t ordinal = 0;
        if (!func[1]) return 0;
        for (uint32_t i = 1; func[i]; i++) {
            if (func[i] < '0' || func[i] > '9') return 0;
            uint32_t digit = (uint32_t)(func[i] - '0');
            if (ordinal > (UINT32_MAX - digit) / 10u) return 0;
            ordinal = ordinal * 10u + digit;
        }
        return pe_get_export_ordinal(proc, mod, ordinal, 0);
    }

    return pe_get_export_depth(proc, mod, func, 0);
}

/*
 * Resolve imports in process-private images. Missing imports stay null rather
 * than becoming a bogus RVA; supported forwarders and ordinal imports are
 * resolved above.
 */
static void pe_resolve_imports(KPROCESS *proc, BootModule *mod) {
    if (!proc || !mod) return;
    UserImage *image = PspGetUserImage(proc, mod);
    if (!image || image->resolved || image->resolving) return;
    uint8_t *phys = PspImageBytes(image);
    uint64_t size = image->size;
    if (!pe_is_image(phys, size)) {
        image->import_failed = 1;
        image->resolved = 1;
        return;
    }
    image->import_failed = 0;
    image->resolving = 1;
    int32_t peoff = *(int32_t *)(phys + 0x3C);
    uint8_t *opt = phys + peoff + 4 + 20;
    uint32_t imp = *(uint32_t *)(opt + 112 + 8);
    uint32_t imp_size = *(uint32_t *)(opt + 112 + 12);
    if (!imp && !imp_size) {
        image->resolving = 0;
        image->resolved = 1;
        return; /* valid PE image with no import directory */
    }
    if (!imp || imp >= size || (imp_size && imp_size > size - imp)) {
        image->import_failed = 1;
        image->resolving = 0;
        image->resolved = 1;
        return;
    }
    uint64_t desc_count = imp_size ? imp_size / 20 : (size - imp) / 20;
    unsigned int unresolved_logged = 0;
    for (uint64_t d = 0; d < desc_count; d++) {
        uint64_t off = (uint64_t)imp + d * 20;
        if (off > size || size - off < 20) break;
        uint8_t *desc = phys + off;
        uint32_t oft = *(uint32_t *)(desc + 0);
        uint32_t name_rva = *(uint32_t *)(desc + 12);
        uint32_t ft = *(uint32_t *)(desc + 16);
        if (!oft && !name_rva && !ft) break;
        if (!name_rva || !ft || name_rva >= size || ft >= size) {
            image->import_failed = 1;
            continue;
        }
        const char *dll_name = (const char *)(phys + name_rva);

        /*
         * The api-ms-win-crt-* names are API-set contracts, not independent
         * runtime images. The build currently packages several contracts as
         * copies of the same minimal CRT PE. Mapping each copy separately
         * collides at the same preferred ImageBase (and those copies have no
         * relocation directory). Resolve the contract to the single shared
         * CRT implementation instead. Keep the original name for diagnostics.
         */
        char dependency_name[64];
        unsigned int dll_len = 0;
        while (dll_name[dll_len] && dll_len + 1 < sizeof(dependency_name)) {
            char ch = dll_name[dll_len];
            dependency_name[dll_len] = (ch >= 'A' && ch <= 'Z')
                ? (char)(ch + ('a' - 'A')) : ch;
            dll_len++;
        }
        dependency_name[dll_len] = 0;
        int is_crt_contract =
            dll_len >= 15 &&
            dependency_name[0] == 'a' && dependency_name[1] == 'p' &&
            dependency_name[2] == 'i' && dependency_name[3] == '-' &&
            dependency_name[4] == 'm' && dependency_name[5] == 's' &&
            dependency_name[6] == '-' && dependency_name[7] == 'w' &&
            dependency_name[8] == 'i' && dependency_name[9] == 'n' &&
            dependency_name[10] == '-' && dependency_name[11] == 'c' &&
            dependency_name[12] == 'r' && dependency_name[13] == 't' &&
            dependency_name[14] == '-';
        if (is_crt_contract) {
            const char crt_runtime[] = "api-ms-win-crt-runtime-l1-1-0.dll";
            unsigned int j = 0;
            while (crt_runtime[j] && j + 1 < sizeof(dependency_name)) {
                dependency_name[j] = crt_runtime[j];
                j++;
            }
            dependency_name[j] = 0;
        } else if (dll_len == 0 || dll_len + 1 >= sizeof(dependency_name)) {
            dependency_name[0] = 0;
        }

        BootModule *dep = dependency_name[0]
            ? PspFindModule(user_bootinfo, dependency_name) : 0;
        if (!dep && dependency_name[0])
            dep = PspLoadProcessDiskDependency(proc, dependency_name);
        if (!dep) {
            image->import_failed = 1;
            if (unresolved_logged < 32) {
                DbgPrint("user: unresolved DLL import image=%s pid=%lu dll=%s\n",
                         mod->name, (unsigned long)proc->Pid, dll_name);
                unresolved_logged++;
            }
        }
        uint32_t look_rva = oft ? oft : ft;
        if (look_rva >= size) continue;
        uint64_t count = (size - look_rva) / 8;
        uint64_t iat_count = (size - ft) / 8;
        if (count > iat_count) count = iat_count;
        if (dep && PspMapUserImage(proc, dep) == 0) pe_resolve_imports(proc, dep);
        for (uint64_t i = 0; i < count; i++) {
            uint64_t look = *(uint64_t *)(phys + look_rva + i * 8);
            if (!look) break;
            uint64_t addr = 0;
            if (dep && PspGetUserImage(proc, dep)) {
                if (look & 0x8000000000000000ULL)
                    addr = pe_get_export_ordinal(proc, dep, (uint32_t)(look & 0xFFFFu), 0);
                else {
                    uint32_t name_off = (uint32_t)look;
                    if (name_off <= size && size - name_off >= 3)
                        addr = pe_get_export(proc, dep, (const char *)(phys + name_off + 2));
                }
            }
            if (!addr) {
                image->import_failed = 1;
            }
            if (!addr && unresolved_logged < 32) {
                if (look & 0x8000000000000000ULL) {
                    DbgPrint("user: unresolved import image=%s pid=%lu dll=%s ordinal=%u iat=%p\n",
                             mod->name, (unsigned long)proc->Pid, dll_name,
                             (unsigned)(look & 0xFFFFu),
                             (void *)(uintptr_t)(image->base + ft + i * 8));
                } else {
                    uint32_t name_off = (uint32_t)look;
                    const char *symbol = (name_off <= size && size - name_off >= 3)
                        ? (const char *)(phys + name_off + 2) : "<bad-import-name>";
                    DbgPrint("user: unresolved import image=%s pid=%lu dll=%s symbol=%s iat=%p\n",
                             mod->name, (unsigned long)proc->Pid, dll_name, symbol,
                             (void *)(uintptr_t)(image->base + ft + i * 8));
                }
                unresolved_logged++;
            }
            /*
             * Never replace an unresolved import with NULL. Keep the original
             * thunk contents for diagnostics/retry; process creation below
             * rejects images whose required imports did not resolve.
             */
            if (addr)
                *(uint64_t *)(phys + ft + i * 8) = addr;
        }
    }
    image->resolving = 0;
    image->resolved = 1;
}

/* ------------------------------------------------------------ user memory */

static int copy_user_str(uint64_t uaddr, char *out, int max) {
    if (!out || max <= 0 ||
        uaddr < 0x10000ULL ||
        uaddr >= 0x0000800000000000ULL) return -1;

    for (int i = 0; i < max - 1; i++) {
        uint64_t at = uaddr + (uint64_t)i;
        if (at < uaddr || !MmValidateUserRange(MmCurrentProcess, at, 1, 0))
            return -1;
        char c = ((const char *)at)[0];
        out[i] = c;
        if (!c) return 0;
    }

    out[max - 1] = 0;
    return -1; /* no terminator within the supplied bound */
}

/* ------------------------------------------------------------ syscalls */

static uint64_t NtStatusResult(NTSTATUS status) {
    return (uint64_t)(int64_t)status;
}


/* Read-only VFS file handles used by the initial Win32 file APIs. */
#define VFS_USER_HANDLES 32
/* VFS handles are now managed by the Object Manager. This constant is kept for compatibility. */
#define SYS_NtCloseFile 22
#define SYS_NtQueryFileSize 25
#define SYS_NtQueryProcessList 41
#define SYS_NtGetApplicationError 42
#define SYS_NtSetFilePosition 26
typedef struct {
    uint32_t ino;
    uint64_t pos, size;
    int used, writable, ntfs;
} VfsUserHandle;
/* VfsUserHandle is now stored within OB_OBJECT.body. */
typedef struct {
    uint64_t creation_time,access_time,write_time,change_time,size;
    uint32_t inode,mode,volume_serial;
    uint16_t links,reserved;
} UserFileMetadata;
typedef struct {
    uint64_t total_blocks,free_blocks,reserved_blocks;
    uint32_t block_size,volume_serial,total_inodes,free_inodes;
    char volume_label[17];
} UserVolumeMetadata;
/* vfs_user_handles array is replaced by the Object Manager. */
static uint64_t user_filetime_from_unix(uint32_t seconds) {
    return ((uint64_t)seconds+11644473600ULL)*10000000ULL;
}

static int vfs_find_regular_file(const char *name, uint32_t *ino_out, uint64_t *size_out);

static uint64_t vfs_ntfsk_resolve(const char *name) {
    if (!g_ntfsk_ok || !name || !name[0]) return 0;
    char path[256];
    unsigned int n=0;
    while(name[n] && n<sizeof(path)-1) {
        path[n]=(name[n]=='\\')?'/':name[n];
        ++n;
    }
    if(name[n] || !n) return 0;
    path[n]=0;
    unsigned int pos=0;
    if(n>=2 && path[1]==':') pos=2;
    while(path[pos]=='/') ++pos;
    uint64_t parent=5, found=0;
    while(pos<n) {
        unsigned int end=pos;
        while(end<n && path[end]!='/') ++end;
        if(end==pos) { ++pos; continue; }
        char part[256]; unsigned int len=end-pos;
        if(len>=sizeof(part)) return 0;
        for(unsigned int i=0;i<len;i++) part[i]=path[pos+i];
        part[len]=0;
        found=ntfsk_lookup(&g_ntfsk_volume,parent,part);
        if(!found) return 0;
        parent=found;
        pos=end;
        while(path[pos]=='/') ++pos;
    }
    return found;
}

static int vfs_ntfsk_internal_root_name(const uint8_t *fn,uint8_t nl) {
    static const char *const internal[]={
        "$MFT","$MFTMirr","$LogFile","$Volume","$AttrDef","$Bitmap",
        "$Boot","$BadClus","$Secure","$UpCase","$Extend","$Quota",
        "$ObjId","$Reparse","$UsnJrnl"
    };
    for(unsigned int n=0;n<sizeof(internal)/sizeof(internal[0]);n++) {
        const char *s=internal[n];unsigned int i=0;
        while(s[i]&&i<nl) {
            uint16_t ch=ntfsk_u16(fn+66+i*2);
            char a=(char)ch,b=s[i];
            if(a>='a'&&a<='z')a-=32;
            if(b>='a'&&b<='z')b-=32;
            if(ch>127||a!=b)break;
            i++;
        }
        if(i==nl&&!s[i])return 1;
    }
    return 0;
}
static uint64_t vfs_ntfsk_cwd_storage=5;
static int vfs_ntfsk_refresh(void) {
    vfs_nent=0;
    if(!g_ntfsk_ok||!g_ntfsk_volume.mounted)return -1;
    uint8_t *r=kmalloc(g_ntfsk_volume.record_size);
    if(!r)return -1;
    uint64_t max=g_ntfsk_volume.mft_bytes/g_ntfsk_volume.record_size;
    for(uint64_t idx=0;idx<max&&vfs_nent<VFS_MAX_ENT;idx++) {
        if(ntfsk_record(&g_ntfsk_volume,idx,r)<0 ||
           (ntfsk_u16(r+22)&NTFSK_FILE_IN_USE)==0)continue;
        int is_dir=(ntfsk_u16(r+22)&NTFSK_FILE_DIRECTORY)!=0;
        uint16_t ao=ntfsk_u16(r+20);
        for(uint32_t p=ao;p+16<g_ntfsk_volume.record_size;) {
            uint32_t type=ntfsk_u32(r+p);
            if(type==NTFSK_ATTR_END)break;
            uint32_t al=ntfsk_u32(r+p+4);
            if(al<16||p+al>g_ntfsk_volume.record_size)break;
            if(type==NTFSK_ATTR_FILE_NAME&&!r[p+8]) {
                uint16_t vo=ntfsk_u16(r+p+20);
                if(vo<=al&&al-vo>=66) {
                    uint8_t *fn=r+p+vo;uint8_t nl=fn[64],ns=fn[65];
                    if(ns!=2&&nl&&66u+(uint32_t)nl*2u<=al-vo&&
                       (ntfsk_u64(fn)&0x0000ffffffffffffULL)==vfs_ntfsk_cwd_storage&&
                       !(vfs_ntfsk_cwd_storage==5&&vfs_ntfsk_internal_root_name(fn,nl))) {
                        VfsEnt *entry=&vfs_ents[vfs_nent];
                        uint32_t out=0;
                        for(uint32_t j=0;j<nl&&out<sizeof(entry->name)-1;j++) {
                            uint16_t ch=ntfsk_u16(fn+66+j*2);
                            entry->name[out++]=(ch>=32&&ch<127)?(char)ch:'?';
                        }
                        entry->name[out]=0;
                        entry->ino=(uint32_t)idx;
                        entry->is_dir=(uint8_t)is_dir;
                        vfs_nent++;
                        /* One visible name per MFT record; skip DOS aliases. */
                        break;
                    }
                }
            }
            p+=al;
        }
    }
    kfree(r);
    if(vfs_nent>=VFS_MAX_ENT)
        DbgPrint("fs: NTFS directory listing reached %u-entry limit",(unsigned)VFS_MAX_ENT);
    return vfs_nent;
}
static int vfs_refresh_current_directory(void) {
    if (g_ntfsk_ok) return vfs_ntfsk_refresh();
    if (g_ext4_ok && g_ext4.blksz) return vfs_listdir(vfs_cwd_ino);
    vfs_nent = 0;
    return -1;
}
static uint64_t vfs_ntfsk_resolve_from(const char *name,uint64_t start_ino) {
    if(!g_ntfsk_ok||!name||!name[0])return 0;
    char path[256];unsigned int n=0;
    while(name[n]&&n<sizeof(path)-1){path[n]=(name[n]=='\\')?'/':name[n];n++;}
    if(name[n]||!n)return 0;
    path[n]=0;
    unsigned int pos=0;int absolute=0;
    if(n>=2&&path[1]==':'){pos=2;absolute=1;}
    if(path[pos]=='/')absolute=1;
    while(path[pos]=='/')pos++;
    uint64_t parent=absolute?5:start_ino,found=parent;
    while(pos<n) {
        unsigned int end=pos;while(end<n&&path[end]!='/')end++;
        if(end==pos){pos++;continue;}
        char part[256];unsigned int len=end-pos;if(len>=sizeof(part))return 0;
        for(unsigned int i=0;i<len;i++)part[i]=path[pos+i];
        part[len]=0;
        if(part[0]=='.'&&part[1]=='.'&&!part[2]) {
            if(parent!=5)parent=ntfsk_parent(&g_ntfsk_volume,parent);
            found=parent;
        } else if(!(part[0]=='.'&&!part[1])) {
            found=ntfsk_lookup(&g_ntfsk_volume,parent,part);
            if(!found)return 0;
            parent=found;
        }
        pos=end;while(path[pos]=='/')pos++;
    }
    return found;
}
static int vfs_ntfsk_chdir(const char *name) {
    if(!g_ntfsk_ok||!name||!name[0])return -1;
    if(name[0]=='.'&&name[1]=='.'&&!name[2]) {
        if(vfs_ntfsk_cwd_storage!=5)
            vfs_ntfsk_cwd_storage=ntfsk_parent(&g_ntfsk_volume,vfs_ntfsk_cwd_storage);
        return vfs_ntfsk_refresh()>=0?0:-1;
    }
    if(name[0]=='.'&&!name[1])return 0;
    uint64_t target=vfs_ntfsk_resolve_from(name,vfs_ntfsk_cwd_storage);
    if(!target||!ntfsk_is_directory(&g_ntfsk_volume,target))return -1;
    vfs_ntfsk_cwd_storage=target;
    return vfs_ntfsk_refresh()>=0?0:-1;
}
static int vfs_ntfsk_open_path(const char *name, uint64_t *index_out,
                               uint64_t *size_out) {
    if(!name || !index_out || !size_out) return -1;
    uint64_t idx=vfs_ntfsk_resolve(name);
    const char *prefixes[]={"magic/System32/","magic/","magic/Program Files/"};
    char candidate[256];
    for(unsigned int p=0;!idx && p<sizeof(prefixes)/sizeof(prefixes[0]);p++) {
        unsigned int i=0,j=0;
        while(prefixes[p][i] && i+1<sizeof(candidate)){candidate[i]=prefixes[p][i];i++;}
        while(name[j] && i+j+1<sizeof(candidate)){candidate[i+j]=(name[j]=='\\')?'/':name[j];j++;}
        if(name[j]) continue;
        candidate[i+j]=0;
        idx=vfs_ntfsk_resolve(candidate);
    }
    if(!idx) return -1;
    void *data=0; uint64_t size=0;
    if(ntfsk_read_file(&g_ntfsk_volume,idx,&data,&size)<0) return -1;
    kfree(data);
    *index_out=idx; *size_out=size;
    return 0;
}

static int64_t vfs_open_user_file(const char *name) {
    if ((!g_ext4_ok && !g_ntfsk_ok) || !name || !name[0]) return -1;
    uint32_t ino = 0;
    for (int i = 0; i < vfs_nent; i++) {
        const char *a = vfs_ents[i].name, *b = name;
        int same = 1;
        while (*a || *b) {
            char ca = *a++, cb = *b++;
            if (ca >= 'A' && ca <= 'Z') ca += 'a' - 'A';
            if (cb >= 'A' && cb <= 'Z') cb += 'a' - 'A';
            if (ca != cb) { same = 0; break; }
        }
        if (same && !vfs_ents[i].is_dir) { ino = vfs_ents[i].ino; break; }
    }
    /* The UI cache only lists the mounted root. Resolve real paths and
       common Windows DLL basenames through the ext4 directory hierarchy. */
    if (!ino) {
        uint64_t ignored_size=0;
        if (vfs_find_regular_file(name,&ino,&ignored_size)<0) ino=0;
        const char *prefixes[]={"magic/System32/","magic/","magic/Program Files/"};
        char candidate[256];
        for (unsigned int p=0; !ino && p<sizeof(prefixes)/sizeof(prefixes[0]); ++p) {
            unsigned int i=0,j=0;
            while(prefixes[p][i] && i+1<sizeof(candidate)) {
                candidate[i]=prefixes[p][i]; i++;
            }
            while(name[j] && i+j+1<sizeof(candidate)) {
                candidate[i+j]=name[j]=='\\' ? '/' : name[j]; j++;
            }
            if(name[j]) continue;
            candidate[i+j]=0;
            if(vfs_find_regular_file(candidate,&ino,&ignored_size)<0) ino=0;
        }
    }
    if (!ino && g_ntfsk_ok) {
        uint64_t ntfs_index=0, ntfs_size=0;
        if(vfs_ntfsk_open_path(name,&ntfs_index,&ntfs_size)==0 && ntfs_index<=UINT32_MAX) {
            OB_HANDLE handle;
            void *body;
            if (!ObCreateObject(ObTypeFile, NULL, sizeof(VfsUserHandle), (uintptr_t)MmCurrentProcess->Pid, OB_ACCESS_READ|OB_ACCESS_WRITE, &handle, &body)) return -1;
            VfsUserHandle *vh = (VfsUserHandle *)body;
            vh->ino=(uint32_t)ntfs_index;
            vh->pos=0;
            vh->size=ntfs_size;
            vh->used=1; vh->writable=1;
            vh->ntfs=1;
            ObDereferenceObject((OB_OBJECT *)((uint8_t *)body - offsetof(OB_OBJECT, body)));
            return (int64_t)handle;
        }
    }
    if (!ino || !g_ext4_ok) return -1;
    uint8_t inode[256];
    if (e4_inode(&g_ext4, ino, inode) < 0 ||
        (E16(inode, 0) & 0xF000) != 0x8000) return -1;
    OB_HANDLE handle;
    void *body;
    if (!ObCreateObject(ObTypeFile, NULL, sizeof(VfsUserHandle), (uintptr_t)MmCurrentProcess->Pid, OB_ACCESS_READ, &handle, &body)) return -1;
    VfsUserHandle *vh = (VfsUserHandle *)body;
    vh->ino = ino;
    vh->pos = 0;
    vh->size = e4_size(inode);
    vh->used = 1;
    vh->writable = 0;
    vh->ntfs = 0;
    ObDereferenceObject((OB_OBJECT *)((uint8_t *)body - offsetof(OB_OBJECT, body)));
    return (int64_t)handle;
}

static void vfs_ntfsk_invalidate_cached_file(uint32_t ino);
static int64_t vfs_create_user_output_file(const char *name) {
    if (!g_ext4_ok || !name || !name[0]) return -1;
    uint32_t ino = 0;
    if (e4_create_empty_file(&g_ext4, vfs_cwd_ino, name, &ino) < 0)
        return -1;
    OB_HANDLE handle;
    void *body;
    if (!ObCreateObject(ObTypeFile, NULL, sizeof(VfsUserHandle), (uintptr_t)MmCurrentProcess->Pid, OB_ACCESS_READ|OB_ACCESS_WRITE, &handle, &body)) return -1;
    VfsUserHandle *vh = (VfsUserHandle *)body;
    vh->ino = ino;
    vh->pos = 0;
    vh->size = 0;
    vh->used = 1;
    vh->writable = 1;
    ObDereferenceObject((OB_OBJECT *)((uint8_t *)body - offsetof(OB_OBJECT, body)));
    (void)vfs_refresh_current_directory();
    return (int64_t)handle;
}

static int vfs_write_user_output_file(uint64_t handle, uint64_t src, uint64_t len) {
    OB_OBJECT *obj = ObReferenceObjectByHandle((uintptr_t)MmCurrentProcess->Pid, (OB_HANDLE)handle, ObTypeFile, OB_ACCESS_WRITE);
    if (!obj || !len || len > 1024 * 1024) {
        if (obj) ObDereferenceObject(obj);
        return -1;
    }
    VfsUserHandle *h = (VfsUserHandle *)obj->body;
    KPROCESS *proc = MmCurrentProcess;
    if (!h->used || !h->writable || !proc || h->size > UINT32_MAX ||
        !MmValidateUserRange(proc, src, len, 0)) {
        ObDereferenceObject(obj);
        return -1;
    }
    if(h->ntfs) {
        if(h->pos>h->size||len>h->size-h->pos) { ObDereferenceObject(obj); return -1; }
        int rc=ntfsk_write_file_at(&g_ntfsk_volume,h->ino,h->pos,
                                  (const void *)(uintptr_t)src,len);
        if(rc>0){h->pos+=(uint64_t)rc;vfs_ntfsk_invalidate_cached_file(h->ino);}
        ObDereferenceObject(obj);
        return rc;
    }
    if (h->pos != h->size || len > UINT32_MAX - h->size) {
        ObDereferenceObject(obj);
        return -1;
    }
    uint8_t inode[256];
    if (e4_inode(&g_ext4, h->ino, inode) < 0 ||
        e4_size(inode) != h->size ||
        e4_write_inode_grow(&g_ext4, h->ino, h->pos,
                            (const void *)(uintptr_t)src, len) < 0) {
        ObDereferenceObject(obj);
        return -1;
    }
    h->pos += len;
    h->size += len;
    ObDereferenceObject(obj);
    return (int)len;
}

static int vfs_read_user_file(uint64_t handle, uint64_t dst, uint64_t len) {
    KPROCESS *proc = MmCurrentProcess;
    OB_OBJECT *obj = proc ? ObReferenceObjectByHandle((uintptr_t)proc->Pid,
        (OB_HANDLE)handle, ObTypeFile, OB_ACCESS_READ) : NULL;
    if (!obj || len > 1024 * 1024) {
        if (obj) ObDereferenceObject(obj);
        return -1;
    }
    VfsUserHandle *h = (VfsUserHandle *)obj->body;
    int result = -1;
    if (!h->used || !proc) goto done;
    if (!len) { result = 0; goto done; }
    if (
        !MmValidateUserRange(proc, dst, len, 1)) goto done;
    if (h->pos >= h->size) { result = 0; goto done; }
    if (h->ntfs) {
        if(!g_ntfsk_ok) goto done;
        if(len>h->size-h->pos) len=h->size-h->pos;
        void *whole=0; uint64_t actual=0;
        if(ntfsk_read_file(&g_ntfsk_volume,h->ino,&whole,&actual)<0) goto done;
        if(actual!=h->size || h->pos>actual || len>actual-h->pos) {
            kfree(whole); goto done;
        }
        memcpy((void *)(uintptr_t)dst,(const uint8_t *)whole+h->pos,(size_t)len);
        kfree(whole); h->pos+=len; result = (int)len; goto done;
    }
    if (len > h->size - h->pos) len = h->size - h->pos;

    uint8_t inode[256];
    if (e4_inode(&g_ext4, h->ino, inode) < 0) goto done;
    uint64_t done = 0;
    while (done < len) {
        uint64_t pos = h->pos + done;
        uint32_t block_off = (uint32_t)(pos % g_ext4.blksz);
        uint32_t run_blocks = 0;
        uint64_t phys_block = e4_map_run(&g_ext4, inode,
            (uint32_t)(pos / g_ext4.blksz), &run_blocks);
        uint64_t chunk;
        if (phys_block && run_blocks) {
            /* Read the contiguous part of this extent in one I/O operation. */
            chunk = (uint64_t)run_blocks * g_ext4.blksz - block_off;
            if (chunk > len - done) chunk = len - done;
            if (e4_read(&g_ext4, phys_block * g_ext4.blksz + block_off,
                        (void *)(dst + done), chunk) < 0)
                { result = done ? (int)done : -1; goto done; }
        } else {
            /* Sparse/unmapped block: preserve the previous zero-fill behavior. */
            chunk = g_ext4.blksz - block_off;
            if (chunk > len - done) chunk = len - done;
            for (uint64_t j = 0; j < chunk; j++)
                ((uint8_t *)dst)[done + j] = 0;
        }
        done += chunk;
    }
    h->pos += done;
    result = (int)done;
done:
    ObDereferenceObject(obj);
    return result;
}

static int vfs_close_user_file(uint64_t handle) {
    KPROCESS *proc = MmCurrentProcess;
    if (!proc) return 0;
    OB_OBJECT *obj = ObReferenceObjectByHandle((uintptr_t)proc->Pid,
        (OB_HANDLE)handle, ObTypeFile, OB_ACCESS_READ);
    if (!obj) return 0;
    VfsUserHandle *h = (VfsUserHandle *)obj->body;
    int writable = h->used && h->writable;
    int closed = ObCloseHandle((uintptr_t)proc->Pid, (OB_HANDLE)handle);
    if (closed) h->used = 0;
    ObDereferenceObject(obj);
    if (closed && writable) (void)vfs_refresh_current_directory();
    return closed;
}


/*
 * Resolve a regular file by walking ext4 directory inodes directly. The
 * cached vfs_ents list is intentionally bounded for UI enumeration, so it
 * must not be used as the authority for DLL loading: important files can be
 * beyond its first VFS_MAX_ENT entries. Accept Windows drive prefixes and
 * either slash style, and use case-insensitive lookup for Windows paths.
 */
static int vfs_find_regular_file(const char *name, uint32_t *ino_out,
                                 uint64_t *size_out) {
    if (!g_ext4_ok || !name || !name[0]) return -1;

    char path[256];
    unsigned int n = 0;
    while (name[n] && n < sizeof(path) - 1) {
        char c = name[n];
        path[n] = c == '\\' ? '/' : c;
        n++;
    }
    if (name[n] != 0 || n == 0) return -1;
    path[n] = 0;

    /* "C:/..." is a DOS path, not a directory named "C:". */
    unsigned int start = 0;
    if (n >= 2 && path[1] == ':') start = 2;
    while (path[start] == '/') start++;
    if (start >= n) return -1;

    uint32_t current = 2; /* ext4 root inode */
    unsigned int pos = start;
    while (pos < n) {
        unsigned int end = pos;
        while (end < n && path[end] != '/') end++;
        if (end == pos) { pos++; continue; }
        char component[256];
        unsigned int len = end - pos;
        if (len >= sizeof(component)) return -1;
        for (unsigned int i = 0; i < len; i++) component[i] = path[pos + i];
        component[len] = 0;

        uint32_t child = e4_lookup(&g_ext4, current, component);
        if (!child) return -1;
        uint8_t inode[256];
        if (e4_inode(&g_ext4, child, inode) < 0) return -1;
        uint16_t mode = E16(inode, 0) & 0xF000;
        if (end < n) {
            if (mode != 0x4000) return -1;
            current = child;
            pos = end + 1;
            while (path[pos] == '/') pos++;
            continue;
        }
        if (mode != 0x8000) return -1;
        if (ino_out) *ino_out = child;
        if (size_out) *size_out = e4_size(inode);
        return 0;
    }
    return -1;
}
/*
 * Image loading from the read-only NTFS system volume. The PE loader below
 * only knew how to read ext4 inodes, so with an NTFS root it reported
 * "disk image not found: smss.exe" even though the volume was mounted.
 * The MFT index plays the role of the inode number when ext4 is absent.
 */
static uint8_t *g_psp_ntfs_buf;
static uint64_t g_psp_ntfs_size, g_psp_ntfs_idx;
static void vfs_release_ntfs_image_cache(void) {
    if (g_psp_ntfs_buf) kfree(g_psp_ntfs_buf);
    g_psp_ntfs_buf = 0; g_psp_ntfs_size = 0; g_psp_ntfs_idx = 0;
}
static void vfs_ntfsk_invalidate_cached_file(uint32_t ino) {
    if(g_psp_ntfs_buf&&g_psp_ntfs_idx==ino)vfs_release_ntfs_image_cache();
}
static int vfs_find_image_file(const char *name, uint32_t *ino_out,
                               uint64_t *size_out) {
    if (!name || !name[0] || !ino_out || !size_out) return -1;

    /*
     * Both filesystem backends can be mounted during boot (for example, an
     * ext4 boot volume alongside the NTFS system volume). Do not let an ext4
     * miss hide a valid system image on NTFS: try each mounted backend until
     * the requested path is actually found.
     */
    if (g_ext4_ok &&
        vfs_find_regular_file(name, ino_out, size_out) == 0)
        return 0;

    if (g_ntfsk_ok) {
        uint64_t idx = 0, size = 0;
        if (vfs_ntfsk_open_path(name, &idx, &size) == 0 &&
            idx <= UINT32_MAX) {
            *ino_out = (uint32_t)idx;
            *size_out = size;
            return 0;
        }
    }
    DbgPrint("user: image lookup miss path=%s ext4=%d ntfs=%d ntfs_mounted=%d\\n",
             name, g_ext4_ok, g_ntfsk_ok, g_ntfsk_volume.mounted);
    return -1;
}
static int vfs_read_ntfs_image_at(uint32_t ino, uint64_t pos, void *dst,
                                  uint64_t len) {
    if (!dst || !g_ntfsk_ok) return -1;
    if (!g_psp_ntfs_buf || g_psp_ntfs_idx != ino) {
        void *whole = 0; uint64_t actual = 0;
        if (ntfsk_read_file(&g_ntfsk_volume, ino, &whole, &actual) < 0) return -1;
        vfs_release_ntfs_image_cache();
        g_psp_ntfs_buf = (uint8_t *)whole; g_psp_ntfs_size = actual;
        g_psp_ntfs_idx = ino;
    }
    if (pos >= g_psp_ntfs_size || !len) return 0;
    if (len > g_psp_ntfs_size - pos) len = g_psp_ntfs_size - pos;
    memcpy(dst, g_psp_ntfs_buf + pos, (size_t)len);
    return (int)len;
}
static int vfs_read_inode_at(uint32_t ino,uint64_t pos,void *dst,uint64_t len) {
    if (!g_ext4_ok && g_ntfsk_ok) return vfs_read_ntfs_image_at(ino,pos,dst,len);
    uint8_t inode[256];
    if(!dst || e4_inode(&g_ext4,ino,inode)<0) return -1;
    uint64_t size=e4_size(inode);
    if(pos>=size || !len) return 0;
    if(len>size-pos)len=size-pos;
    uint64_t done=0;
    while(done<len) {
        uint64_t off=pos+done;
        uint32_t inblock=(uint32_t)(off%g_ext4.blksz);
        uint64_t chunk=g_ext4.blksz-inblock;
        if(chunk>len-done)chunk=len-done;
        uint64_t pb=e4_map(&g_ext4,inode,(uint32_t)(off/g_ext4.blksz));
        if(!pb) {
            uint8_t *d=(uint8_t *)dst;
            for(uint64_t j=0;j<chunk;j++)d[done+j]=0;
        } else if(e4_read(&g_ext4,pb*g_ext4.blksz+inblock,
                           (uint8_t *)dst+done,chunk)<0) {
            return done?(int)done:-1;
        }
        done+=chunk;
    }
    return (int)done;
}
static void PspFreeDiskModule(UserDiskModule *d) {
    if(!d || !d->used)return;
    for(uint64_t i=0;i<d->source_pages;i++)
        pmm_free(d->source_phys+i*USER_IMAGE_PAGE);
    d->module.phys=0; d->module.size=0; d->module.entry=0;
    d->module.base=0; d->owner=0; d->source_phys=0;
    d->source_pages=0;
    for (int i=0;i<(int)sizeof(d->image_path);i++) d->image_path[i]=0;
    for (int i=0;i<(int)sizeof(d->dependency_name);i++) d->dependency_name[i]=0;
    d->used=0;
}
static void PspForgetDiskModule(KPROCESS *owner) {
    if(!owner)return;
    for(int i=0;i<USER_DISK_MODULE_MAX;i++)
        if(user_disk_modules[i].used && user_disk_modules[i].owner==owner)
            PspFreeDiskModule(&user_disk_modules[i]);
}
/*
 * Load an on-disk x64 PE32+ file into image layout. This handles PE headers
 * and section copies; imports are resolved from boot or disk-loaded modules.
 */
/*
 * Load an on-disk x64 PE32+ file into image layout without reading the entire
 * file into RAM. Large installers commonly carry a huge overlay after their
 * PE sections; that overlay is data, not part of the mapped executable image.
 *
 * The file itself has no arbitrary 64 MiB cap. Only PE headers are buffered;
 * section data is streamed directly from the filesystem into the allocated
 * image. Actual limits are the PE format, address space, filesystem and RAM.
 */
static UserDiskModule *PspLoadDiskModuleImpl(const char *name, KPROCESS *owner);
static UserDiskModule *PspLoadDiskModule(const char *name, KPROCESS *owner) {
    UserDiskModule *m = PspLoadDiskModuleImpl(name, owner);
    vfs_release_ntfs_image_cache();
    return m;
}
static UserDiskModule *PspLoadDiskModuleImpl(const char *name, KPROCESS *owner) {
    uint32_t ino=0;
    uint64_t raw_size=0;
    char system_path[224];
    unsigned int path_len = 0;
    while (name[path_len] && path_len < 159) path_len++;
    if (name[path_len] != 0) { DbgPrint("user: disk image path too long\n"); return 0; }

    int found = 0;
    if (owner) {
        const char *app_dir = 0;
        for (int k=0;k<USER_DISK_MODULE_MAX;k++) {
            UserDiskModule *main = &user_disk_modules[k];
            if (!main->used || main->owner != owner) continue;
            int has_sep = 0;
            for (int j=0;main->image_path[j];j++)
                if (main->image_path[j]=='/' || main->image_path[j]=='\\') has_sep=1;
            if (has_sep) { app_dir = main->image_path; break; }
        }
        if (app_dir) {
            unsigned int dir_len=0;
            while (app_dir[dir_len] && dir_len+1<sizeof(system_path)) dir_len++;
            while (dir_len>0 && app_dir[dir_len-1]!='/' && app_dir[dir_len-1]!='\\') dir_len--;
            if (dir_len>0 && dir_len+path_len+1<=sizeof(system_path)) {
                for (unsigned int j=0;j<dir_len;j++)
                    system_path[j]=(app_dir[j]=='\\')?'/':app_dir[j];
                for (unsigned int j=0;j<path_len;j++)
                    system_path[dir_len+j]=(name[j]=='\\')?'/':name[j];
                system_path[dir_len+path_len]=0;
                found = vfs_find_image_file(system_path, &ino, &raw_size) >= 0;
                if (!found) {
                    unsigned int start=0;
                    if (dir_len>=2 && system_path[1]==':') start=2;
                    while (system_path[start]=='/') start++;
                    if (start && system_path[start]) {
                        char relative_path[224];
                        unsigned int n=0;
                        while (system_path[start+n] && n+1<sizeof(relative_path)) {
                            relative_path[n]=system_path[start+n]; n++;
                        }
                        relative_path[n]=0;
                        found = vfs_find_image_file(relative_path, &ino, &raw_size) >= 0;
                    }
                }
            }
        }
    }
    if (!found) found = vfs_find_image_file(name, &ino, &raw_size) >= 0;

    const char prefix0[] = "magic/System32/";
    const char prefix1[] = "C:/magic/System32/";
    const char prefix2[] = "C:\\magic\\System32\\";
    const char prefix3[] = "magic/Program Files/";
    const char prefix4[] = "System32/";
    const char prefix5[] = "Windows/System32/";
    const char prefix6[] = "C:/Windows/System32/";
    const char *prefixes[] = { prefix0, prefix1, prefix2, prefix3, prefix4, prefix5, prefix6 };
    for (unsigned int p = 0; !found && p < sizeof(prefixes)/sizeof(prefixes[0]); ++p) {
        unsigned int i = 0;
        while (prefixes[p][i] && i + path_len + 1 < sizeof(system_path)) {
            system_path[i] = prefixes[p][i];
            i++;
        }
        unsigned int j = 0;
        while (j < path_len && i + j + 1 < sizeof(system_path)) {
            system_path[i + j] = name[j];
            j++;
        }
        if (j != path_len) continue;
        system_path[i + j] = 0;
        found = vfs_find_image_file(system_path, &ino, &raw_size) >= 0;
    }
    if (!found) { DbgPrint("user: disk image not found: %s\n", name); return 0; }
    DbgPrint("user: PE probe path=%s size=%llu ino=%u\n",name,(unsigned long long)raw_size,ino);
    if (raw_size < 0x100) { DbgPrint("user: PE reject too-small file size=%llu\n",(unsigned long long)raw_size);
        DbgPrint("user: disk image too small: %s size=%llu\n", name,
                 (unsigned long long)raw_size);
        return 0;
    }

    /* Read only enough to discover and validate the PE header extent. */
    uint8_t dos[64];
    if (vfs_read_inode_at(ino,0,dos,sizeof(dos))!=(int)sizeof(dos) ||
        dos[0]!='M' || dos[1]!='Z') { DbgPrint("user: PE reject DOS header/read\n");
        DbgPrint("user: disk image is not MZ PE: %s\n",name);
        return 0;
    }
    int32_t lfanew=*(int32_t *)(dos+0x3C);
    if (lfanew<0 || (uint64_t)lfanew>raw_size ||
        raw_size-(uint64_t)lfanew<24) { DbgPrint("user: PE reject e_lfanew=%d size=%llu\n",lfanew,(unsigned long long)raw_size); return 0; }

    uint8_t nt_head[24];
    if (vfs_read_inode_at(ino,(uint64_t)lfanew,nt_head,sizeof(nt_head))!=(int)sizeof(nt_head) ||
        *(uint32_t *)nt_head!=0x00004550) { DbgPrint("user: PE reject NT signature/read\n"); return 0; }
    uint16_t machine=*(uint16_t *)(nt_head+4);
    uint16_t sections=*(uint16_t *)(nt_head+6);
    uint16_t opt_size=*(uint16_t *)(nt_head+20);
    uint64_t opt_off=(uint64_t)lfanew+24;
    if (machine!=0x8664 || opt_size<160 || !sections || sections>96 ||
        opt_off>raw_size || opt_size>raw_size-opt_off) { DbgPrint("user: PE reject COFF machine=%x sections=%u opt=%u\n",machine,sections,opt_size); return 0; }

    uint64_t sect_off=opt_off+opt_size;
    uint64_t header_need=sect_off+(uint64_t)sections*40;
    if (header_need<sect_off || header_need>raw_size ||
        header_need>1024ull*1024ull) { DbgPrint("user: PE reject header extent=%llu\n",(unsigned long long)header_need);
        DbgPrint("user: invalid or oversized PE headers: %s\n",name);
        return 0;
    }
    uint64_t header_pages=(header_need+0xFFFULL)>>12;
    uint64_t header_pa=pmm_alloc_n(header_pages);
    if(!header_pa) { DbgPrint("user: PE header allocation failed pages=%llu\n",(unsigned long long)header_pages); return 0; }
    uint8_t *headers=(uint8_t *)(HHDM_BASE+header_pa);
    for(uint64_t i=0;i<header_pages*USER_IMAGE_PAGE;i++)headers[i]=0;
    if(vfs_read_inode_at(ino,0,headers,header_need)!=(int)header_need) {
        for(uint64_t i=0;i<header_pages;i++)pmm_free(header_pa+i*USER_IMAGE_PAGE);
        return 0;
    }
    uint8_t *opt=headers+opt_off;
    uint32_t entry_rva=*(uint32_t *)(opt+16);
    uint64_t preferred=*(uint64_t *)(opt+24);
    uint32_t image_size=*(uint32_t *)(opt+56);
    uint32_t headers_size=*(uint32_t *)(opt+60);
    if (*(uint16_t *)opt!=0x20B || image_size<0x1000 ||
        !headers_size || headers_size>raw_size || headers_size>image_size ||
        entry_rva>=image_size) { DbgPrint("user: PE reject optional magic=%x image=%u headers=%u entry=%x raw=%llu\n",*(uint16_t *)opt,image_size,headers_size,entry_rva,(unsigned long long)raw_size); goto bad_headers; }

    uint64_t image_pages=((uint64_t)image_size+0xFFFULL)>>12;
    if(!image_pages || image_pages>UINT64_MAX/USER_IMAGE_PAGE)goto bad_headers;
    uint64_t image_pa=pmm_alloc_n(image_pages);
    if(!image_pa) { DbgPrint("user: PE image allocation failed pages=%llu bytes=%u\n",(unsigned long long)image_pages,image_size); goto bad_headers; }
    uint8_t *image=(uint8_t *)(HHDM_BASE+image_pa);
    for(uint64_t i=0;i<image_pages*USER_IMAGE_PAGE;i++)image[i]=0;
    if(vfs_read_inode_at(ino,0,image,headers_size)!=(int)headers_size) {
        for(uint64_t j=0;j<image_pages;j++)pmm_free(image_pa+j*USER_IMAGE_PAGE);
        goto bad_headers;
    }

    /* Stream each raw section in bounded chunks; ignore installer overlays. */
    for(uint16_t i=0;i<sections;i++) {
        uint8_t *sh=headers+sect_off+(uint64_t)i*40;
        uint32_t vsize=*(uint32_t *)(sh+8);
        uint32_t va=*(uint32_t *)(sh+12);
        uint32_t rawsz=*(uint32_t *)(sh+16);
        uint32_t rawoff=*(uint32_t *)(sh+20);
        uint32_t copy=rawsz;
        if(vsize && copy>vsize)copy=vsize;
        if(va>image_size || copy>image_size-va ||
           rawoff>raw_size || copy>raw_size-rawoff) {
            for(uint64_t j=0;j<image_pages;j++)pmm_free(image_pa+j*USER_IMAGE_PAGE);
            goto bad_headers;
        }
        uint32_t done=0;
        while(done<copy) {
            uint32_t chunk=copy-done;
            if(chunk>65536u)chunk=65536u;
            if(vfs_read_inode_at(ino,(uint64_t)rawoff+done,image+va+done,chunk)!=(int)chunk) {
                for(uint64_t j=0;j<image_pages;j++)pmm_free(image_pa+j*USER_IMAGE_PAGE);
                goto bad_headers;
            }
            done+=chunk;
        }
    }

    for(uint64_t i=0;i<header_pages;i++)pmm_free(header_pa+i*USER_IMAGE_PAGE);
    for(int i=0;i<USER_DISK_MODULE_MAX;i++)if(!user_disk_modules[i].used) {
        UserDiskModule *d=&user_disk_modules[i];
        d->used=1; d->owner=0; d->source_phys=image_pa;
        d->source_pages=image_pages;
        d->module.phys=image_pa; d->module.size=image_size;
        d->module.base=preferred?preferred:0x42000000ULL;
        d->module.entry=d->module.base+entry_rva;
        int n=0; for(;name[n]&&n<31;n++)d->module.name[n]=name[n];
        d->module.name[n]=0;
        for(n++;n<32;n++)d->module.name[n]=0;
        for (n=0;n<(int)sizeof(d->image_path)-1 && name[n];n++)
            d->image_path[n]=name[n];
        d->image_path[n]=0;
        for (n=0;n<(int)sizeof(d->dependency_name)-1 && name[n];n++)
            d->dependency_name[n]=name[n];
        d->dependency_name[n]=0;
        return d;
    }
    for(uint64_t i=0;i<image_pages;i++)pmm_free(image_pa+i*USER_IMAGE_PAGE);
    return 0;

bad_headers:
    for(uint64_t i=0;i<header_pages;i++)pmm_free(header_pa+i*USER_IMAGE_PAGE);
    return 0;
}

static BootModule *PspLoadProcessDiskDependency(KPROCESS *proc, const char *name) {
    if (!proc || !name || !name[0]) return 0;
    for (int i = 0; i < USER_DISK_MODULE_MAX; i++) {
        UserDiskModule *d = &user_disk_modules[i];
        if (!d->used || d->owner != proc) continue;
        const char *a = d->dependency_name[0] ? d->dependency_name : d->module.name, *b = name;
        int same = 1;
        for (int k = 0; a[k] || b[k]; k++) {
            char ca = a[k], cb = b[k];
            if (ca >= 'A' && ca <= 'Z') ca = (char)(ca + ('a' - 'A'));
            if (cb >= 'A' && cb <= 'Z') cb = (char)(cb + ('a' - 'A'));
            if (ca != cb) { same = 0; break; }
        }
        if (same) return &d->module;
    }
    UserDiskModule *d = PspLoadDiskModule(name, proc);
    if (!d) return 0;
    d->owner = proc;
    return &d->module;
}

typedef struct { uint16_t wYear,wMonth,wDayOfWeek,wDay,wHour,wMinute,wSecond,wMilliseconds; } UserSystemTime;
static uint8_t user_rtc_read(uint8_t reg) {
    uint8_t value;
    __asm__ volatile("outb %0, $0x70" : : "a"(reg));
    __asm__ volatile("inb $0x71, %0" : "=a"(value));
    return value;
}
static uint8_t user_rtc_decode(uint8_t value,int binary) {
    return binary?value:(uint8_t)((value&0x0Fu)+((value>>4)*10u));
}
static uint64_t user_boot_rtc_seconds;
static int user_boot_rtc_valid;
static int user_rtc_leap(uint32_t y){return (y%4u==0u&&y%100u!=0u)||y%400u==0u;}
static uint64_t user_rtc_epoch_seconds(const UserSystemTime *t){
    static const uint8_t md[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    if(!t||t->wYear<1970||t->wMonth<1||t->wMonth>12)return 0;
    uint64_t days=0;
    for(uint32_t y=1970;y<t->wYear;y++)days+=user_rtc_leap(y)?366u:365u;
    for(uint32_t m=1;m<t->wMonth;m++)days+=md[m-1]+(m==2&&user_rtc_leap(t->wYear));
    days+=t->wDay-1u;
    return days*86400u+(uint64_t)t->wHour*3600u+(uint64_t)t->wMinute*60u+t->wSecond;
}
static int user_rtc_system_time(UserSystemTime *out) {
    if(!out)return 0;
    int tries=100000;
    while((user_rtc_read(0x0A)&0x80u)&&--tries){}
    if(!tries)return 0;
    uint8_t sec=user_rtc_read(0x00),min=user_rtc_read(0x02),hour=user_rtc_read(0x04);
    uint8_t dow=user_rtc_read(0x06),day=user_rtc_read(0x07),month=user_rtc_read(0x08);
    uint8_t year=user_rtc_read(0x09),century=user_rtc_read(0x32),mode=user_rtc_read(0x0B);
    int binary=(mode&0x04u)!=0,pm=(hour&0x80u)!=0;
    hour&=0x7Fu;
    sec=user_rtc_decode(sec,binary);min=user_rtc_decode(min,binary);
    hour=user_rtc_decode(hour,binary);day=user_rtc_decode(day,binary);
    month=user_rtc_decode(month,binary);year=user_rtc_decode(year,binary);
    if(!(mode&0x02u)){hour=(uint8_t)(hour%12u+(pm?12u:0u));}
    if(century!=0&&century!=0xFFu){century=user_rtc_decode(century,binary);out->wYear=(uint16_t)(century*100u+year);}
    else out->wYear=(uint16_t)((year>=70u?1900u:2000u)+year);
    out->wMonth=month;out->wDay=day;out->wDayOfWeek=dow?((dow-1u)%7u):0;
    out->wHour=hour;out->wMinute=min;out->wSecond=sec;out->wMilliseconds=0;
    return month>=1&&month<=12&&day>=1&&day<=31&&hour<24&&min<60&&sec<60;
}


/* Shared software window compositor. USER32 surfaces are copied into kernel-owned
 * per-window backing stores; the shared GPU scanout is output-only. */
#define SYS_NtPresentLayer 37
/* Submit a window-local ARGB surface. Unlike the legacy full-screen layer
 * API, pixels are addressed from the window's own (0,0) origin. */
#define SYS_NtPresentWindowSurface 40
#define WM_LAYER_BACKGROUND 0
#define WM_LAYER_DESKTOP    1
#define WM_LAYER_WINDOW     2
#define WM_LAYER_TASKBAR    3
#define WM_COMP_MAX_PIXELS (1920u * 1080u)
typedef struct {
    uint64_t pixels;
    uint32_t layer, x, y, w, h, width, height;
} WmPresentLayerArgs;
typedef struct {
    uint64_t pixels;
    uint32_t x, y, w, h, width, height;
} WmPresentWindowSurfaceArgs;
static uint32_t *wm_shared_background;
/* Set only while tearing down a window: the old fullscreen owner must not
 * suppress the repaint that removes its former foreground window. */
static int wm_shared_force_compose;
static uint32_t *wm_shared_desktop;
static uint32_t *wm_shared_taskbar;
/* Legacy USER32 layers remain screen-sized; newer applications may submit
 * tightly packed window-local surfaces with independent dimensions. */
static uint32_t *wm_shared_windows[WM_MAX];
static uint32_t *wm_shared_local_windows[WM_MAX];
static uint32_t wm_shared_local_width[WM_MAX],wm_shared_local_height[WM_MAX];
static uint32_t wm_shared_width, wm_shared_height;
/* Set once the desktop has published the full wallpaper layer; until then the
 * kernel compositor does not own the pointer (login/boot screens draw directly). */
static int wm_shared_bg_published;
static uint32_t wm_shared_alpha(uint32_t dst, uint32_t src) {
    uint32_t a=src>>24;
    if(!a)return dst;
    if(a==255u)return src;
    uint32_t ia=255u-a;
    uint32_t r=(((src>>16)&255u)*a+((dst>>16)&255u)*ia)/255u;
    uint32_t g=(((src>>8)&255u)*a+((dst>>8)&255u)*ia)/255u;
    uint32_t b=((src&255u)*a+(dst&255u)*ia)/255u;
    return 0xFF000000u|(r<<16)|(g<<8)|b;
}
static int wm_shared_ensure(uint32_t width,uint32_t height) {
    if(!width||!height||width>1920u||height>1080u||
       (uint64_t)width*height>WM_COMP_MAX_PIXELS)return 0;
    if(wm_shared_width==width&&wm_shared_height==height&&wm_shared_background&&
       wm_shared_desktop&&wm_shared_taskbar)return 1;
    uint64_t bytes=(uint64_t)width*height*sizeof(uint32_t);
    if(wm_shared_background)kfree(wm_shared_background);
    if(wm_shared_desktop)kfree(wm_shared_desktop);
    if(wm_shared_taskbar)kfree(wm_shared_taskbar);
    wm_shared_bg_published=0;
    wm_shared_background=kzalloc((size_t)bytes);
    wm_shared_desktop=kzalloc((size_t)bytes);
    wm_shared_taskbar=kzalloc((size_t)bytes);
    for(int i=0;i<WM_MAX;i++) {
        if(wm_shared_windows[i])kfree(wm_shared_windows[i]);
        wm_shared_windows[i]=0;
    }
    if(!wm_shared_background||!wm_shared_desktop||!wm_shared_taskbar) {
        if(wm_shared_background)kfree(wm_shared_background);
        if(wm_shared_desktop)kfree(wm_shared_desktop);
        if(wm_shared_taskbar)kfree(wm_shared_taskbar);
        wm_shared_background=wm_shared_desktop=wm_shared_taskbar=0;
        wm_shared_width=wm_shared_height=0;
        return 0;
    }
    wm_shared_width=width;wm_shared_height=height;
    return 1;
}
static int wm_shared_window_slot(int pid) {
    for(int i=0;i<WM_MAX;i++)
        if(wm_tab[i].alive&&wm_tab[i].pid==pid)return i;
    return -1;
}
/* Bounded serial diagnostics: detailed startup events plus periodic samples. */
static uint64_t wm_dbg_compose_calls, wm_dbg_present_calls;
static uint64_t wm_dbg_window_moves, wm_dbg_window_registers, wm_dbg_window_closes;
static int wm_dbg_sample(uint64_t n) { return n <= 48u || (n % 128u) == 0u; }
static uint64_t wm_dbg_input_events;
static void wm_dbg_input(int pid,int type,int x,int y,int btn,char key) {
    uint64_t n=++wm_dbg_input_events;
    if(!wm_dbg_sample(n))return;
    if(type==1)
        DbgPrint("[input] #%llu pid=%d key='%c' mouse=(%d,%d) buttons=%d\n",
                 (unsigned long long)n,pid,key,x,y,btn);
    else
        DbgPrint("[input] #%llu pid=%d %s mouse=(%d,%d) buttons=%d\n",
                 (unsigned long long)n,pid,type==3?"click":"move",x,y,btn);
}

/* ------------------------------------------------------------------
 * Kernel-owned system pointer.
 *
 * Every USER32 process used to paint its own CPU cursor straight into the
 * shared scanout with a private save-under buffer.  When focus moved to
 * another window, the previous process never erased its pointer and the new
 * process saved that stale pointer as its "background", so each window left
 * a ghost mouse behind.  The pointer now lives here, next to the compositor
 * that already rebuilds every damaged rectangle from the persistent layers:
 * it is blended last on every compose, so there is exactly one pointer and
 * nothing to restore, and therefore nothing to trail.
 * ------------------------------------------------------------------ */
#define WM_CURSOR_W 16
#define WM_CURSOR_H 16
static const char wm_cursor_default_shape[WM_CURSOR_H][WM_CURSOR_W+1] = {
    "##..............",
    "#w#.............",
    "#ww#............",
    "#www#...........",
    "#wwww#..........",
    "#wwwww#.........",
    "#wwwwww#........",
    "#wwwwwww#.......",
    "#wwwwwwww#......",
    "#wwwwwwwwww#....",
    "#wwwwwwwwwwww#..",
    "#wwwwwwwwwwww#..",
    "#wwwwwwwwww#....",
    "#ww#wwwwww#.....",
    "#w#..#wwww#.....",
    "##.............."
};
static uint32_t wm_cursor_pixels[WM_CURSOR_W*WM_CURSOR_H]; /* ARGB, alpha 0 = clear */
static int wm_cursor_ready;              /* wm_cursor_pixels holds a bitmap */
static uint32_t wm_cursor_shape_id=32512u; /* IDC_ARROW until USER32 says otherwise */
static int wm_cursor_x=-64, wm_cursor_y=-64; /* where the pointer is composed */
static int wm_cursor_hidden, wm_cursor_hidden_pid;
static int wm_cursor_suspended;          /* shutdown screen etc.: never draw */
static int wm_cursor_app_owned;          /* a fullscreen app owns the scanout */

static void wm_cursor_init_default(void) {
    if(wm_cursor_ready)return;
    for(int j=0;j<WM_CURSOR_H;j++)
        for(int i=0;i<WM_CURSOR_W;i++) {
            char c=wm_cursor_default_shape[j][i];
            wm_cursor_pixels[j*WM_CURSOR_W+i]=
                c=='#'?0xFF000000u:(c=='w'?0xFFF1F3F6u:0u);
        }
    wm_cursor_ready=1;
}
/* A process that hid the pointer (games) only hides it while it is the
 * active window, so a crashed or minimized game can never leave the desktop
 * without a pointer. */
static int wm_cursor_effective_hidden(void) {
    if(wm_cursor_suspended)return 1;
    if(!wm_cursor_hidden)return 0;
    return wm_cursor_hidden_pid==wm_get_active_pid();
}
/* Blend the pointer over the part of [x,x+w)x[y,y+h) it covers. */
static void wm_cursor_overlay(uint32_t *out,uint32_t pitch,uint32_t x,uint32_t y,
                              uint32_t w,uint32_t h,uint32_t width,uint32_t height) {
    if(!wm_shared_bg_published||wm_cursor_effective_hidden())return;
    wm_cursor_init_default();
    int64_t x0=wm_cursor_x,y0=wm_cursor_y;
    int64_t x1=x0+WM_CURSOR_W,y1=y0+WM_CURSOR_H;
    if(x0<(int64_t)x)x0=x;
    if(y0<(int64_t)y)y0=y;
    if(x1>(int64_t)x+w)x1=(int64_t)x+w;
    if(y1>(int64_t)y+h)y1=(int64_t)y+h;
    if(x1>(int64_t)width)x1=width;
    if(y1>(int64_t)height)y1=height;
    if(x0<0)x0=0;
    if(y0<0)y0=0;
    if(x1<=x0||y1<=y0)return;
    for(int64_t yy=y0;yy<y1;yy++) {
        uint32_t *dstrow=out+(uint32_t)yy*pitch;
        const uint32_t *srcrow=&wm_cursor_pixels[(yy-wm_cursor_y)*WM_CURSOR_W];
        for(int64_t xx=x0;xx<x1;xx++) {
            uint32_t px=srcrow[xx-wm_cursor_x];
            if(px>>24)dstrow[xx]=wm_shared_alpha(dstrow[xx],px);
        }
    }
}
static void wm_shared_compose(uint32_t x,uint32_t y,uint32_t w,uint32_t h);
/* Recompose the pointer-sized rectangle at (px,py); the compositor redraws
 * the scene there and blends the pointer on top, so the old footprint is
 * erased from the real layers rather than from a saved copy. */
static void wm_cursor_compose_at(int px,int py,int pw,int ph) {
    int64_t x0=px,y0=py,x1=(int64_t)px+pw,y1=(int64_t)py+ph;
    if(x0<0)x0=0;
    if(y0<0)y0=0;
    if(x1>(int64_t)wm_shared_width)x1=wm_shared_width;
    if(y1>(int64_t)wm_shared_height)y1=wm_shared_height;
    if(x1<=x0||y1<=y0)return;
    wm_shared_compose((uint32_t)x0,(uint32_t)y0,(uint32_t)(x1-x0),(uint32_t)(y1-y0));
}
static void wm_cursor_refresh(void) {
    wm_cursor_compose_at(wm_cursor_x,wm_cursor_y,WM_CURSOR_W,WM_CURSOR_H);
}
/* Follow the hardware pointer.  Called from the input syscall, so it runs
 * no matter which process happens to poll; ownership never changes hands. */
static void wm_cursor_track(int nx,int ny) {
    if(!wm_shared_bg_published||!wm_shared_width||!wm_shared_height)return;
    if(nx<0)nx=0;
    if(ny<0)ny=0;
    if(nx>=(int)wm_shared_width)nx=(int)wm_shared_width-1;
    if(ny>=(int)wm_shared_height)ny=(int)wm_shared_height-1;
    if(nx==wm_cursor_x&&ny==wm_cursor_y)return;
    int ox=wm_cursor_x,oy=wm_cursor_y;
    wm_cursor_x=nx;
    wm_cursor_y=ny;
    if(wm_cursor_effective_hidden())return;
    int dx=nx>ox?nx-ox:ox-nx,dy=ny>oy?ny-oy:oy-ny;
    if(dx<WM_CURSOR_W&&dy<WM_CURSOR_H) {
        /* Old and new footprints overlap: one compose, one flush. */
        int ux=nx<ox?nx:ox,uy=ny<oy?ny:oy;
        wm_cursor_compose_at(ux,uy,WM_CURSOR_W+dx,WM_CURSOR_H+dy);
    } else {
        wm_cursor_compose_at(nx,ny,WM_CURSOR_W,WM_CURSOR_H);
        wm_cursor_compose_at(ox,oy,WM_CURSOR_W,WM_CURSOR_H);
    }
}

static void wm_shared_compose(uint32_t x,uint32_t y,uint32_t w,uint32_t h) {
    if(!wm_shared_background||!gfx_surface_pa||!gfx_width||!gfx_height)return;
    uint32_t width=wm_shared_width,height=wm_shared_height;
    if(width!=gfx_width||height!=gfx_height)return;
    if(x>=width||y>=height||!w||!h)return;
    /* Clamp damage before any x+w/y+h arithmetic or pixel addressing.
     * Present requests and window-move unions are user-influenced; a clipped
     * rectangle must never wrap around and write beyond the GPU surface. */
    if(w>width-x)w=width-x;
    if(h>height-y)h=height-y;
    if(!w||!h)return;

    /*
     * Fullscreen applications such as Maze draw directly to the shared
     * scanout and flush their own frames. A later taskbar/window-layer update
     * must not rebuild the desktop over that frame, or the game flickers
     * between its own pixels and the desktop. Treat a screen-covering,
     * frontmost window as temporarily owning scanout. Its normal window
     * registration is still retained, so unregister/exit allows composition
     * to resume and restore the desktop/taskbar.
     */
    int fullscreen_slot=-1;
    unsigned long long fullscreen_z=0;
    for(int i=0;i<WM_MAX;i++) {
        WmEntry *e=&wm_tab[i];
        if(!e->alive||e->minimized||e->w<=0||e->h<=0)continue;
        /* Local-surface apps must always pass through composition; they do
         * not own the shared scanout even when their window covers the screen. */
        if(wm_shared_local_windows[i])continue;
        if(e->x<=0&&e->y<=0&&
           (uint64_t)e->w+12u>=width&&
           (uint64_t)e->h+16u>=height&&
           (fullscreen_slot<0||e->z>fullscreen_z)) {
            fullscreen_slot=i;
            fullscreen_z=e->z;
        }
    }
    if(fullscreen_slot>=0) {
        int covered_by_newer=0;
        for(int i=0;i<WM_MAX;i++) {
            WmEntry *e=&wm_tab[i];
            if(e->alive&&!e->minimized&&e->z>fullscreen_z) {
                covered_by_newer=1;
                break;
            }
        }
        if(!covered_by_newer&&!wm_shared_force_compose){wm_cursor_app_owned=1;return;}
    }
    if(w>width-x)w=width-x;if(h>height-y)h=height-y;
    KPROCESS *old=MmCurrentProcess;
    if(old!=PspSystemProcess)MmSwitchToProcess(PspSystemProcess);
    uint32_t *out=(uint32_t*)PHYS_TO_VIRT(gfx_surface_pa);
    uint32_t pitch=gfx_pitch/4u;

    /* A fullscreen app using PresentWindowSurface owns the visible scanout
     * while it is the frontmost window. Do not rebuild the desktop/taskbar
     * over it: desktop repaint requests can arrive after the app's frame and
     * otherwise leave Explorer visible while the game runs behind it. Local
     * surfaces are tightly packed and independent of the shared scanout. */
    int local_fullscreen=-1;
    unsigned long long local_fullscreen_z=0;
    for(int i=0;i<WM_MAX;i++) {
        WmEntry *e=&wm_tab[i];
        if(!e->alive||e->minimized||!wm_shared_local_windows[i])continue;
        if(e->x>0||e->y>0||
           wm_shared_local_width[i]<width||
           wm_shared_local_height[i]<height)continue;
        if(local_fullscreen<0||e->z>local_fullscreen_z) {
            local_fullscreen=i;
            local_fullscreen_z=e->z;
        }
    }
    if(local_fullscreen>=0) {
        int covered=0;
        for(int i=0;i<WM_MAX;i++) {
            WmEntry *e=&wm_tab[i];
            if(e->alive&&!e->minimized&&e->z>local_fullscreen_z) {
                covered=1;break;
            }
        }
        if(!covered&&!wm_shared_force_compose) {
            wm_cursor_app_owned=1;
            uint32_t *src=wm_shared_local_windows[local_fullscreen];
            uint32_t sw=wm_shared_local_width[local_fullscreen];
            for(uint32_t yy=y;yy<y+h;yy++) {
                uint32_t *dstrow=out+yy*pitch;
                uint32_t *srcrow=src+yy*sw;
                for(uint32_t xx=x;xx<x+w;xx++)dstrow[xx]=srcrow[xx];
            }
            int flush_ok=gfx_flush(x,y,w,h);
    (void)flush_ok;
            (void)flush_ok;
            if(old&&old!=PspSystemProcess)MmSwitchToProcess(old);
            return;
        }
    }

    wm_cursor_app_owned=0;
    /* Consume the window manager's canonical back-to-front order.
     * Surface slots are process-owned; resolve each copied entry back to its
     * slot only after the order snapshot has been obtained. */
    int order[WM_MAX],count=0;
    for(int rank=0;rank<WM_MAX;rank++) {
        WmEntry entry;
        if(!wm_get_z_order(rank,&entry))break;
        int slot=wm_shared_window_slot(entry.pid);
        if(slot<0||(!wm_shared_windows[slot]&&!wm_shared_local_windows[slot]))continue;
        order[count++]=slot;
    }
    uint64_t dbg_n=++wm_dbg_compose_calls;
    static uint64_t wm_dbg_composed_pixels;
    uint64_t damage_pixels=(uint64_t)w*(uint64_t)h;
    wm_dbg_composed_pixels+=damage_pixels;
    (void)wm_dbg_composed_pixels;
    if(x==0&&y==0&&w==width&&h==height) {
        SENTINEL_GFX_LOG("[gfx] full-screen compose #%llu pixels=%llu total=%llu\n",
                 (unsigned long long)dbg_n,
                 (unsigned long long)damage_pixels,
                 (unsigned long long)wm_dbg_composed_pixels);
    }
    if(wm_dbg_sample(dbg_n)) {
        SENTINEL_GFX_LOG("[gfx] compose #%llu damage=(%u,%u %ux%u) windows=%d pitch=%u\n",
                 (unsigned long long)dbg_n,x,y,w,h,count,pitch);
        for(int oi=0;oi<count;oi++) {
            WmEntry *e=&wm_tab[order[oi]];
            (void)e;
            SENTINEL_GFX_LOG("[gfx]   z[%d] pid=%d rect=(%d,%d %dx%d) minimized=%d\n",
                     oi,e->pid,e->x,e->y,e->w,e->h,e->minimized);
        }
    }
    /* First rebuild the damaged rectangle from the two static layers.
     * Then overlay each window only where its frame intersects the damage.
     * This avoids the old O(damage_pixels * window_count) hit-test loop:
     * pixels outside every window no longer pay for every window's bounds. */
    for(uint32_t yy=y;yy<y+h;yy++) {
        uint32_t row=yy*width;
        uint32_t *dstrow=out+yy*pitch;
        for(uint32_t xx=x;xx<x+w;xx++) {
            uint32_t at=row+xx;
            dstrow[xx]=wm_shared_alpha(wm_shared_background[at],
                                       wm_shared_desktop[at]);
        }
    }
    static uint64_t wm_dbg_window_overlay_pixels;
    uint64_t window_overlay_pixels=0;
    for(int oi=0;oi<count;oi++) {
        int slot=order[oi];
        WmEntry *e=&wm_tab[slot];
        /* Legacy USER32 presents screen-space layers including non-client
         * decoration. Local surfaces instead map (0,0) to the window origin. */
        int local=wm_shared_local_windows[slot]!=0;
        int64_t left=local?(int64_t)e->x:(int64_t)e->x-12;
        int64_t top=local?(int64_t)e->y:(int64_t)e->y-12;
        int64_t right=local?(int64_t)e->x+wm_shared_local_width[slot]:(int64_t)e->x+(int64_t)e->w+12;
        int64_t bottom=local?(int64_t)e->y+wm_shared_local_height[slot]:(int64_t)e->y+(int64_t)e->h+16;
        if(left<(int64_t)x)left=x;
        if(top<(int64_t)y)top=y;
        if(right>(int64_t)x+w)right=(int64_t)x+w;
        if(bottom>(int64_t)y+h)bottom=(int64_t)y+h;
        if(left<0)left=0;
        if(top<0)top=0;
        if(right>(int64_t)width)right=width;
        if(bottom>(int64_t)height)bottom=height;
        if(right<=left||bottom<=top)continue;
        window_overlay_pixels+=(uint64_t)(right-left)*(uint64_t)(bottom-top);
        uint32_t *surface=local?wm_shared_local_windows[slot]:wm_shared_windows[slot];
        uint32_t sw=local?wm_shared_local_width[slot]:width;
        for(uint32_t yy=(uint32_t)top;yy<(uint32_t)bottom;yy++) {
            uint32_t *dstrow=out+yy*pitch;
            uint32_t sy=local?(uint32_t)((int64_t)yy-e->y):yy;
            for(uint32_t xx=(uint32_t)left;xx<(uint32_t)right;xx++) {
                uint32_t sx=local?(uint32_t)((int64_t)xx-e->x):xx;
                uint32_t at=local?sy*sw+sx:yy*width+xx;
                dstrow[xx]=wm_shared_alpha(dstrow[xx],surface[at]);
            }
        }
    }
    wm_dbg_window_overlay_pixels+=window_overlay_pixels;
    (void)wm_dbg_window_overlay_pixels;
    if(wm_dbg_sample(dbg_n))
        SENTINEL_GFX_LOG("[gfx] overlay-work #%llu pixels=%llu cumulative=%llu\n",
                 (unsigned long long)dbg_n,
                 (unsigned long long)window_overlay_pixels,
                 (unsigned long long)wm_dbg_window_overlay_pixels);
    /* Taskbar remains the top layer and is blended only once per damaged pixel. */
    for(uint32_t yy=y;yy<y+h;yy++) {
        uint32_t row=yy*width;
        uint32_t *dstrow=out+yy*pitch;
        for(uint32_t xx=x;xx<x+w;xx++) {
            uint32_t at=row+xx;
            dstrow[xx]=wm_shared_alpha(dstrow[xx],wm_shared_taskbar[at]);
        }
    }
    /* The system pointer is the topmost layer: blended after the taskbar and
     * before the flush, so every repaint of this rectangle is pointer-correct. */
    wm_cursor_overlay(out,pitch,x,y,w,h,width,height);
    int flush_ok=gfx_flush(x,y,w,h);
    if(wm_dbg_sample(dbg_n))
        SENTINEL_GFX_LOG("[gfx] flush damage=(%u,%u %ux%u) result=%d\n",x,y,w,h,flush_ok);
    if(old&&old!=PspSystemProcess)MmSwitchToProcess(old);
}


#define SYS_NtSocketCreate 44
#define SYS_NtSocketClose  45
#define SYS_NtSocketBind   46
#define SYS_NtSocketSendTo 47
#define SYS_NtSocketRecvFrom 48
#define SYS_NtSocketConnect 56
#define SYS_NtSocketSend 57
#define SYS_NtSocketRecv 58
#define NT_SOCKET_BASE 0x534F0000ULL
#define NT_SOCKET_STATUS_INVALID_HANDLE (-1LL)
#define NT_SOCKET_STATUS_INVALID_PARAMETER (-2LL)
#define NT_SOCKET_STATUS_WOULD_BLOCK (-3LL)
#define NT_SOCKET_STATUS_ADDRESS_IN_USE (-4LL)
#define NT_SOCKET_STATUS_NETWORK_UNREACHABLE (-5LL)
#define NT_SOCKET_STATUS_MESSAGE_TOO_LARGE (-6LL)
#define NT_SOCKET_STATUS_NO_BUFFERS (-7LL)
#define NT_SOCKET_STATUS_TIMED_OUT (-8LL)
#define NT_SOCKET_STATUS_CONNECTION_RESET (-9LL)
#define NT_SOCKET_STATUS_NOT_CONNECTED (-10LL)
#define NT_SOCKET_STATUS_ALREADY_CONNECTED (-11LL)
typedef struct { int used; int owner_pid; int type; uint16_t local_port; uint32_t peer_addr; uint16_t peer_port; } NT_SOCKET_SLOT;
static NT_SOCKET_SLOT nt_socket_slots[32];
static uint16_t nt_socket_ephemeral_next=49152;

static int NtSocketDecode(uint64_t h) {
    if(h<=NT_SOCKET_BASE || h>NT_SOCKET_BASE+32) return -1;
    int i=(int)(h-NT_SOCKET_BASE-1);
    if(!nt_socket_slots[i].used || !MmCurrentProcess ||
       nt_socket_slots[i].owner_pid!=(int)MmCurrentProcess->Pid) return -1;
    return i;
}
static int NtSocketAllocatePort(int socket_index,uint16_t *out_port) {
    if(!out_port)return -1;
    const uint32_t first=49152u,last=65535u,count=last-first+1u;
    for(uint32_t n=0;n<count;n++) {
        uint16_t candidate=nt_socket_ephemeral_next;
        nt_socket_ephemeral_next=(uint16_t)(candidate==65535u?first:(uint32_t)candidate+1u);
        int busy=0;
        for(int j=0;j<32;j++)if(j!=socket_index&&nt_socket_slots[j].used&&nt_socket_slots[j].local_port==candidate){busy=1;break;}
        if(busy)continue;
        if(nt_socket_slots[socket_index].type==2&&NetUdpBindExclusive(candidate)<0)continue;
        nt_socket_slots[socket_index].local_port=candidate;*out_port=candidate;return 0;
    }
    return -1;
}

static Frame *syscall_handler(Frame *f) {
    NetPoll(); /* service Ethernet RX while user processes make kernel calls */
    switch (f->rax) {
    case SYS_NtNetworkInfo: {
        if(!f->rdi||!MmValidateUserRange(MmCurrentProcess,f->rdi,sizeof(NT_NETWORK_INFO),1)) { f->rax=0; return f; }
        NT_NETWORK_INFO *out=(NT_NETWORK_INFO *)(uint64_t)f->rdi;
        out->ip=net_ipv4_addr; out->mask=net_ipv4_mask; out->gateway=net_ipv4_gateway; out->dns=net_dns_server;
        out->dhcp_state=(uint32_t)net_dhcp_state; out->link_up=(uint32_t)e1000_ready;
        for(unsigned i=0;i<6;i++)out->mac[i]=e1000_mac[i]; out->reserved=0; f->rax=1; return f;
    }
    case SYS_NtPing: {
        uint32_t ip=(uint32_t)f->rdi, reply=0, polls=0;
        int result=NetPing(ip,&reply,&polls);
        if(f->rsi && MmValidateUserRange(MmCurrentProcess,f->rsi,sizeof(uint32_t),1)) *(uint32_t *)(uint64_t)f->rsi=reply;
        if(f->rdx && MmValidateUserRange(MmCurrentProcess,f->rdx,sizeof(uint32_t),1)) *(uint32_t *)(uint64_t)f->rdx=polls;
        f->rax=(uint64_t)(int64_t)result; return f;
    }
    case SYS_NtSocketCreate: {
        int af=(int)f->rdi, type=(int)f->rsi, proto=(int)f->rdx;
        if(af!=2 || (type!=1 && type!=2) || (proto && proto!=(type==2?17:6))) { f->rax=(uint64_t)-1LL; return f; }
        for(int i=0;i<32;i++) if(!nt_socket_slots[i].used) {
            nt_socket_slots[i]=(NT_SOCKET_SLOT){.used=1,.owner_pid=MmCurrentProcess?(int)MmCurrentProcess->Pid:-1,.type=type};
            f->rax=NT_SOCKET_BASE+(uint64_t)i+1; return f;
        }
        f->rax=(uint64_t)-1LL; return f;
    }
    case SYS_NtSocketClose: {
        int i=NtSocketDecode(f->rdi);
        if(i<0) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_HANDLE; return f; }
        if(nt_socket_slots[i].type==1){int rc=NetTcpClose((unsigned)i);if(rc==-8){f->rax=(uint64_t)NT_SOCKET_STATUS_TIMED_OUT;goto socket_close_done;}if(rc==-9){f->rax=(uint64_t)NT_SOCKET_STATUS_CONNECTION_RESET;goto socket_close_done;}}
        uint16_t port=nt_socket_slots[i].local_port;
        nt_socket_slots[i].used=0;
        if(port&&nt_socket_slots[i].type==2){int shared=0;for(int j=0;j<32;j++)if(nt_socket_slots[j].used&&nt_socket_slots[j].local_port==port)shared=1;if(!shared)NetUdpUnbind(port);}
socket_close_done:
        if(f->rax==(uint64_t)NT_SOCKET_STATUS_TIMED_OUT||f->rax==(uint64_t)NT_SOCKET_STATUS_CONNECTION_RESET){uint16_t close_port=nt_socket_slots[i].local_port;int close_type=nt_socket_slots[i].type;nt_socket_slots[i].used=0;if(close_type==2&&close_port)NetUdpUnbind(close_port);return f;}
        f->rax=0; return f;
    }
    case SYS_NtSocketBind: {
        int i=NtSocketDecode(f->rdi);
        if(i<0) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_HANDLE; return f; }
        if((nt_socket_slots[i].type!=1&&nt_socket_slots[i].type!=2)||nt_socket_slots[i].local_port||!f->rsi||f->rdx<16||
           !MmValidateUserRange(MmCurrentProcess,f->rsi,16,0)) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
        const uint8_t *sa=(const uint8_t *)(uint64_t)f->rsi;
        uint16_t family=*(const uint16_t *)sa;
        uint16_t port=(uint16_t)(((uint16_t)sa[2]<<8)|sa[3]);
        uint32_t local_addr=*(const uint32_t *)(sa+4);
        if(family!=2||!port||(local_addr&&local_addr!=net_ipv4_addr)) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
        for(int j=0;j<32;j++)if(j!=i&&nt_socket_slots[j].used&&nt_socket_slots[j].local_port==port){f->rax=(uint64_t)NT_SOCKET_STATUS_ADDRESS_IN_USE;return f;}
        if(nt_socket_slots[i].type==2&&NetUdpBindExclusive(port)<0) { f->rax=(uint64_t)NT_SOCKET_STATUS_ADDRESS_IN_USE; return f; }
        nt_socket_slots[i].local_port=port; f->rax=0; return f;
    }
    case SYS_NtSocketConnect: {
        int i=NtSocketDecode(f->rdi);
        if(i<0) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_HANDLE; return f; }
        if(nt_socket_slots[i].type!=1||nt_socket_slots[i].peer_addr||!f->rsi||f->rdx<16||
           !MmValidateUserRange(MmCurrentProcess,f->rsi,16,0)) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
        const uint8_t *sa=(const uint8_t *)(uint64_t)f->rsi;
        uint16_t family=*(const uint16_t *)sa,port=(uint16_t)(((uint16_t)sa[2]<<8)|sa[3]);
        uint32_t ip=*(const uint32_t *)(sa+4);
        if(family!=2||!port||!ip) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
        uint16_t local=nt_socket_slots[i].local_port;
        if(!local&&NtSocketAllocatePort(i,&local)<0){f->rax=(uint64_t)NT_SOCKET_STATUS_NO_BUFFERS;return f;}
        int rc=NetTcpConnect((unsigned)i,local,ip,port);
        if(rc==-8){f->rax=(uint64_t)NT_SOCKET_STATUS_TIMED_OUT;return f;}
        if(rc==-9){f->rax=(uint64_t)NT_SOCKET_STATUS_CONNECTION_RESET;return f;}
        if(rc==-7){f->rax=(uint64_t)NT_SOCKET_STATUS_NO_BUFFERS;return f;}
        if(rc==-5){f->rax=(uint64_t)NT_SOCKET_STATUS_NETWORK_UNREACHABLE;return f;}
        if(rc<0){f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER;return f;}
        nt_socket_slots[i].peer_addr=ip;nt_socket_slots[i].peer_port=port;
        f->rax=0;return f;
    }
    case SYS_NtSocketSend: {
        int i=NtSocketDecode(f->rdi);
        if(i<0){f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_HANDLE;return f;}
        if(f->rdx>65535u){f->rax=(uint64_t)NT_SOCKET_STATUS_MESSAGE_TOO_LARGE;return f;}
        if(nt_socket_slots[i].type!=1||!nt_socket_slots[i].peer_addr) { f->rax=(uint64_t)NT_SOCKET_STATUS_NOT_CONNECTED; return f; }
        if((!f->rsi&&f->rdx)||(f->rdx&&!MmValidateUserRange(MmCurrentProcess,f->rsi,f->rdx,0))) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
        int rc=NetTcpSend((unsigned)i,(const void *)(uint64_t)f->rsi,(unsigned)f->rdx);
        if(rc==-8){f->rax=(uint64_t)NT_SOCKET_STATUS_TIMED_OUT;return f;}
        if(rc==-9){f->rax=(uint64_t)NT_SOCKET_STATUS_CONNECTION_RESET;return f;}
        if(rc==-10){f->rax=(uint64_t)NT_SOCKET_STATUS_NOT_CONNECTED;return f;}
        if(rc==-7){f->rax=(uint64_t)NT_SOCKET_STATUS_NO_BUFFERS;return f;}
        if(rc<0){f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER;return f;}
        f->rax=(uint64_t)(int64_t)rc;return f;
    }
    case SYS_NtSocketRecv: {
        int i=NtSocketDecode(f->rdi);
        if(i<0){f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_HANDLE;return f;}
        if(f->rdx>65535u){f->rax=(uint64_t)NT_SOCKET_STATUS_MESSAGE_TOO_LARGE;return f;}
        if(nt_socket_slots[i].type!=1||!nt_socket_slots[i].peer_addr) { f->rax=(uint64_t)NT_SOCKET_STATUS_NOT_CONNECTED; return f; }
        if((!f->rsi&&f->rdx)||(f->rdx&&!MmValidateUserRange(MmCurrentProcess,f->rsi,f->rdx,1))) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
        int rc=NetTcpReceive((unsigned)i,(void *)(uint64_t)f->rsi,(unsigned)f->rdx);
        if(rc==-8){f->rax=(uint64_t)NT_SOCKET_STATUS_TIMED_OUT;return f;}
        if(rc==-9){f->rax=(uint64_t)NT_SOCKET_STATUS_CONNECTION_RESET;return f;}
        if(rc==-10){f->rax=(uint64_t)NT_SOCKET_STATUS_NOT_CONNECTED;return f;}
        if(rc==-7){f->rax=(uint64_t)NT_SOCKET_STATUS_NO_BUFFERS;return f;}
        if(rc<0){f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER;return f;}
        f->rax=(uint64_t)(int64_t)rc;return f;
    }
    case SYS_NtSocketSendTo: {
        int i=NtSocketDecode(f->rdi);
        if(i<0) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_HANDLE; return f; }
        if(f->rdx>NET_UDP_DATA_MAX) { f->rax=(uint64_t)NT_SOCKET_STATUS_MESSAGE_TOO_LARGE; return f; }
        if(nt_socket_slots[i].type!=2||(!f->rsi&&f->rdx)||
           (f->rdx&&!MmValidateUserRange(MmCurrentProcess,f->rsi,f->rdx,0))||
           !f->r8||f->r9<16||!MmValidateUserRange(MmCurrentProcess,f->r8,16,0)) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
        const uint8_t *sa=(const uint8_t *)(uint64_t)f->r8;
        if(*(const uint16_t *)sa!=2) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
        uint16_t port=(uint16_t)(((uint16_t)sa[2]<<8)|sa[3]);
        uint32_t ip=*(const uint32_t *)(sa+4);
        if(!port||!ip) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
        uint16_t local=nt_socket_slots[i].local_port;
        if(!local&&NtSocketAllocatePort(i,&local)<0){f->rax=(uint64_t)NT_SOCKET_STATUS_NO_BUFFERS;return f;}
        if(!nt_socket_slots[i].local_port)nt_socket_slots[i].local_port=local;
        int sent=NetUdpSend(ip,local,port,(const void *)(uint64_t)f->rsi,(unsigned)f->rdx);
        if(sent==-3){f->rax=(uint64_t)NT_SOCKET_STATUS_WOULD_BLOCK;return f;}
        if(sent==-4){f->rax=(uint64_t)NT_SOCKET_STATUS_NO_BUFFERS;return f;}
        if(sent<0){f->rax=(uint64_t)NT_SOCKET_STATUS_NETWORK_UNREACHABLE;return f;}
        f->rax=(uint64_t)(int64_t)sent; return f;
    }
    case SYS_NtSocketRecvFrom: {
        int i=NtSocketDecode(f->rdi);
        if(i<0) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_HANDLE; return f; }
        if(nt_socket_slots[i].type!=2||!nt_socket_slots[i].local_port||(!f->rsi&&f->rdx)||f->rdx>65535||
           (f->rdx&&!MmValidateUserRange(MmCurrentProcess,f->rsi,f->rdx,1))||
           (!!f->r8!=!!f->r9)) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
        int *addrlen=0;
        if(f->r8){
            if(f->r9<sizeof(int)||!MmValidateUserRange(MmCurrentProcess,f->r8,16,1)||
               !MmValidateUserRange(MmCurrentProcess,f->r9,sizeof(int),1)) { f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER; return f; }
            addrlen=(int *)(uint64_t)f->r9;
            if(*addrlen<16){*addrlen=16;f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER;return f;}
        }
        NetPoll();
        uint32_t source_ip=0; uint16_t source_port=0;
        int got=NetUdpReceiveFrom(nt_socket_slots[i].local_port,(void *)(uint64_t)f->rsi,(unsigned)f->rdx,&source_ip,&source_port);
        if(got==-2){f->rax=(uint64_t)NT_SOCKET_STATUS_WOULD_BLOCK;return f;}
        if(got==-6){f->rax=(uint64_t)NT_SOCKET_STATUS_MESSAGE_TOO_LARGE;return f;}
        if(got<0){f->rax=(uint64_t)NT_SOCKET_STATUS_INVALID_PARAMETER;return f;}
        if(f->r8 && addrlen) {
            uint8_t *sa=(uint8_t *)(uint64_t)f->r8;
            for(unsigned j=0;j<16;j++)sa[j]=0;
            *(uint16_t *)sa=2; sa[2]=(uint8_t)(source_port>>8); sa[3]=(uint8_t)source_port;
            *(uint32_t *)(sa+4)=source_ip;
            *addrlen=16;
        }
        f->rax=(uint64_t)(int64_t)got; return f;
    }
    case NT_SYS_QUERY_INFORMATION_PROCESS: {
        if ((NT_HANDLE)f->rdi != NT_CURRENT_PROCESS ||
            f->rsi != NT_PROCESS_BASIC_INFORMATION_CLASS ||
            f->rcx < sizeof(NT_PROCESS_BASIC_INFORMATION)) {
            f->rax = NtStatusResult(
                (NT_HANDLE)f->rdi != NT_CURRENT_PROCESS
                    ? NT_STATUS_INVALID_HANDLE
                    : (f->rsi != NT_PROCESS_BASIC_INFORMATION_CLASS
                        ? NT_STATUS_INVALID_PARAMETER
                        : NT_STATUS_INFO_LENGTH_MISMATCH));
            return f;
        }

        if (!MmValidateUserRange(MmCurrentProcess, f->rdx,
                                 sizeof(NT_PROCESS_BASIC_INFORMATION), 1) ||
            (f->r8 && !MmValidateUserRange(MmCurrentProcess, f->r8,
                                           sizeof(NT_ULONG), 1))) {
            f->rax = NtStatusResult(NT_STATUS_ACCESS_VIOLATION);
            return f;
        }

        NT_PROCESS_BASIC_INFORMATION info;
        info.ExitStatus = NT_STATUS_SUCCESS;
        info.PebBaseAddress = 0;
        info.AffinityMask = 1;
        info.BasePriority = 8;
        info.UniqueProcessId = MmCurrentProcess ? MmCurrentProcess->Pid : 0;
        info.InheritedFromUniqueProcessId = 0;

        int me = up_find_proc(MmCurrentProcess);
        if (me >= 0) {
            int parent = up_tab[me].parent;
            if (parent >= 0 && parent < UP_MAX &&
                up_tab[parent].alive && up_tab[parent].proc)
                info.InheritedFromUniqueProcessId = up_tab[parent].proc->Pid;
        }

        *(NT_PROCESS_BASIC_INFORMATION *)f->rdx = info;
        if (f->r8) *(NT_ULONG *)f->r8 = sizeof info;
        f->rax = NtStatusResult(NT_STATUS_SUCCESS);
        return f;
    }

    case NT_SYS_ALLOCATE_VIRTUAL_MEMORY: {
        if ((NT_HANDLE)f->rdi != NT_CURRENT_PROCESS) {
            f->rax = NtStatusResult(NT_STATUS_INVALID_HANDLE);
            return f;
        }
        if (f->rdx != 0) {
            f->rax = NtStatusResult(NT_STATUS_INVALID_PARAMETER);
            return f;
        }
        if (!f->rsi || !f->rcx ||
            !MmValidateUserRange(MmCurrentProcess, f->rsi, sizeof(uint64_t), 1) ||
            !MmValidateUserRange(MmCurrentProcess, f->rcx, sizeof(uint64_t), 1)) {
            f->rax = NtStatusResult(NT_STATUS_ACCESS_VIOLATION);
            return f;
        }

        uint64_t base = *(uint64_t *)f->rsi;
        uint64_t requested = *(uint64_t *)f->rcx;
        uint64_t alloc_type = f->r8;
        uint64_t protect = f->r9;
        if (!requested || requested > UINT64_MAX - 0xFFFULL ||
            requested > 16ull * 1024 * 1024 ||
            (alloc_type & ~(NT_MEM_RESERVE | NT_MEM_COMMIT)) != 0 ||
            (alloc_type & (NT_MEM_RESERVE | NT_MEM_COMMIT)) !=
                (NT_MEM_RESERVE | NT_MEM_COMMIT) ||
            protect != NT_PAGE_READWRITE) {
            f->rax = NtStatusResult(NT_STATUS_INVALID_PARAMETER);
            return f;
        }

        uint64_t size = (requested + 0xFFFULL) & ~0xFFFULL;
        if (!base) base = 0x50000000ULL;
        if ((base & 0xFFFULL) || base < 0x10000ULL ||
            base >= 0x0000800000000000ULL ||
            size > 0x0000800000000000ULL - base) {
            f->rax = NtStatusResult(NT_STATUS_INVALID_ADDRESS);
            return f;
        }

        KPROCESS *caller = MmCurrentProcess;
        if (!caller || caller == PspSystemProcess) {
            f->rax = NtStatusResult(NT_STATUS_INVALID_HANDLE);
            return f;
        }

        MmSwitchToProcess(PspSystemProcess);
        if (!MmUserRangeUnmapped(caller, base, size)) {
            MmSwitchToProcess(caller);
            f->rax = NtStatusResult(NT_STATUS_INVALID_ADDRESS);
            return f;
        }

        uint64_t mapped = 0;
        for (; mapped < size; mapped += USER_IMAGE_PAGE) {
            if (!MmMapAllocatedUserPage(caller, base + mapped)) break;
        }
        if (mapped != size) {
            while (mapped) {
                mapped -= USER_IMAGE_PAGE;
                MmUnmapAllocatedUserPage(caller, base + mapped);
            }
            MmSwitchToProcess(caller);
            f->rax = NtStatusResult(NT_STATUS_NO_MEMORY);
            return f;
        }

        MmSwitchToProcess(caller);
        *(uint64_t *)f->rsi = base;
        *(uint64_t *)f->rcx = size;
        f->rax = NtStatusResult(NT_STATUS_SUCCESS);
        return f;
    }

    case NT_SYS_YIELD_EXECUTION: {
        int me = up_find_proc(MmCurrentProcess);
        if (me >= 0) {
            up_save(f, me);
            up_tab[me].rax = 0;
        }
        int next = up_pick_next();
        if (next >= 0 && next != me) {
            up_load(f, next);
            return f;
        }
        f->rax = NtStatusResult(NT_STATUS_SUCCESS);
        return f;
    }

    case NT_SYS_QUERY_VIRTUAL_MEMORY: {
        if ((NT_HANDLE)f->rdi != NT_CURRENT_PROCESS) {
            f->rax = NtStatusResult(NT_STATUS_INVALID_HANDLE);
            return f;
        }
        if (f->rdx != NT_MEMORY_BASIC_INFORMATION_CLASS ||
            f->r8 < sizeof(NT_MEMORY_BASIC_INFORMATION)) {
            f->rax = NtStatusResult(
                f->rdx != NT_MEMORY_BASIC_INFORMATION_CLASS
                    ? NT_STATUS_INVALID_PARAMETER
                    : NT_STATUS_INFO_LENGTH_MISMATCH);
            return f;
        }
        if (!MmValidateUserRange(MmCurrentProcess, f->rcx,
                                 sizeof(NT_MEMORY_BASIC_INFORMATION), 1) ||
            (f->r9 && !MmValidateUserRange(MmCurrentProcess, f->r9,
                                           sizeof(NT_ULONG), 1))) {
            f->rax = NtStatusResult(NT_STATUS_ACCESS_VIOLATION);
            return f;
        }

        uint64_t va = f->rsi;
        uint64_t pte = MmLookupUserPte(MmCurrentProcess, va, 0);
        if (!pte) {
            f->rax = NtStatusResult(NT_STATUS_INVALID_ADDRESS);
            return f;
        }

        NT_MEMORY_BASIC_INFORMATION info;
        info.BaseAddress = (NT_PVOID)(va & ~0xFFFULL);
        info.AllocationBase = info.BaseAddress;
        info.AllocationProtect = NT_PAGE_READWRITE;
        info.PartitionId = 0;
        info.RegionSize = 0x1000;
        info.State = NT_MEM_COMMITTED;
        info.Protect = (pte & PTE_RW) ? NT_PAGE_READWRITE : NT_PAGE_READONLY;
        info.Type = NT_MEM_PRIVATE;
        *(NT_MEMORY_BASIC_INFORMATION *)f->rcx = info;
        if (f->r9) *(NT_ULONG *)f->r9 = sizeof info;
        f->rax = NtStatusResult(NT_STATUS_SUCCESS);
        return f;
    }


    case SYS_NtPresentLayer: {
        WmPresentLayerArgs a;
        if(!f->rdi||!MmValidateUserRange(MmCurrentProcess,f->rdi,sizeof(a),0)) {
            f->rax=0;return f;
        }
        a=*(WmPresentLayerArgs*)f->rdi;
        uint64_t dbg_n=++wm_dbg_present_calls;
        uint64_t pixels=(uint64_t)a.width*a.height;
        uint64_t bytes=pixels*sizeof(uint32_t);
        if(!a.pixels||!a.width||!a.height||a.width>1920u||a.height>1080u||
           pixels>WM_COMP_MAX_PIXELS||a.layer>WM_LAYER_TASKBAR||
           !MmValidateUserRange(MmCurrentProcess,a.pixels,bytes,0)||
           a.width!=gfx_width||a.height!=gfx_height) {
            if(wm_dbg_sample(dbg_n))
                SENTINEL_GFX_LOG("[gfx] present #%llu REJECT layer=%u rect=(%u,%u %ux%u) surface=%ux%u gfx=%ux%u pixels=%p\n",
                         (unsigned long long)dbg_n,a.layer,a.x,a.y,a.w,a.h,
                         a.width,a.height,gfx_width,gfx_height,(void*)a.pixels);
            f->rax=0;return f;
        }
        int pid=MmCurrentProcess?(int)MmCurrentProcess->Pid:0;
        if(wm_dbg_sample(dbg_n))
            SENTINEL_GFX_LOG("[gfx] present #%llu pid=%d layer=%u rect=(%u,%u %ux%u) surface=%ux%u\n",
                     (unsigned long long)dbg_n,pid,a.layer,a.x,a.y,a.w,a.h,a.width,a.height);
        int slot=wm_shared_window_slot(pid);
        KPROCESS *caller=MmCurrentProcess;
        if(caller!=PspSystemProcess)MmSwitchToProcess(PspSystemProcess);
        int ok=wm_shared_ensure(a.width,a.height);
        if(ok&&a.layer==WM_LAYER_WINDOW) {
            if(slot<0)ok=0;
            else if(!wm_shared_windows[slot])wm_shared_windows[slot]=kzalloc((size_t)bytes);
            if(slot>=0&&!wm_shared_windows[slot])ok=0;
        }
        if(caller!=PspSystemProcess)MmSwitchToProcess(caller);
        if(!ok){f->rax=0;return f;}
        if(a.x>=a.width||a.y>=a.height||!a.w||!a.h){f->rax=1;return f;}
        if(a.w>a.width-a.x)a.w=a.width-a.x;
        if(a.h>a.height-a.y)a.h=a.height-a.y;
        uint32_t *src=(uint32_t*)a.pixels;
        uint32_t *dst=0;
        if(a.layer==WM_LAYER_BACKGROUND)dst=wm_shared_background;
        else if(a.layer==WM_LAYER_DESKTOP)dst=wm_shared_desktop;
        else if(a.layer==WM_LAYER_TASKBAR)dst=wm_shared_taskbar;
        else if(slot>=0)dst=wm_shared_windows[slot];
        if(!dst){
            if(wm_dbg_sample(dbg_n))
                SENTINEL_GFX_LOG("[gfx] present #%llu REJECT no destination pid=%d layer=%u slot=%d\n",
                         (unsigned long long)dbg_n,pid,a.layer,slot);
            f->rax=0;return f;
        }
        for(uint32_t yy=a.y;yy<a.y+a.h;yy++)
            for(uint32_t xx=a.x;xx<a.x+a.w;xx++)
                dst[yy*a.width+xx]=src[yy*a.width+xx];
        if(a.layer==WM_LAYER_BACKGROUND&&a.x==0&&a.y==0&&a.w==a.width&&a.h==a.height)
            wm_shared_bg_published=1;
        /* The desktop publishes its desktop/window/taskbar layers in order.
         * Composing the window layer here and then composing the taskbar layer
         * immediately afterwards sends the same damaged rectangle to the GPU
         * twice. Defer only the Desktop owner's window-layer present; its
         * taskbar-layer present is the frame commit. Ordinary app windows still
         * present immediately, and the cursor/taskbar path remains unchanged. */
        int desktop_owner = slot >= 0 &&
            wm_tab[slot].title[0] == 'D' &&
            wm_tab[slot].title[1] == 'e' &&
            wm_tab[slot].title[2] == 's' &&
            wm_tab[slot].title[3] == 'k' &&
            wm_tab[slot].title[4] == 't' &&
            wm_tab[slot].title[5] == 'o' &&
            wm_tab[slot].title[6] == 'p' &&
            wm_tab[slot].title[7] == 0;
        if(a.layer==WM_LAYER_TASKBAR ||
           (a.layer==WM_LAYER_WINDOW && !desktop_owner))
            wm_shared_compose(a.x,a.y,a.w,a.h);
        if(wm_dbg_sample(dbg_n))
            SENTINEL_GFX_LOG("[gfx] present #%llu ACCEPT pid=%d layer=%u damage=(%u,%u %ux%u)\n",
                     (unsigned long long)dbg_n,pid,a.layer,a.x,a.y,a.w,a.h);
        f->rax=1;
        return f;
    }

    case SYS_NtPresentWindowSurface: {
        WmPresentWindowSurfaceArgs a;
        if(!f->rdi||!MmValidateUserRange(MmCurrentProcess,f->rdi,sizeof(a),0)) {
            f->rax=0;return f;
        }
        a=*(WmPresentWindowSurfaceArgs*)f->rdi;
        uint64_t pixels=(uint64_t)a.width*a.height;
        uint64_t bytes=pixels*sizeof(uint32_t);
        int pid=MmCurrentProcess?(int)MmCurrentProcess->Pid:0;
        int slot=wm_shared_window_slot(pid);
        /* Keep the rejection reason visible on serial: a failed local-surface
         * present otherwise leaves a newly-created window looking blank and
         * gives user-mode no way to distinguish a bad pointer from a size or
         * window-registration mismatch. Do not index wm_tab until slot is valid. */
        int reject=0;
        if(slot<0) reject=1;
        else if(!a.pixels) reject=2;
        else if(!a.width||!a.height) reject=3;
        else if(a.width>1920u||a.height>1080u||pixels>WM_COMP_MAX_PIXELS) reject=4;
        else if(wm_tab[slot].w<=0||wm_tab[slot].h<=0||
                a.width>(uint32_t)wm_tab[slot].w||
                a.height>(uint32_t)wm_tab[slot].h) reject=5;
        else if(!MmValidateUserRange(MmCurrentProcess,a.pixels,bytes,0)) reject=6;
        else if(!gfx_width||!gfx_height) reject=7;
        else if(a.x>=a.width||a.y>=a.height||!a.w||!a.h) reject=8;
        if(reject) {
            static uint64_t wm_dbg_local_rejects;
            uint64_t n=++wm_dbg_local_rejects;
            if(wm_dbg_sample(n))
                DbgPrint("[wm] local surface rejected #%llu pid=%d reason=%d slot=%d size=%ux%u window=%dx%d pixels=%p gpu=%ux%u damage=(%u,%u %ux%u)\n",
                         (unsigned long long)n,pid,reject,slot,a.width,a.height,
                         slot>=0?wm_tab[slot].w:0,slot>=0?wm_tab[slot].h:0,
                         (void*)a.pixels,gfx_width,gfx_height,a.x,a.y,a.w,a.h);
            f->rax=0;return f;
        }
        if(a.w>a.width-a.x)a.w=a.width-a.x;
        if(a.h>a.height-a.y)a.h=a.height-a.y;
        if((uint64_t)a.width*a.height*4ULL>SIZE_MAX) { f->rax=0;return f; }
        KPROCESS *caller=MmCurrentProcess;
        if(caller!=PspSystemProcess)MmSwitchToProcess(PspSystemProcess);
        if(!wm_shared_ensure(gfx_width,gfx_height)) {
            if(caller!=PspSystemProcess)MmSwitchToProcess(caller);
            f->rax=0;return f;
        }
        uint32_t *surface=wm_shared_local_windows[slot];
        if(!surface||wm_shared_local_width[slot]!=a.width||
           wm_shared_local_height[slot]!=a.height) {
            uint32_t *replacement=kzalloc((size_t)bytes);
            if(!replacement) {
                if(caller!=PspSystemProcess)MmSwitchToProcess(caller);
                f->rax=0;return f;
            }
            if(surface)kfree(surface);
            surface=replacement;
            wm_shared_local_windows[slot]=surface;
            wm_shared_local_width[slot]=a.width;
            wm_shared_local_height[slot]=a.height;
        }
        /* A process has one active surface representation. Drop its legacy
         * screen-sized buffer to avoid retaining two full-resolution images. */
        if(wm_shared_windows[slot]) {
            kfree(wm_shared_windows[slot]);
            wm_shared_windows[slot]=0;
        }
        /* The source is a user virtual address. Restore the caller's CR3
         * before dereferencing it; the system process page tables do not map
         * this process's private image/buffers. Kernel heap mappings are shared
         * in the kernel half, so the destination surface remains accessible. */
        if(caller!=PspSystemProcess)MmSwitchToProcess(caller);
        uint32_t *src=(uint32_t*)a.pixels;
        for(uint32_t yy=a.y;yy<a.y+a.h;yy++)
            for(uint32_t xx=a.x;xx<a.x+a.w;xx++)
                surface[yy*a.width+xx]=src[yy*a.width+xx];
        WmEntry *e=&wm_tab[slot];
        int64_t sx=(int64_t)e->x+a.x,sy=(int64_t)e->y+a.y;
        if(sx<0){uint32_t trim=(uint32_t)(-sx);if(trim>=a.w){f->rax=1;return f;}a.w-=trim;sx=0;}
        if(sy<0){uint32_t trim=(uint32_t)(-sy);if(trim>=a.h){f->rax=1;return f;}a.h-=trim;sy=0;}
        if(sx>=(int64_t)wm_shared_width||sy>=(int64_t)wm_shared_height){f->rax=1;return f;}
        if(a.w>wm_shared_width-(uint32_t)sx)a.w=wm_shared_width-(uint32_t)sx;
        if(a.h>wm_shared_height-(uint32_t)sy)a.h=wm_shared_height-(uint32_t)sy;
        if(a.w&&a.h)wm_shared_compose((uint32_t)sx,(uint32_t)sy,a.w,a.h);
        f->rax=1;
        return f;
    }

    case SYS_NtTerminateProcess: {
        DbgPrint("[user] exit");

        KPROCESS *dying = MmCurrentProcess;
        int dead_idx = up_find_proc(dying);
        int parent_idx = (dead_idx >= 0) ? up_tab[dead_idx].parent : -1;

        ut_exit_current();

        if (dying && dying != PspSystemProcess) {
            int dead_pid=(int)dying->Pid;
            int dead_slot=wm_shared_window_slot(dead_pid);
            int dx=0,dy=0,dw=(int)wm_shared_width,dh=(int)wm_shared_height;
            if(dead_slot>=0) {
                dx=wm_tab[dead_slot].x-12;dy=wm_tab[dead_slot].y-12;
                dw=wm_tab[dead_slot].w+24;dh=wm_tab[dead_slot].h+28;
            }
            MmSwitchToProcess(PspSystemProcess);
            if(dead_slot>=0&&wm_shared_windows[dead_slot]) {
                kfree(wm_shared_windows[dead_slot]);wm_shared_windows[dead_slot]=0;
            }
            if(dead_slot>=0&&wm_shared_local_windows[dead_slot]) {
                kfree(wm_shared_local_windows[dead_slot]);wm_shared_local_windows[dead_slot]=0;
                wm_shared_local_width[dead_slot]=wm_shared_local_height[dead_slot]=0;
            }
            wm_unregister(dead_pid);
            if(dx<0){dw+=dx;dx=0;}if(dy<0){dh+=dy;dy=0;}
            /* If the process already unregistered its window, there is no
             * stale window rectangle to repaint. Avoid a needless full-screen
             * compose on the exit path; it can stall interactive input/rendering. */
            /* A closed window must never leave pixels behind: always rebuild the
             * whole scanout from the remaining live layers, forced, whether or
             * not the process unregistered its window before exiting. */
            if(wm_shared_width&&wm_shared_height) {
                wm_shared_force_compose=1;
                wm_shared_compose(0,0,wm_shared_width,wm_shared_height);
                wm_shared_force_compose=0;
            } else if(dead_slot>=0&&dw>0&&dh>0)
                wm_shared_compose((uint32_t)dx,(uint32_t)dy,(uint32_t)dw,(uint32_t)dh);

            for (int i = 0; i < UP_MAX; i++) {
                if (up_tab[i].proc == dying) {
                    up_tab[i].alive = 0;
                    up_tab[i].parent = -1;
                }
            }

            /* No thread may resume in an address space after its exit. */
            MmSwitchToProcess(PspSystemProcess);
            if (ki_current) ki_current->Process = PspSystemProcess;
            for (int i = 0; i < UT_MAX; i++) {
                if (ut_tab[i].proc == dying) {
                    ut_tab[i].alive = 0;
                    ut_tab[i].proc = 0;
                }
            }
            PspForgetUserImages(dying);
            PspForgetDiskModule(dying);
            user_vm_forget_process(dying);
            MmDeleteAddressSpace(dying);
        }

        int nxt = -1;

        if (parent_idx >= 0 && parent_idx < UP_MAX &&
            up_tab[parent_idx].alive && up_tab[parent_idx].proc) {
            nxt = parent_idx;
        }

        if (nxt < 0)
            nxt = up_pick_next();

        if (nxt >= 0) {
            DbgPrint("user: switch process");
            up_load(f, nxt);
            return f;
        }

        DbgPrint("user: no process left");
        MmSwitchToProcess(PspSystemProcess);

        for (;;) __asm__ volatile("cli; hlt");
    }

    case SYS_NtWriteFile: {
        uint64_t uaddr = f->rsi;
        uint64_t len = f->rdx;

        if (len <= 4096 &&
            MmValidateUserRange(MmCurrentProcess, uaddr, len, 0)) {
            for (uint64_t i = 0; i < len; i++) {
                char c = ((const char *)uaddr)[i];
                if (!c) break;
                serial_putc(c);
            }

            f->rax = len;
        } else {
            f->rax = (uint64_t)-1LL;
        }

        return f;
    }

    case SYS_NtGetCurrentProcessId:
        f->rax = MmCurrentProcess ? MmCurrentProcess->Pid : 0;
        return f;

    case SYS_NtAllocateVirtualMemory: {
        KPROCESS *caller = MmCurrentProcess;
        uint64_t prefer = f->rdi;
        uint64_t requested = f->rsi;
        uint64_t protect = f->rdx ? f->rdx : 0x04ULL;

        if (!caller || caller == PspSystemProcess ||
            requested > UINT64_MAX - 0xFFFULL) {
            f->rax = 0;
            return f;
        }

        uint64_t size = (requested + 0xFFFULL) & ~0xFFFULL;
        if(protect!=0x02ULL&&protect!=0x04ULL&&protect!=0x20ULL&&protect!=0x40ULL){f->rax=0;return f;}
        /* Per-request virtual-memory ceiling: 128 GiB. This is not a promise
           that physical RAM exists; the physical-page check below rejects
           requests that cannot be backed while preserving the kernel reserve. */
        const uint64_t max_user_allocation = 128ull * 1024 * 1024 * 1024;
        if (!size || size > max_user_allocation) {
            f->rax = 0;
            return f;
        }

        int automatic_address=(prefer==0);
        if (!prefer) prefer = 0x50000000ULL;
        /* The current automatic-address arena is 0x50000000..0x60000000.
           Avoid unsigned underflow for allocations larger than that arena;
           callers needing larger ranges must provide a suitable base. */
        if (automatic_address && size > 0x10000000ULL) {
            f->rax = 0;
            return f;
        }
        if ((prefer & 0xFFFULL) || prefer < 0x10000ULL ||
            prefer >= 0x0000800000000000ULL ||
            size > 0x0000800000000000ULL - prefer) {
            f->rax = 0;
            return f;
        }

        /* Validate and allocate while the system CR3 provides the physical
           identity map used by the PMM. Never replace an existing mapping.
           Large user allocations must not consume the kernel's last physical
           pages: an allocation that fails only after mapping thousands of
           pages can leave the machine under severe memory pressure during
           rollback and process teardown. Keep a 64 MiB reserve for the kernel,
           graphics compositor, input, and scheduler when requests are >=4 MiB. */
        MmSwitchToProcess(PspSystemProcess);
        if (size >= 4ull * 1024 * 1024) {
            uint64_t need_pages = size / USER_IMAGE_PAGE;
            uint64_t reserve_pages = 64ull * 1024 * 1024 / USER_IMAGE_PAGE;
            if (pmm_free_pages() <= need_pages + reserve_pages) {
                MmSwitchToProcess(caller);
                f->rax = 0;
                return f;
            }
        }
        if(automatic_address) {
            uint64_t candidate=0x50000000ULL;
            uint64_t limit=0x60000000ULL-size;
            for(;candidate<=limit;candidate+=USER_IMAGE_PAGE)
                if(MmUserRangeUnmapped(caller,candidate,size))break;
            if(candidate>limit) {
                MmSwitchToProcess(caller);f->rax=0;return f;
            }
            prefer=candidate;
        }
        if (!MmUserRangeUnmapped(caller, prefer, size)) {
            MmSwitchToProcess(caller);
            f->rax = 0;
            return f;
        }

        uint64_t mapped = 0;
        for (; mapped < size; mapped += USER_IMAGE_PAGE) {
            if (!MmMapAllocatedUserPage(caller, prefer + mapped)) break;
        }

        if (mapped != size) {
            while (mapped) {
                mapped -= USER_IMAGE_PAGE;
                MmUnmapAllocatedUserPage(caller, prefer + mapped);
            }
            MmSwitchToProcess(caller);
            f->rax = 0;
            return f;
        }
        if(protect==0x02ULL||protect==0x20ULL) {
            for(uint64_t off=0;off<size;off+=USER_IMAGE_PAGE)user_vm_set_page_writable(caller,prefer+off,0);
        }

        int alloc_slot=-1;
        for(int i=0;i<USER_VM_ALLOCATION_MAX;i++)if(!user_vm_allocations[i].used){alloc_slot=i;break;}
        if(alloc_slot<0) {
            while(mapped){mapped-=USER_IMAGE_PAGE;MmUnmapAllocatedUserPage(caller,prefer+mapped);}
            MmSwitchToProcess(caller);f->rax=0;return f;
        }
        user_vm_allocations[alloc_slot].process=caller;
        user_vm_allocations[alloc_slot].base=prefer;
        user_vm_allocations[alloc_slot].size=size;
        user_vm_allocations[alloc_slot].allocation_protect=(uint32_t)protect;
        user_vm_allocations[alloc_slot].used=1;
        MmSwitchToProcess(caller);
        f->rax = prefer;
        return f;
    }

    case SYS_NtCreateProcess: {
        char name[160];
        char child_arg[64];
        child_arg[0] = 0;
        int has_child_arg = 0;

        if (copy_user_str(f->rdi, name, sizeof name) != 0) {
            f->rax = (uint64_t)-1LL;
            return f;
        }
        if (f->rsi && copy_user_str(f->rsi, child_arg, sizeof child_arg) == 0)
            has_child_arg = 1;

        KPROCESS *caller = MmCurrentProcess;

        /*
         * Never execute a file by an explicit path into System32. System
         * components are launched by their approved basename during startup;
         * this prevents browsing to C:\\magic\\System32 and clicking an EXE
         * from starting another copy of a protected OS component.
         */
        if (PspIsExplicitSystemPath(name)) {
            DbgPrint("user: denied explicit system-directory execution: %s\\n", name);
            f->rax = (uint64_t)-2LL;
            return f;
        }

        /*
         * System applications are a protected launch class. User applications
         * may launch ordinary applications, but only a system application may
         * launch smss.exe, bootvid.exe, or sentlogon.exe.
         */
        if (PspIsProtectedLaunchName(name) && !PspIsSystemProcess(caller)) {
            DbgPrint("user: denied system-app launch: target=%s\n", name);
            /* Win32 callers get the subsystem-incompatibility dialog. */
            f->rax = (uint64_t)-2LL;
            return f;
        }

        /* Kernel allocation and page-table work under the system CR3. */
        MmSwitchToProcess(PspSystemProcess);

        BootModule *mod = PspFindModule(user_bootinfo, name);
        UserDiskModule *disk_mod = 0;
        if (!mod) {
            disk_mod = PspLoadDiskModule(name, 0);
            if (disk_mod) mod = &disk_mod->module;
        }

        if (!mod) {
            DbgPrint("user: process image load failed: %s\n", name);
            MmSwitchToProcess(caller);
            f->rax = (uint64_t)-1LL;
            return f;
        }

        /* Only the protected native boot applications may use subsystem 1.
           Normal Win32 applications must be GUI (2) or console (3) images. */
        int subsystem = pe_get_subsystem(
            (const uint8_t *)(HHDM_BASE + mod->phys), mod->size);
        int protected_system_app = PspIsSystemAppName(name);
        if (subsystem < 0 ||
            (protected_system_app && subsystem != 1) ||
            (!protected_system_app && subsystem != 2 && subsystem != 3)) {
            DbgPrint("user: incompatible PE subsystem: %s (subsystem=%d)\n",
                     name, subsystem);
            if (disk_mod) PspFreeDiskModule(disk_mod);
            MmSwitchToProcess(caller);
            f->rax = (uint64_t)-2LL;
            return f;
        }

        KPROCESS *proc = MmCreateAddressSpace(name);

        if (!proc) {
            if (disk_mod) PspFreeDiskModule(disk_mod);
            MmSwitchToProcess(caller);
            f->rax = (uint64_t)-1LL;
            return f;
        }
        if (disk_mod) disk_mod->owner = proc;
        if (PspMapUserImage(proc, mod) != 0) {
            PspForgetUserImages(proc);
            MmDeleteAddressSpace(proc);
            if (disk_mod) PspFreeDiskModule(disk_mod);
            MmSwitchToProcess(caller);
            f->rax = (uint64_t)-1LL;
            return f;
        }

        pe_resolve_imports(proc, mod);

        UserImage *main_image = PspGetUserImage(proc, mod);

        /*
         * Do not start a process with unresolved imports. Previously the
         * resolver wrote zero IAT entries and the process later faulted at
         * RIP=0, obscuring the actual missing dependency.
         */
        if (main_image && main_image->import_failed) {
            DbgPrint("user: refusing to start '%s': unresolved PE imports\n",
                     name);
            PspForgetUserImages(proc);
            MmDeleteAddressSpace(proc);
            if (disk_mod) PspFreeDiskModule(disk_mod);
            MmSwitchToProcess(caller);
            f->rax = (uint64_t)-1LL;
            return f;
        }

        if (!main_image) {
            PspForgetUserImages(proc);
            MmDeleteAddressSpace(proc);
            if (disk_mod) PspFreeDiskModule(disk_mod);
            MmSwitchToProcess(caller);
            f->rax = (uint64_t)-1LL;
            return f;
        }

        uint64_t entry = main_image->entry;

        /* Map the child's 64 KiB stack plus the Windows x64 home/shadow-space
         * page above initial RSP. RSP starts at USER_STACK_TOP-8, so the
         * 32-byte home area crosses USER_STACK_TOP and must be mapped. */
        {
            uint64_t stack_sz = 0x10000ULL;
            uint64_t stack_lo = USER_STACK_TOP - stack_sz;

            for (uint64_t off = 0; off <= stack_sz; off += USER_IMAGE_PAGE) {
                uint64_t pa = pmm_alloc_zeroed();

                if (!pa) {
                    PspForgetUserImages(proc);
                    MmDeleteAddressSpace(proc);
                    if (disk_mod) PspFreeDiskModule(disk_mod);
                    MmSwitchToProcess(caller);
                    f->rax = (uint64_t)-1LL;
                    return f;
                }

                map_4k_in(proc->Pml4,
                          stack_lo + off, pa, PTE_U | PTE_RW | PTE_OWNED);
            }
        }

        if (!user_setup_teb(proc, USER_STACK_TOP - 0x10000ULL, USER_STACK_TOP)) {
            PspForgetUserImages(proc);
            MmDeleteAddressSpace(proc);
            if (disk_mod) PspFreeDiskModule(disk_mod);
            MmSwitchToProcess(caller);
            f->rax = (uint64_t)-1LL;
            return f;
        }

        /* Optional single command-line argument at a stable user VA. */
        if (has_child_arg && MmUserRangeUnmapped(proc, 0x6FF00000ULL, USER_IMAGE_PAGE)) {
            uint64_t arg_pa = pmm_alloc_zeroed();
            if (arg_pa) {
                map_4k_in(proc->Pml4, 0x6FF00000ULL, arg_pa,
                          PTE_U | PTE_RW | PTE_OWNED);
                char *arg_dst = (char *)(uintptr_t)arg_pa;
                for (int ai = 0; ai < 63 && child_arg[ai]; ai++)
                    arg_dst[ai] = child_arg[ai];
                arg_dst[63] = 0;
            }
        }

        if (up_find_proc(caller) < 0 && up_n < UP_MAX) {
            up_tab[up_n].parent = -1;
            up_tab[up_n].proc = caller;
            up_set_image_name(&up_tab[up_n], "unknown.exe");
            up_tab[up_n].entry = f->rip;
            up_tab[up_n].alive = 1;
            up_tab[up_n].fresh = 0;
            up_tab[up_n].rip = f->rip;
            up_tab[up_n].rsp = f->rsp;
            up_tab[up_n].rflags = f->rflags ? f->rflags : 0x202;
            up_tab[up_n].rax = proc->Pid;

            up_snap(f, &up_tab[up_n]);
            up_n++;
        } else {
            int me = up_find_proc(caller);

            if (me >= 0) {
                up_save(f, me);
                up_tab[me].rax = proc->Pid;
            }
        }

        if (up_n < UP_MAX) {
            up_tab[up_n].parent = up_find_proc(caller);
            up_tab[up_n].system_app = PspIsSystemAppName(name);
            up_tab[up_n].proc = proc;
            up_set_image_name(&up_tab[up_n], name);
            up_tab[up_n].entry = entry;
            up_tab[up_n].alive = 1;
            up_tab[up_n].fresh = 1;
            up_tab[up_n].rip = entry;
            up_tab[up_n].rsp = USER_STACK_TOP - sizeof(uint64_t);
            up_tab[up_n].rflags = 0x202;
            up_tab[up_n].rax = 0;
            up_n++;

        }

        {
            int ci = up_find_proc(proc);

            if (ci >= 0) {
                up_load(f, ci);
                f->rax = proc->Pid;
                return f;
            }
        }

        MmSwitchToProcess(caller);
        f->rax = proc->Pid;
        return f;
    }

    case SYS_NtGetApplicationError: {
        /* Deliver a kernel-owned crash record to the currently running UI
         * process. USER32 consumes it from GetMessageA, so a child launched
         * by File Explorer gets the same OS error dialog as one launched by
         * the desktop shell. The failed process never handles its own fault. */
        if (!MmCurrentProcess || MmCurrentProcess == PspSystemProcess ||
            !f->rdi ||
            !MmValidateUserRange(MmCurrentProcess, f->rdi,
                                 sizeof(UserApplicationError), 1)) {
            f->rax = 0;
            return f;
        }
        if (!user_app_error_count) {
            f->rax = 0;
            return f;
        }
        *(UserApplicationError *)(uintptr_t)f->rdi =
            user_app_errors[user_app_error_head];
        user_app_error_head = (user_app_error_head + 1u) % USER_APP_ERROR_QUEUE_SIZE;
        user_app_error_count--;
        f->rax = 1;
        return f;
    }

    case SYS_NtQueryProcessList: {
        uint64_t capacity = f->rsi;
        if (capacity > UP_MAX) capacity = UP_MAX;
        if (capacity && (!f->rdi ||
            !MmValidateUserRange(MmCurrentProcess, f->rdi,
                                 capacity * sizeof(UserProcessSnapshot), 1))) {
            f->rax = (uint64_t)-1LL;
            return f;
        }
        uint64_t total = 0;
        UserProcessSnapshot *out = (UserProcessSnapshot *)(uintptr_t)f->rdi;
        for (int i = 0; i < up_n; i++) {
            if (!up_tab[i].alive || !up_tab[i].proc) continue;
            if (total < capacity) {
                UserProcessSnapshot *row = &out[total];
                row->pid = up_tab[i].proc->Pid;
                row->parent_pid = 0;
                int parent = up_tab[i].parent;
                if (parent >= 0 && parent < up_n && up_tab[parent].alive &&
                    up_tab[parent].proc)
                    row->parent_pid = up_tab[parent].proc->Pid;
                row->state = up_tab[i].fresh ? 1u : 2u;
                row->reserved = 0;
                unsigned int j = 0;
                while (j < sizeof(row->image_name) - 1 &&
                       up_tab[i].image_name[j]) {
                    row->image_name[j] = up_tab[i].image_name[j];
                    j++;
                }
                row->image_name[j] = 0;
            }
            total++;
        }
        f->rax = total;
        return f;
    }

    case SYS_NtCreateOutputFile: {
        char name[64];
        if (copy_user_str(f->rdi, name, sizeof name) != 0) {
            f->rax = (uint64_t)-1LL;
            return f;
        }
        f->rax = (uint64_t)(int64_t)vfs_create_user_output_file(name);
        return f;
    }

    case SYS_NtWriteOutputFile:
        f->rax = (uint64_t)(int64_t)vfs_write_user_output_file(f->rdi, f->rsi, f->rdx);
        return f;

    case SYS_NtOpenFile: {
        char name[64];
        if (copy_user_str(f->rdi, name, sizeof name) != 0) {
            f->rax = (uint64_t)-1LL;
            return f;
        }
        f->rax = (uint64_t)(int64_t)vfs_open_user_file(name);
        return f;
    }

    case SYS_NtReadFile:
        f->rax = (uint64_t)(int64_t)vfs_read_user_file(f->rdi, f->rsi, f->rdx);
        return f;

    case SYS_NtCloseFile:
        f->rax = vfs_close_user_file(f->rdi);
        return f;

    case SYS_NtQueryFileSize: {
        KPROCESS *proc=MmCurrentProcess;
        OB_OBJECT *obj=proc?ObReferenceObjectByHandle((uintptr_t)proc->Pid,
            (OB_HANDLE)f->rdi,ObTypeFile,OB_ACCESS_READ):NULL;
        if(!obj){f->rax=(uint64_t)-1LL;return f;}
        VfsUserHandle *vh=(VfsUserHandle *)obj->body;
        f->rax=vh->used?vh->size:(uint64_t)-1LL;
        ObDereferenceObject(obj);
        return f;
    }

    case SYS_NtSetFilePosition: {
        KPROCESS *proc=MmCurrentProcess;
        OB_OBJECT *obj=proc?ObReferenceObjectByHandle((uintptr_t)proc->Pid,
            (OB_HANDLE)f->rdi,ObTypeFile,OB_ACCESS_READ):NULL;
        if(!obj){f->rax=(uint64_t)-1LL;return f;}
        VfsUserHandle *vh=(VfsUserHandle *)obj->body;
        if(!vh->used){ObDereferenceObject(obj);f->rax=(uint64_t)-1LL;return f;}
        int64_t offset=(int64_t)f->rsi;
        uint64_t base=0;
        if(f->rdx==1)base=vh->pos;
        else if(f->rdx==2)base=vh->size;
        else if(f->rdx!=0){ObDereferenceObject(obj);f->rax=(uint64_t)-1LL;return f;}
        uint64_t target;
        if(offset<0){uint64_t mag=(uint64_t)(-(offset+1))+1;if(mag>base){ObDereferenceObject(obj);f->rax=(uint64_t)-1LL;return f;}target=base-mag;}
        else {uint64_t mag=(uint64_t)offset;if(mag>0x7FFFFFFFFFFFFFFFULL-base){ObDereferenceObject(obj);f->rax=(uint64_t)-1LL;return f;}target=base+mag;}
        vh->pos=target;f->rax=vh->pos;ObDereferenceObject(obj);return f;
    }

    case SYS_NtFreeVirtualMemory: {
        KPROCESS *caller=MmCurrentProcess;
        uint64_t base=f->rdi,size=f->rsi,type=f->rdx;
        if(!caller||caller==PspSystemProcess||(base&0xFFFULL)||size!=0||type!=0x8000ULL) {f->rax=0;return f;}
        int slot=-1;
        for(int i=0;i<USER_VM_ALLOCATION_MAX;i++) {
            UserVmAllocation *a=&user_vm_allocations[i];
            if(a->used&&a->process==caller&&a->base==base){slot=i;break;}
        }
        if(slot<0){f->rax=0;return f;}
        UserVmAllocation *a=&user_vm_allocations[slot];
        MmSwitchToProcess(PspSystemProcess);
        int ok=1;
        for(uint64_t off=0;off<a->size;off+=USER_IMAGE_PAGE) {
            if(!MmUnmapAllocatedUserPage(caller,base+off)){ok=0;break;}
        }
        if(ok){a->used=0;a->process=0;a->base=0;a->size=0;}
        MmSwitchToProcess(caller);
        f->rax=ok?1:0;return f;
    }

    case SYS_NtProtectVirtualMemory: {
        KPROCESS *caller=MmCurrentProcess;
        uint64_t address=f->rdi,length=f->rsi,protect=f->rdx;
        if(!caller||caller==PspSystemProcess||!length||address>UINT64_MAX-length||
           (protect!=0x02ULL&&protect!=0x04ULL&&protect!=0x20ULL&&protect!=0x40ULL)) {f->rax=0;return f;}
        uint64_t start=address&~0xFFFULL,end=address+length;
        if(end>UINT64_MAX-0xFFFULL){f->rax=0;return f;}
        end=(end+0xFFFULL)&~0xFFFULL;
        if(end<=start){f->rax=0;return f;}
        UserVmAllocation *allocation=0;
        for(int i=0;i<USER_VM_ALLOCATION_MAX;i++) {
            UserVmAllocation *a=&user_vm_allocations[i];
            if(a->used&&a->process==caller&&start>=a->base&&end<=a->base+a->size){allocation=a;break;}
        }
        if(!allocation){f->rax=0;return f;}
        uint64_t first=MmLookupUserPte(caller,start,0);
        if(!(first&PTE_P)||!(first&PTE_U)||!(first&PTE_OWNED)){f->rax=0;return f;}
        uint64_t old_protect=(first&PTE_RW)?0x04ULL:0x02ULL;
        for(uint64_t page=start;page<end;page+=USER_IMAGE_PAGE) {
            uint64_t pte=MmLookupUserPte(caller,page,0);
            if(!(pte&PTE_P)||!(pte&PTE_U)||!(pte&PTE_OWNED)){f->rax=0;return f;}
        }
        int writable=(protect==0x04ULL||protect==0x40ULL);
        MmSwitchToProcess(PspSystemProcess);
        int ok=1;
        for(uint64_t page=start;page<end;page+=USER_IMAGE_PAGE)
            if(!user_vm_set_page_writable(caller,page,writable)){ok=0;break;}
        MmSwitchToProcess(caller);
        f->rax=ok?old_protect:0;return f;
    }

    case SYS_NtQueryVirtualMemory: {
        typedef struct {
            uint64_t BaseAddress,AllocationBase;
            uint32_t AllocationProtect;
            uint16_t PartitionId,Padding;
            uint64_t RegionSize;
            uint32_t State,Protect,Type,Padding2;
        } UserMemoryBasicInformation;
        KPROCESS *caller=MmCurrentProcess;
        uint64_t address=f->rdi,out=f->rsi,length=f->rdx;
        if(!caller||address>=0x0000800000000000ULL||
           length<sizeof(UserMemoryBasicInformation)||
           !MmValidateUserRange(caller,out,sizeof(UserMemoryBasicInformation),1)){f->rax=0;return f;}
        uint64_t page=address&~0xFFFULL,pte=MmLookupUserPte(caller,page,0);
        UserMemoryBasicInformation info={0};
        UserVmAllocation *allocation=0;
        for(int i=0;i<USER_VM_ALLOCATION_MAX;i++) {
            UserVmAllocation *a=&user_vm_allocations[i];
            if(a->used&&a->process==caller&&page>=a->base&&page<a->base+a->size){allocation=a;break;}
        }
        if(allocation&&pte) {
            uint32_t protect_now=(pte&PTE_RW)?0x04u:0x02u;
            uint64_t start=page,end=page+USER_IMAGE_PAGE,alloc_end=allocation->base+allocation->size;
            while(start>allocation->base) {
                uint64_t prev=MmLookupUserPte(caller,start-USER_IMAGE_PAGE,0);
                if(!prev||!(prev&PTE_OWNED)||(((prev&PTE_RW)?0x04u:0x02u)!=protect_now))break;
                start-=USER_IMAGE_PAGE;
            }
            while(end<alloc_end) {
                uint64_t next=MmLookupUserPte(caller,end,0);
                if(!next||!(next&PTE_OWNED)||(((next&PTE_RW)?0x04u:0x02u)!=protect_now))break;
                end+=USER_IMAGE_PAGE;
            }
            info.BaseAddress=start;info.AllocationBase=allocation->base;
            info.AllocationProtect=allocation->allocation_protect;info.RegionSize=end-start;
            info.State=0x1000u;info.Protect=protect_now;info.Type=0x20000u;
        } else if(pte) {
            info.BaseAddress=page;info.AllocationBase=page;info.AllocationProtect=(pte&PTE_RW)?0x04u:0x02u;
            info.RegionSize=USER_IMAGE_PAGE;info.State=0x1000u;info.Protect=(pte&PTE_RW)?0x04u:0x02u;
            info.Type=(pte&PTE_OWNED)?0x20000u:0x1000000u;
        } else {
            info.BaseAddress=page;info.AllocationBase=0;info.AllocationProtect=0;info.RegionSize=USER_IMAGE_PAGE;
            info.State=0x10000u;info.Protect=0;info.Type=0;
        }
        *(UserMemoryBasicInformation*)out=info;
        f->rax=sizeof(UserMemoryBasicInformation);return f;
    }

    case SYS_NtQueryVolumeMetadata: {
        uint64_t out=f->rdi,length=f->rsi;
        if(!g_ext4_ok||!g_ext4.blksz||length<sizeof(UserVolumeMetadata)||
           !MmValidateUserRange(MmCurrentProcess,out,sizeof(UserVolumeMetadata),1)){f->rax=0;return f;}
        UserVolumeMetadata meta={0};
        meta.total_blocks=g_ext4.total_blocks;meta.free_blocks=g_ext4.free_blocks;meta.reserved_blocks=g_ext4.reserved_blocks;
        meta.block_size=g_ext4.blksz;meta.volume_serial=g_ext4.volume_serial;meta.total_inodes=g_ext4.total_inodes;meta.free_inodes=g_ext4.free_inodes;
        for(int i=0;i<17;i++)meta.volume_label[i]=g_ext4.volume_label[i];
        *(UserVolumeMetadata*)out=meta;f->rax=1;return f;
    }

    case SYS_NtQueryFileMetadata: {
        uint64_t h=f->rdi,out=f->rsi,length=f->rdx;
        KPROCESS *proc=MmCurrentProcess;
        OB_OBJECT *obj=proc?ObReferenceObjectByHandle((uintptr_t)proc->Pid,
            (OB_HANDLE)h,ObTypeFile,OB_ACCESS_READ):NULL;
        if(!obj||length<sizeof(UserFileMetadata)||!MmValidateUserRange(proc,out,sizeof(UserFileMetadata),1)) {
            if(obj)ObDereferenceObject(obj);
            f->rax=0;return f;
        }
        VfsUserHandle *vh=(VfsUserHandle *)obj->body;uint8_t inode[256];
        if(!vh->used||!g_ext4_ok||e4_inode(&g_ext4,vh->ino,inode)<0){ObDereferenceObject(obj);f->rax=0;return f;}
        UserFileMetadata meta={0};
        meta.creation_time=0; /* legacy ext4 inode has no birth-time field */
        meta.access_time=user_filetime_from_unix(E32(inode,8));
        meta.write_time=user_filetime_from_unix(E32(inode,16));
        meta.change_time=user_filetime_from_unix(E32(inode,12));
        meta.size=e4_size(inode);meta.inode=vh->ino;meta.mode=E16(inode,0);meta.volume_serial=g_ext4.volume_serial;meta.links=E16(inode,26);
        *(UserFileMetadata*)out=meta;f->rax=1;ObDereferenceObject(obj);return f;
    }

    case SYS_NtQueryDirectoryFile: {
        uint32_t index = (uint32_t)f->rdi;
        char *name = (char *)f->rsi;
        uint64_t capacity = f->rdx;
        if (capacity < 2 || capacity > 256 ||
            !name || !MmValidateUserRange(MmCurrentProcess, (uint64_t)name, capacity, 1)) {
            f->rax = 0;
            return f;
        }

        if (g_ext4_ok || g_ntfsk_ok) {
            if (index < (uint32_t)vfs_nent) {
                const char *n = vfs_ents[index].name;
                uint64_t i = 0;
                for (; n[i] && i + 1 < capacity; i++) name[i] = n[i];
                name[i] = 0;
                f->rax = vfs_ents[index].is_dir ? 2 : 1;
            } else f->rax = 0;
        } else {
            /* No mounted filesystem: never misrepresent boot modules as files. */
            name[0] = 0;
            f->rax = 0;
        }
        return f;
    }

    case SYS_NtUploadVirGLBuffer: {
        uint64_t bytes=f->rdi;
        if(!gfx_3d_ready||!bytes||(bytes&3ULL)||bytes>GFX_VIRGL_BUFFER_BYTES) { f->rax=0;return f; }
        KPROCESS *caller=MmCurrentProcess;
        if(caller!=PspSystemProcess)MmSwitchToProcess(PspSystemProcess);
        int ok=gfx_upload_virgl_buffer((uint32_t)bytes);
        if(caller!=PspSystemProcess)MmSwitchToProcess(caller);
        f->rax=ok?1:0;
        return f;
    }

    case SYS_NtPresent3D: {
        if(!gfx_3d_ready) { f->rax=0;return f; }
        KPROCESS *caller=MmCurrentProcess;
        if(caller!=PspSystemProcess)MmSwitchToProcess(PspSystemProcess);
        int ok=gfx_present_virgl();
        if(caller!=PspSystemProcess)MmSwitchToProcess(caller);
        f->rax=ok?1:0;
        return f;
    }

    case SYS_NtSubmit3D: {
        uint64_t user_stream=f->rdi, length=f->rsi;
        if(!length || (length&3ULL) || length>4064 || !gfx_3d_ready ||
           (user_stream&3ULL) ||
           !MmValidateUserRange(MmCurrentProcess,user_stream,length,0)) {
            f->rax=0;return f;
        }
        uint8_t stream[4064];
        for(uint64_t i=0;i<length;i++)stream[i]=((const uint8_t*)user_stream)[i];
        KPROCESS *caller=MmCurrentProcess;
        if(caller!=PspSystemProcess)MmSwitchToProcess(PspSystemProcess);
        int ok=gfx_submit_virgl(stream,(uint32_t)length);
        if(caller!=PspSystemProcess)MmSwitchToProcess(caller);
        f->rax=ok?1:0;
        return f;
    }

    case SYS_NtFlushGraphics: {
        typedef struct { uint32_t x, y, w, h; } GfxUserRect;
        GfxUserRect rect;
        if (!f->rdi ||
            !MmValidateUserRange(MmCurrentProcess, f->rdi, sizeof(rect), 0)) {
            f->rax = 0;
            return f;
        }
        rect = *(GfxUserRect *)f->rdi;
        KPROCESS *caller = MmCurrentProcess;
        if (caller != PspSystemProcess) MmSwitchToProcess(PspSystemProcess);
        int ok = gfx_flush(rect.x, rect.y, rect.w, rect.h);
        if (caller != PspSystemProcess) MmSwitchToProcess(caller);
        f->rax = ok ? 1 : 0;
        return f;
    }

    case SYS_NtInitializeGraphics: {
        GfxBootInfo info = {0};
        if (!f->rdi ||
            !MmValidateUserRange(MmCurrentProcess, f->rdi, sizeof(info), 1)) {
            f->rax = 0;
            return f;
        }
        gfx_boot_initialize(&info, user_fb_w, user_fb_h, user_fb_pitch);
        *(GfxBootInfo *)f->rdi = info;
        f->rax = info.initialized ? 1 : 0;
        return f;
    }

    case SYS_NtMapFramebuffer: {
        if (!user_fb_base) {
            f->rax = 0;
            return f;
        }

        KPROCESS *cur = MmCurrentProcess;
        uint64_t uva = 0x70000000ULL;
        uint64_t bytes = (uint64_t)user_fb_pitch * user_fb_h;
        uint64_t pages = (bytes + 0xFFFULL) >> 12;
        if (!cur || cur == PspSystemProcess || !pages ||
            !MmValidateUserRange(cur, f->rdi, 20, 1) ||
            !MmUserRangeUnmapped(cur, uva, pages << 12)) {
            f->rax = 0;
            return f;
        }

        MmSwitchToProcess(PspSystemProcess);
        for (uint64_t i = 0; i < pages; i++) {
            map_4k_in(cur->Pml4,
                      uva + (i << 12),
                      (user_fb_base + (i << 12)) & ~0xFFFULL,
                      PTE_U | PTE_RW);
        }
        MmSwitchToProcess(cur);

        *(uint64_t *)f->rdi = uva;
        *(uint32_t *)(f->rdi + 8) = user_fb_w;
        *(uint32_t *)(f->rdi + 12) = user_fb_h;
        *(uint32_t *)(f->rdi + 16) = user_fb_pitch;

        if (!fb_map_logged) {
            DbgPrint("user: FB mapped %ux%u", user_fb_w, user_fb_h);
            fb_map_logged = 1;
        }

        f->rax = uva;
        return f;
    }

    case SYS_NtLoadLibrary: {
        char dll[64];
        if (copy_user_str(f->rdi, dll, sizeof dll) != 0 || !dll[0]) {
            f->rax = 0;
            return f;
        }
        KPROCESS *cur = MmCurrentProcess;
        if (!cur || cur == PspSystemProcess) {
            f->rax = 0;
            return f;
        }
        BootModule *mod = PspFindModule(user_bootinfo, dll);
        if (!mod)
            mod = PspLoadProcessDiskDependency(cur, dll);
        int loaded = 0;
        if (mod) {
            MmSwitchToProcess(PspSystemProcess);
            if (PspMapUserImage(cur, mod) == 0) {
                pe_resolve_imports(cur, mod);
                UserImage *loaded_image = PspGetUserImage(cur, mod);
                loaded = loaded_image && loaded_image->resolved &&
                         !loaded_image->import_failed;
            }
            MmSwitchToProcess(cur);
        }
        f->rax = loaded ? 1 : 0;
        return f;
    }

    case SYS_NtGetProcAddress: {
        char dll[64], func[64];

        if (copy_user_str(f->rdi, dll, sizeof dll) != 0)
            dll[0] = 0;

        if (copy_user_str(f->rsi, func, sizeof func) != 0)
            func[0] = 0;

        KPROCESS *cur = MmCurrentProcess;
        BootModule *mod = PspFindModule(user_bootinfo, dll);
        /*
         * GetProcAddress is also used on DLLs loaded from the application's
         * own directory (Geometry Dash ships most of its engine this way).
         * Those images are private to the process and are not in boot modules.
         */
        if (!mod)
            mod = PspLoadProcessDiskDependency(cur, dll);

        uint64_t addr = 0;
        if (mod && cur && cur != PspSystemProcess) {
            MmSwitchToProcess(PspSystemProcess);
            if (PspMapUserImage(cur, mod) == 0) {
                pe_resolve_imports(cur, mod);
                addr = pe_get_export(cur, mod, func);
            }
            MmSwitchToProcess(cur);
        }

        f->rax = addr;
        return f;
    }

    case SYS_NtGetGameMouseDelta: {
        if (!MmCurrentProcess || MmCurrentProcess == PspSystemProcess ||
            wm_get_active_pid() != (int)MmCurrentProcess->Pid) {
            f->rax = 0;
            return f;
        }
        f->rax = ps2_game_mouse_delta();
        return f;
    }

    case SYS_NtGetGameKeyState: {
        /* Only the active user process may poll live game controls. */
        if (!MmCurrentProcess || MmCurrentProcess == PspSystemProcess ||
            wm_get_active_pid() != (int)MmCurrentProcess->Pid) {
            f->rax = 0;
            return f;
        }
        f->rax = ps2_game_key_state();
        return f;
    }

    case SYS_NtGetInput: {
        typedef struct {
            int type, x, y, btn;
            char key;
        } UIn;

        UIn *out = (UIn *)f->rdi;

        static UIn pending_click;
        static int pending_click_valid;
        static int pending_click_pid;

        int mepid = MmCurrentProcess ? (int)MmCurrentProcess->Pid : 0;

        if (!out || !MmValidateUserRange(MmCurrentProcess, (uint64_t)out, sizeof *out, 1)) {
            f->rax = 0;
            return f;
        }

        /* A click assigned to another process remains queued. */
        if (pending_click_valid) {
            if (pending_click_pid == mepid) {
                *out = pending_click;
                pending_click_valid = 0;
                wm_dbg_input(mepid,out->type,out->x,out->y,out->btn,out->key);
                f->rax = 1;
                return f;
            }

            goto no_input_event;
        }

        ps2_poll();

        if (vi_ok)
            virtio_input_poll();

        /* The kernel owns the one system pointer: move it here, whichever
         * process polled, instead of letting each process paint its own. */
        wm_cursor_track(vi_ok ? vi_x : mouse_x, vi_ok ? vi_y : mouse_y);

        /* Mouse wheel: route notches to the window under the pointer, queue
         * them for that process, and deliver as input type 4 (btn = delta*120,
         * positive = scroll up). Only the target process consumes them. */
        {
            static int pending_wheel, pending_wheel_pid;
            if (vi_ok) { mouse_wheel_accum += vi_wheel; vi_wheel = 0; }
            if (mouse_wheel_accum) {
                int wx = vi_ok ? vi_x : mouse_x;
                int wy = vi_ok ? vi_y : mouse_y;
                int wtarget = wm_hit_test(wx, wy);
                if (wtarget <= 0) wtarget = wm_get_active_pid();
                if (wtarget <= 0) wtarget = mepid;
                if (pending_wheel && pending_wheel_pid != wtarget)
                    pending_wheel = 0;
                pending_wheel += mouse_wheel_accum;
                pending_wheel_pid = wtarget;
                mouse_wheel_accum = 0;
            }
            if (pending_wheel && pending_wheel_pid == mepid) {
                int notches = pending_wheel;
                if (notches > 8) notches = 8;
                if (notches < -8) notches = -8;
                pending_wheel = 0;
                out->type = 4;
                out->x = vi_ok ? vi_x : mouse_x;
                out->y = vi_ok ? vi_y : mouse_y;
                out->btn = notches * 120;
                out->key = 0;
                f->rax = 1;
                return f;
            }
        }

        /* Tablet owns absolute position when present. Route ordinary pointer
         * motion only to the active window so a background process cannot
         * repaint a game-hidden cursor over the foreground scene. Clicks are
         * still hit-tested and delivered to their actual target below. */
        if (vi_ok && vi_moved && !vi_clicked &&
            wm_get_active_pid() && wm_get_active_pid() != mepid)
            goto no_input_event;

        if (vi_ok && (vi_moved || vi_clicked)) {
            mouse_x = vi_x;
            mouse_y = vi_y;
            mouse_btn = vi_btn;

            out->type = vi_clicked ? 3 : 2;
            out->x = mouse_x;
            out->y = mouse_y;
            out->btn = mouse_btn;

            vi_moved = 0;
            vi_clicked = 0;

            if (out->type == 3) {
                int target = wm_hit_test(out->x, out->y);
                if (target <= 0) target = mepid;

                /* Raise/focus the clicked window before routing its button event. */

                wm_activate_pid(target);

                pending_click = *out;
                pending_click_pid = target;
                pending_click_valid = 1;

                if (target != mepid)
                    goto no_input_event;

                pending_click_valid = 0;
            }

            wm_dbg_input(mepid,out->type,out->x,out->y,out->btn,out->key);
            f->rax = 1;
            return f;
        }

        char k = 0;

        /*
         * Keyboard bytes are shared by all user processes. Only the active
         * window may consume them; otherwise Explorer's message pump can eat
         * WASD/Escape before a foreground game ever sees the key.
         */
        int active_input_pid = wm_get_active_pid();
        if ((!active_input_pid || active_input_pid == mepid) && ps2_read_key(&k)) {
            out->type = 1;
            out->key = k;
            out->x = mouse_x;
            out->y = mouse_y;
            out->btn = mouse_btn;
            wm_dbg_input(mepid,out->type,out->x,out->y,out->btn,out->key);
            f->rax = 1;
            return f;
        }

        /* PS/2 relative mouse input, only when no tablet exists. */
        if (!vi_ok) {
            static int lx = -1, ly = -1, lb = -1;

            if (mouse_x != lx || mouse_y != ly || mouse_btn != lb) {
                int pressed = (mouse_btn & 1) && !(lb & 1);
                int active_mouse_pid = wm_get_active_pid();
                if (!pressed && active_mouse_pid && active_mouse_pid != mepid)
                    goto no_input_event;

                out->type = pressed ? 3 : 2;
                out->x = mouse_x;
                out->y = mouse_y;
                out->btn = mouse_btn;

                lx = mouse_x;
                ly = mouse_y;
                lb = mouse_btn;

                wm_dbg_input(mepid,out->type,out->x,out->y,out->btn,out->key);
                if (out->type == 3) {
                    int target = wm_hit_test(out->x, out->y);
                    if (target <= 0) target = mepid;

                    /* Raise/focus the clicked window before routing its button event. */

                    wm_activate_pid(target);

                    pending_click = *out;
                    pending_click_pid = target;
                    pending_click_valid = 1;

                    if (target != mepid)
                        goto no_input_event;

                    pending_click_valid = 0;
                }

                f->rax = 1;
                return f;
            }
        }

    no_input_event:
        /*
         * Round-robin at most every 32 empty polls.
         * Scheduler behavior intentionally unchanged.
         */
        {
            static int empty;
            empty++;

            if ((empty & 31) == 0) {
                int me = up_find_proc(MmCurrentProcess);

                if (me >= 0)
                    up_save(f, me);

                int nxt = up_pick_next();

                if (nxt >= 0 && nxt != me) {
                    if (me >= 0)
                        up_tab[me].rax = 0;

                    up_load(f, nxt);
                    return f;
                }
            }
        }

        f->rax = 0;
        return f;
    }

    case SYS_NtSetCurrentDirectory: {
        char name[128];

        if (copy_user_str(f->rdi, name, sizeof name) != 0) {
            f->rax = (uint64_t)-1LL;
            return f;
        }

        int r = g_ext4_ok ? vfs_chdir(name) :
                (g_ntfsk_ok ? vfs_ntfsk_chdir(name) : -1);
        f->rax = (uint64_t)(int64_t)r;
        return f;
    }

    case SYS_NtCreateThread:
        f->rax = ut_create(f->rdi, f->rsi);
        return f;

    case SYS_NtWaitForSingleObject:
        f->rax = ut_wait(f, (int)f->rdi, (uint32_t)f->rsi);
        return f;

    case SYS_WmRegister: {
        char title[40];

        if (copy_user_str(f->rsi, title, sizeof title) != 0)
            title[0] = 0;

        int pid = MmCurrentProcess ? (int)MmCurrentProcess->Pid : 0;
        wm_register(pid, title);
        uint64_t dbg_n=++wm_dbg_window_registers;
        DbgPrint("[wm] register #%llu pid=%d title='%s'\n",
                 (unsigned long long)dbg_n,pid,title);

        f->rax = 0;
        return f;
    }

    case SYS_WmSetMin: {
        int pid = (int)f->rdi;
        int min = (int)f->rsi;
        wm_set_min(pid, min);
        f->rax = 0;
        return f;
    }

    case SYS_WmUnregister: {
        int pid = MmCurrentProcess ? (int)MmCurrentProcess->Pid : 0;
        int slot=wm_shared_window_slot(pid);
        uint64_t dbg_n=++wm_dbg_window_closes;
        if(wm_dbg_sample(dbg_n))
            DbgPrint("[wm] unregister #%llu pid=%d slot=%d\n",
                     (unsigned long long)dbg_n,pid,slot);
        KPROCESS *caller=MmCurrentProcess;
        if(caller!=PspSystemProcess)MmSwitchToProcess(PspSystemProcess);
        if(slot>=0&&wm_shared_windows[slot]) {
            kfree(wm_shared_windows[slot]);wm_shared_windows[slot]=0;
        }
        if(slot>=0&&wm_shared_local_windows[slot]) {
            kfree(wm_shared_local_windows[slot]);wm_shared_local_windows[slot]=0;
            wm_shared_local_width[slot]=wm_shared_local_height[slot]=0;
        }
        wm_unregister(pid);
        /*
         * Rebuild the whole scanout after removing a window. The previous
         * rectangle-only repaint could leave old window pixels visible when
         * its cached layer had been presented outside the registered frame.
         * wm_shared_compose now sees the updated Z-order and redraws only the
         * remaining live windows over the persistent desktop layers. A second
         * unregister has slot == -1 and deliberately does not repaint again.
         */
        if(slot>=0&&wm_shared_width&&wm_shared_height) {
            wm_shared_force_compose=1;
            DbgPrint("[wm] force-composing scanout after unreg pid=%d slot=%d\n", pid, slot);
            wm_shared_compose(0,0,wm_shared_width,wm_shared_height);
            wm_shared_force_compose=0;
        }
        if(caller&&caller!=PspSystemProcess)MmSwitchToProcess(caller);
        f->rax = 0;
        return f;
    }

    case SYS_WmQuery: {
        char tmp[40];
        int minv = 0, pidv = 0;

        if (!wm_query((int)f->rdi, tmp, &minv, &pidv)) {
            f->rax = 0;
            return f;
        }

        if (f->rsi && !MmValidateUserRange(MmCurrentProcess, f->rsi, sizeof tmp, 1)) {
            f->rax = 0;
            return f;
        }
        if (f->rdx && !MmValidateUserRange(MmCurrentProcess, f->rdx, sizeof minv, 1)) {
            f->rax = 0;
            return f;
        }

        if (f->rsi) {
            char *d = (char *)f->rsi;
            int k = 0;

            for (; tmp[k]; k++)
                d[k] = tmp[k];

            d[k] = 0;
        }

        if (f->rdx)
            *(int *)f->rdx = minv;

        f->rax = (uint64_t)(uint32_t)pidv;
        return f;
    }

    case SYS_WmRestore: {
        /* Restore (un-minimize) a window owned by another process.
         * The taskbar passes the target pid in rdi. wm_restore_pid clears
         * the minimized flag, bumps the Z-order, and marks it active;
         * we then force a full scanout recompose so the restored window
         * becomes visible. */
        int pid = (int)f->rdi;
        wm_restore_pid(pid);
        if (wm_shared_width && wm_shared_height) {
            wm_shared_force_compose = 1;
            wm_shared_compose(0, 0, wm_shared_width, wm_shared_height);
            wm_shared_force_compose = 0;
        }
        f->rax = 1;
        return f;
    }

    case SYS_WmSetRect: {
        int rect[4];
        int *src = (int *)f->rdi;
        if (!src || !MmValidateUserRange(MmCurrentProcess,(uint64_t)src,sizeof rect,0)) {
            f->rax=0;return f;
        }
        for(int i=0;i<4;i++)rect[i]=src[i];
        /* Keep frame arithmetic bounded before computing old/new damage.
         * Partially off-screen windows are supported, but absurd coordinates
         * and dimensions must not overflow signed int additions below. */
        uint32_t screen_w=wm_shared_width?wm_shared_width:gfx_width;
        uint32_t screen_h=wm_shared_height?wm_shared_height:gfx_height;
        if(!screen_w||!screen_h||screen_w>1920u||screen_h>1080u) {
            f->rax=0;return f;
        }
        if(rect[2]<1)rect[2]=1;
        if(rect[3]<1)rect[3]=1;
        if((uint32_t)rect[2]>screen_w)rect[2]=(int)screen_w;
        if((uint32_t)rect[3]>screen_h)rect[3]=(int)screen_h;
        int x_limit=(int)screen_w+12,y_limit=(int)screen_h+16;
        if(rect[0]<-x_limit)rect[0]=-x_limit;
        if(rect[0]>x_limit)rect[0]=x_limit;
        if(rect[1]<-y_limit)rect[1]=-y_limit;
        if(rect[1]>y_limit)rect[1]=y_limit;
        int pid=MmCurrentProcess?(int)MmCurrentProcess->Pid:0;
        wm_set_rect(pid, rect[0], rect[1], rect[2], rect[3]);
        f->rax = 1;
        return f;
    }
    case SYS_WmGetDirty: {
        f->rax = (uint64_t)wm_scene_dirty;
        wm_scene_dirty = 0;
        return f;
    }
    case SYS_WmCursor: {
        /* rdi = op.  0: does the kernel compositor own the pointer now?
         *            1: rsi=1 hide / rsi=0 show for the calling process.
         *            2: rsi=shape id, rdx=256 ARGB pixels (or 0 to just ask
         *               whether that shape is already current).
         *            3: stop drawing the pointer (shutdown screen). */
        int cpid = MmCurrentProcess ? (int)MmCurrentProcess->Pid : 0;
        switch (f->rdi) {
        case 0:
            f->rax = (wm_shared_bg_published && !wm_cursor_app_owned &&
                      !wm_cursor_suspended) ? 1 : 0;
            return f;
        case 1: {
            int changed = 0;
            if (f->rsi) {
                if (!wm_cursor_hidden || wm_cursor_hidden_pid != cpid) changed = 1;
                wm_cursor_hidden = 1;
                wm_cursor_hidden_pid = cpid;
            } else if (wm_cursor_hidden && wm_cursor_hidden_pid == cpid) {
                wm_cursor_hidden = 0;
                changed = 1;
            }
            if (changed) wm_cursor_refresh();
            f->rax = 1;
            return f;
        }
        case 2: {
            wm_cursor_init_default();
            if (wm_cursor_shape_id == (uint32_t)f->rsi) { f->rax = 1; return f; }
            if (!f->rdx ||
                !MmValidateUserRange(MmCurrentProcess, f->rdx, sizeof wm_cursor_pixels, 0)) {
                f->rax = 0;
                return f;
            }
            const uint32_t *src = (const uint32_t *)f->rdx;
            for (int i = 0; i < WM_CURSOR_W * WM_CURSOR_H; i++)
                wm_cursor_pixels[i] = src[i];
            wm_cursor_shape_id = (uint32_t)f->rsi;
            wm_cursor_refresh();
            f->rax = 1;
            return f;
        }
        case 3:
            wm_cursor_suspended = 1;
            f->rax = 1;
            return f;
        default:
            f->rax = 0;
            return f;
        }
    }
    case SYS_NtYield: {
        int me = up_find_proc(MmCurrentProcess);
        if (me >= 0) {
            up_save(f, me);
            up_tab[me].rax = 0;
        }
        int nxt = up_pick_next();
        if (nxt >= 0 && nxt != me) {
            up_load(f, nxt);
            return f;
        }
        f->rax = 0;
        return f;
    }

    case SYS_NtGetTickCount: {
        UserSystemTime now;
        if(!user_boot_rtc_valid||!user_rtc_system_time(&now)){f->rax=(uint64_t)-1LL;return f;}
        uint64_t current=user_rtc_epoch_seconds(&now);
        f->rax=current>=user_boot_rtc_seconds?(current-user_boot_rtc_seconds)*1000u:0u;
        return f;
    }

    case SYS_NtGetSystemTime: {
        UserSystemTime value;
        if(!f->rdi || !MmValidateUserRange(MmCurrentProcess,f->rdi,sizeof(value),1) || !user_rtc_system_time(&value)) {
            f->rax=(uint64_t)-1LL;
            return f;
        }
        *(UserSystemTime *)(uint64_t)f->rdi=value;
        f->rax=0;
        return f;
    }

    /* Installer services are restricted to the protected native setup
     * process. All disk access is routed through the common block registry. */
    case SYS_NtQueryInstallerDisk: {
        if (!PspIsInstallerProcess(MmCurrentProcess) || !f->rdi ||
            !MmValidateUserRange(MmCurrentProcess,f->rdi,sizeof(InstallerDiskInfo),1)) {
            f->rax=0; return f;
        }
        InstallerDiskInfo info={0};
        SENTINEL_BLOCK_DEVICE snapshot={0};
        if(f->rsi<SENTINEL_BLOCK_MAX_DEVICES &&
           SentinelBlockSnapshot((uint32_t)f->rsi,&snapshot)==0) {
            SENTINEL_BLOCK_DEVICE *d=&snapshot;
            info.sectors=d->sector_count; info.sector_size=d->sector_size;
            info.index=(uint32_t)f->rsi; info.present=1;
            const char *display=d->model[0]?d->model:d->name;
            for(unsigned i=0;i<sizeof(info.name)-1 && display[i];i++) info.name[i]=display[i];
        }
        *(InstallerDiskInfo *)(uintptr_t)f->rdi=info;
        f->rax=info.present?1:0; return f;
    }
    case SYS_NtInstallerDiskIo: {
        if(!PspIsInstallerProcess(MmCurrentProcess)||f->rcx>=SENTINEL_BLOCK_MAX_DEVICES||
           f->rsi>UINT64_MAX/512ULL||!f->rdx||
           !MmValidateUserRange(MmCurrentProcess,f->rdx,512,f->rdi==0)) {
            f->rax=(uint64_t)-1LL; return f;
        }
        SENTINEL_BLOCK_DEVICE *d=SentinelBlockGet((uint32_t)f->rcx);
        uint64_t capacity=0,off=f->rsi*512ULL;
        if(!d||d->sector_size!=512||f->rsi>=d->sector_count||
           SentinelBlockByteCapacity(d,&capacity)!=0||off>capacity||512>capacity-off) {
            f->rax=(uint64_t)-1LL; return f;
        }
        int rc=f->rdi==0?SentinelBlockReadDevice(d,off,(void *)(uintptr_t)f->rdx,512):
               f->rdi==1?SentinelBlockWriteDevice(d,off,(const void *)(uintptr_t)f->rdx,512):-1;
        f->rax=rc==0?0:(uint64_t)-1LL; return f;
    }
    case SYS_NtQueryInstallerPayload: {
        if(!PspIsInstallerProcess(MmCurrentProcess)||f->rdi>1||!user_bootinfo||!f->rsi||
           !MmValidateUserRange(MmCurrentProcess,f->rsi,sizeof(uint64_t),1)) {
            f->rax=(uint64_t)-1LL; return f;
        }
        BootModule *m=PspFindModule(user_bootinfo,f->rdi?"system.img":"esp.img");
        if(!m||!m->phys||!m->size){f->rax=(uint64_t)-1LL;return f;}
        *(uint64_t *)(uintptr_t)f->rsi=m->size; f->rax=0; return f;
    }
    case SYS_NtVerifyInstallerPayload: {
        if(!PspIsInstallerProcess(MmCurrentProcess)||f->rdi>1||!user_bootinfo) {
            f->rax=(uint64_t)-1LL; return f;
        }
        BootModule *m=PspFindModule(user_bootinfo,f->rdi?"system.img":"esp.img");
        BootModule *sum=PspFindModule(user_bootinfo,"install.sha256");
        if(!m||!sum||!m->phys||!m->size||m->size>(1ULL<<30)||sum->size<130) {
            f->rax=(uint64_t)-1LL;return f;
        }
        const uint8_t *manifest=(const uint8_t *)(uintptr_t)(HHDM_BASE+sum->phys);
        const uint8_t *expected=manifest+(f->rdi?65:0);
        if(manifest[64]!='\n'||manifest[129]!='\n'){f->rax=(uint64_t)-1LL;return f;}
        for(unsigned i=0;i<64;i++) if(!((expected[i]>='0'&&expected[i]<='9')||(expected[i]>='a'&&expected[i]<='f'))){f->rax=(uint64_t)-1LL;return f;}
        uint8_t digest[32]; sentinel_sha256((const uint8_t *)(uintptr_t)(HHDM_BASE+m->phys),m->size,digest);
        static const char hex[]="0123456789abcdef";
        for(unsigned i=0;i<32;i++) if(expected[i*2]!=(uint8_t)hex[digest[i]>>4]||expected[i*2+1]!=(uint8_t)hex[digest[i]&15]){f->rax=(uint64_t)-2LL;return f;}
        f->rax=0;return f;
    }
    case SYS_NtReadInstallerPayload: {
        if(!PspIsInstallerProcess(MmCurrentProcess)||f->rdi>1||!user_bootinfo||f->rcx>65536ULL||
           (f->rcx&&(!f->rdx||!MmValidateUserRange(MmCurrentProcess,f->rdx,f->rcx,1)))) {
            f->rax=(uint64_t)-1LL;return f;
        }
        BootModule *m=PspFindModule(user_bootinfo,f->rdi?"system.img":"esp.img");
        if(!m||f->rsi>m->size||f->rcx>m->size-f->rsi){f->rax=(uint64_t)-1LL;return f;}
        const uint8_t *src=(const uint8_t *)(uintptr_t)(HHDM_BASE+m->phys+f->rsi);
        uint8_t *dst=(uint8_t *)(uintptr_t)f->rdx;
        for(uint64_t i=0;i<f->rcx;i++)dst[i]=src[i];
        f->rax=f->rcx;return f;
    }
    case SYS_NtInstallerInstallImage: {
        if(!PspIsInstallerProcess(MmCurrentProcess)||!user_bootinfo||f->rdi>1||
           f->rcx>=SENTINEL_BLOCK_MAX_DEVICES){f->rax=(uint64_t)-1LL;return f;}
        BootModule *m=PspFindModule(user_bootinfo,f->rdi?"system.img":"esp.img");
        SENTINEL_BLOCK_DEVICE *d=SentinelBlockGet((uint32_t)f->rcx);
        uint64_t capacity=0, dest=f->rdi?264192ULL:2048ULL;
        uint64_t off=f->rsi,bytes=f->rdx;
        if(!m||!m->phys||!m->size||m->size>(1ULL<<30)||(m->size&511ULL)||!d||d->sector_size!=512||
           SentinelBlockByteCapacity(d,&capacity)!=0||dest>d->sector_count||m->size/512ULL>d->sector_count-dest||
           (off&511ULL)||(bytes&511ULL)||!bytes||bytes>4ULL*1024*1024||off>m->size||bytes>m->size-off) {
            f->rax=(uint64_t)-1LL;return f;
        }
        const uint8_t *src=(const uint8_t *)(uintptr_t)(HHDM_BASE+m->phys+off);
        if(SentinelBlockWriteDevice(d,(dest*512ULL)+off,src,bytes)!=0){f->rax=(uint64_t)-2LL;return f;}
        /* Verify every sector using bounded scratch space before advancing
         * installer progress. This remains safe on fragmented low-memory VMs. */
        uint8_t verify[512];
        for(uint64_t pos=0;pos<bytes;pos+=sizeof(verify)) {
            if(SentinelBlockReadDevice(d,(dest*512ULL)+off+pos,verify,sizeof(verify))!=0) {
                DbgPrint("installer: image %llu read-back failed at byte %llu\n",
                         (unsigned long long)f->rdi,(unsigned long long)(off+pos));
                f->rax=(uint64_t)-3LL;return f;
            }
            for(unsigned i=0;i<sizeof(verify);i++)if(verify[i]!=src[pos+i]) {
                DbgPrint("installer: image %llu mismatch at byte %llu\n",
                         (unsigned long long)f->rdi,(unsigned long long)(off+pos+i));
                f->rax=(uint64_t)-4LL;return f;
            }
        }
        f->rax=0;return f;
    }

    case SYS_NtShutdown:
        if (f->rdi == 0)
            HalReturnToFirmware(HalPowerDownRoutine);
        else
            HalReturnToFirmware(HalRebootRoutine);

        f->rax = 0;
        return f;


    default:
        if (f->rax >= 0x1000 && f->rax <= 0x10FF)
            f->rax = NtStatusResult(NT_STATUS_INVALID_SYSTEM_SERVICE);
        else
            f->rax = (uint64_t)-1LL;
        return f;
    }
}

/* Handle CPU exceptions raised by ring-3 code as process termination.
 * Never return to the faulting instruction: tear down its address space,
 * remove its windows/threads, and resume its parent or another runnable app. */
static Frame *user_exception_handler(Frame *f) {
    KPROCESS *dying = MmCurrentProcess;
    int dead_idx = up_find_proc(dying);
    uint64_t cr2 = 0;
    __asm__ volatile("movq %%cr2, %0" : "=r"(cr2));

    if (!dying || dying == PspSystemProcess || dead_idx < 0) {
        DbgPrint("[user-exception] untracked ring-3 fault vector=%llu rip=%016llx; refusing to resume faulting code\n",
                 (unsigned long long)f->vector, (unsigned long long)f->rip);
        /* No safe user process record exists to resume. This is a kernel
         * process-manager invariant failure, so use the fatal diagnostics. */
        uint64_t cr3;
        __asm__ volatile("movq %%cr3, %0" : "=r"(cr3));
        DbgPrint("error=%016llx cs=%04llx rsp=%016llx cr2=%016llx cr3=%016llx\n",
                 (unsigned long long)f->error, (unsigned long long)f->cs,
                 (unsigned long long)f->rsp, (unsigned long long)cr2,
                 (unsigned long long)cr3);
        for (;;) __asm__ volatile("cli; hlt");
    }

    UserProc *faulted = &up_tab[dead_idx];
    int parent_idx = faulted->parent;
    UserApplicationError crash = {0};
    crash.pid = (uint32_t)dying->Pid;
    crash.vector = f->vector;
    crash.rip = f->rip;
    crash.error = f->error;
    crash.cr2 = cr2;
    for (unsigned int i = 0; i < sizeof(crash.image_name)-1 &&
         faulted->image_name[i]; i++)
        crash.image_name[i] = faulted->image_name[i];
    const char *reason = f->vector < 32 ? exc_name[f->vector] : "CPU exception";
    for (unsigned int i = 0; i < sizeof(crash.exception_name)-1 && reason[i]; i++)
        crash.exception_name[i] = reason[i];
    user_app_error_push(&crash);
    DbgPrint("\n[Application Error] %s (PID %u) terminated: %s (#%llu)\n",
             faulted->image_name, (unsigned int)dying->Pid,
             f->vector < 32 ? exc_name[f->vector] : "CPU exception",
             (unsigned long long)f->vector);
    DbgPrint("  RIP=%016llx error=%016llx CR2=%016llx RSP=%016llx\n",
             (unsigned long long)f->rip, (unsigned long long)f->error,
             (unsigned long long)cr2, (unsigned long long)f->rsp);
    /* A null RIP hides the indirect-call site. Dump a few user stack
     * words while the faulting process address space is still active so
     * the last return addresses can identify the caller chain. */
    if (f->rsp >= 0x10000ULL &&
        f->rsp < 0x0000800000000000ULL &&
        f->rsp <= 0x0000800000000000ULL - 4 * sizeof(uint64_t)) {
        volatile const uint64_t *user_stack =
            (volatile const uint64_t *)(uintptr_t)f->rsp;
        for (unsigned int si = 0; si < 4; si++) {
            uint64_t value = user_stack[si];
            DbgPrint("  STACK[%u] %016llx: %016llx\n", si,
                     (unsigned long long)(f->rsp + si * sizeof(uint64_t)),
                     (unsigned long long)value);
        }
        /* For an indirect CALL through a null pointer, STACK[0] is often
         * the return address immediately after that CALL. Dump nearby bytes
         * so the call instruction and its target operand can be identified. */
        uint64_t callsite = user_stack[0];
        if (callsite >= 0x10010ULL &&
            callsite < 0x0000800000000000ULL - 16) {
            volatile const uint8_t *code =
                (volatile const uint8_t *)(uintptr_t)(callsite - 16);
            DbgPrint("  CALLSITE %016llx bytes:", (unsigned long long)(callsite - 16));
            for (unsigned int bi = 0; bi < 32; bi++)
                DbgPrint(" %02x", (unsigned int)code[bi]);
            SENTINEL_GFX_LOG("\\n");
        }
    }
    /* Stop the current thread before switching away from its address space. */
    ut_exit_current();
    int dead_pid = (int)dying->Pid;
    int dead_slot = wm_shared_window_slot(dead_pid);
    int dx = 0, dy = 0, dw = (int)wm_shared_width, dh = (int)wm_shared_height;
    if (dead_slot >= 0) {
        dx = wm_tab[dead_slot].x - 12;
        dy = wm_tab[dead_slot].y - 12;
        dw = wm_tab[dead_slot].w + 24;
        dh = wm_tab[dead_slot].h + 28;
    }

    MmSwitchToProcess(PspSystemProcess);
    if (ki_current) ki_current->Process = PspSystemProcess;
    if (dead_slot >= 0 && wm_shared_windows[dead_slot]) {
        kfree(wm_shared_windows[dead_slot]);
        wm_shared_windows[dead_slot] = 0;
    }
    if (dead_slot >= 0 && wm_shared_local_windows[dead_slot]) {
        kfree(wm_shared_local_windows[dead_slot]);
        wm_shared_local_windows[dead_slot] = 0;
        wm_shared_local_width[dead_slot] = wm_shared_local_height[dead_slot] = 0;
    }
    wm_unregister(dead_pid);
    if (dx < 0) { dw += dx; dx = 0; }
    if (dy < 0) { dh += dy; dy = 0; }
    /* An application may already have unregistered its window before
     * process-exit cleanup runs. Only repaint when that cleanup owned a live
     * slot; otherwise the default rectangle would trigger a full-screen redraw. */
    if (dead_slot >= 0 && dw > 0 && dh > 0)
        wm_shared_compose((uint32_t)dx, (uint32_t)dy, (uint32_t)dw, (uint32_t)dh);

    for (int i = 0; i < UP_MAX; i++) {
        if (up_tab[i].proc == dying) {
            up_tab[i].alive = 0;
            up_tab[i].parent = -1;
        }
    }
    for (int i = 0; i < UT_MAX; i++) {
        if (ut_tab[i].proc == dying) {
            ut_tab[i].alive = 0;
            ut_tab[i].proc = 0;
        }
    }
    PspForgetUserImages(dying);
    PspForgetDiskModule(dying);
    user_vm_forget_process(dying);
    MmDeleteAddressSpace(dying);

    int next = -1;
    if (parent_idx >= 0 && parent_idx < UP_MAX &&
        up_tab[parent_idx].alive && up_tab[parent_idx].proc)
        next = parent_idx;
    if (next < 0) next = up_pick_next();
    if (next >= 0) {
        DbgPrint("[user-exception] recovered; resuming PID %u\n",
                 (unsigned int)up_tab[next].proc->Pid);
        up_load(f, next);
        return f;
    }

    DbgPrint("[user-exception] no runnable user process remains\n");
    MmSwitchToProcess(PspSystemProcess);
    if (ki_current) ki_current->Process = PspSystemProcess;
    for (;;) __asm__ volatile("cli; hlt");
}

/* ------------------------------------------------------------ user entry */

static void user_enter(BootInfo *bi) {
    UserSystemTime boot_time;
    user_boot_rtc_valid=user_rtc_system_time(&boot_time);
    if(user_boot_rtc_valid)user_boot_rtc_seconds=user_rtc_epoch_seconds(&boot_time);
    ps2_init();
    ata_init();
    virtio_blk_init();
    ahci_init();
    virtio_input_init();
    SentinelRegisterBuiltinBlockDevices();

    /* NTFS is preferred when present; ext4 remains the legacy fallback. */
    for(uint32_t i=0;i<SentinelBlockDeviceCount;i++) {
        SENTINEL_BLOCK_DEVICE *d=SentinelBlockGet(i);
        if(d && ntfsk_find_and_mount(&g_ntfsk_volume,d)==0) {
            g_ntfsk_ok=1;
            vfs_ntfsk_cwd_storage=5;
            if(vfs_ntfsk_refresh()<0)
                DbgPrint("fs: NTFS root directory enumeration failed\n");
            DbgPrint("fs: NTFS system volume mounted (bounded in-place writes)\n");
            break;
        }
    }

    if(!g_ntfsk_ok) {
        DbgPrint("fs: no supported NTFS system volume found; trying legacy ext4 volume\n");
        vfs_mount_c();
    }

    if (g_ext4_ok || g_ntfsk_ok) {
        int driver_count = SentinelDriverLoadAllFromDisk();
        if (driver_count < 0)
            DbgPrint("driver: .sys autoload scan failed status=%d\n", driver_count);
    } else {
        DbgPrint("driver: .sys autoload deferred; no supported system volume is mounted\n");
    }

    DbgPrint("\n-- usermode (smss) --\n");

    user_bootinfo = (BootInfo *)(HHDM_BASE + (uint64_t)bi);

    user_fb_base = bi->fb_base;
    user_fb_w = bi->width;
    user_fb_h = bi->height;
    user_fb_pitch = bi->pitch;

    user_pending = 0;

    DbgPrint("user: BootInfo modules (%u)\n",
             user_bootinfo->module_count);

    for (uint32_t i = 0;
         i < user_bootinfo->module_count && i < BOOT_MAX_MODULES;
         i++) {
        DbgPrint("  [%u] '%s'\n",
                 i, user_bootinfo->modules[i].name);
    }

    /* Installer media supplies SMSS on the boot ESP, so it can start even
       when the attached target disk is blank and no system volume mounts. */
    UserDiskModule *smss_disk = 0;
    BootModule *smss = PspFindModule(user_bootinfo, "smss.exe");
    if (!smss) {
        smss_disk = PspLoadDiskModule("smss.exe", 0);
        smss = smss_disk ? &smss_disk->module : 0;
    }

    if (!smss) {
        DbgPrint("user: smss.exe disk load failed\n");
        return;
    }

    /*
     * Ensure page-table and physical allocator work happens in the
     * system address space. Keep the original system process for return.
     */
    MmSwitchToProcess(PspSystemProcess);

    KPROCESS *proc = MmCreateAddressSpace("smss");

    if (!proc) {
        DbgPrint("user: smss address-space creation failed\n");
        PspFreeDiskModule(smss_disk);
        MmSwitchToProcess(PspSystemProcess);
        return;
    }

    if (smss_disk) smss_disk->owner = proc;
    if (PspMapUserImage(proc, smss) != 0) {
        DbgPrint("user: map smss failed\n");
        MmSwitchToProcess(PspSystemProcess);
        PspForgetUserImages(proc);
        PspForgetDiskModule(proc);
        MmDeleteAddressSpace(proc);
        return;
    }

    pe_resolve_imports(proc, smss);

    UserImage *smss_image = PspGetUserImage(proc, smss);

    if (!smss_image) {
        DbgPrint("user: smss private image record missing\n");
        MmSwitchToProcess(PspSystemProcess);
        PspForgetUserImages(proc);
        PspForgetDiskModule(proc);
        MmDeleteAddressSpace(proc);
        return;
    }

    uint64_t entry = smss_image->entry;

    uint64_t ktop =
        ((uint64_t)user_kstack + sizeof user_kstack) & ~15ULL;

    user_set_kernel_stack(ktop);

    if (ki_current)
        ki_current->Process = proc;

    up_tab[0].parent = -1;
    up_tab[0].system_app = 1; /* smss is the trusted system-process root */
    up_tab[0].proc = proc;
    up_set_image_name(&up_tab[0], "smss.exe");
    up_tab[0].entry = entry;
    up_tab[0].alive = 1;
    up_tab[0].fresh = 0;
    up_tab[0].rip = entry;
    up_tab[0].rsp = USER_STACK_TOP - sizeof(uint64_t);
    up_tab[0].rflags = 0x202;
    up_tab[0].rax = 0;

    up_n = 1;
    up_cur = 0;

    DbgPrint("user: pid=%lu enter smss %p\n",
             (unsigned long)proc->Pid, (void *)entry);

    uint64_t *s = (uint64_t *)ktop;

    *--s = USER_DS;
    *--s = USER_STACK_TOP - sizeof(uint64_t);
    *--s = 0x202;
    *--s = USER_CS;
    *--s = entry;

    /* Include the initial Windows x64 home/shadow-space page above RSP. */
    {
        uint64_t stack_sz = 0x10000ULL;
        uint64_t stack_lo = USER_STACK_TOP - stack_sz;

        for (uint64_t off = 0; off <= stack_sz; off += USER_IMAGE_PAGE) {
            uint64_t pa = pmm_alloc_zeroed();

            if (!pa) {
                DbgPrint("user: stack alloc fail\n");
                MmSwitchToProcess(PspSystemProcess);
                if (ki_current) ki_current->Process = PspSystemProcess;
                PspForgetUserImages(proc);
                PspForgetDiskModule(proc);
                MmDeleteAddressSpace(proc);
                return;
            }
            map_4k_in(proc->Pml4,
                      stack_lo + off, pa, PTE_U | PTE_RW | PTE_OWNED);
        }
    }

    if (!user_setup_teb(proc, USER_STACK_TOP - 0x10000ULL, USER_STACK_TOP)) {
        MmSwitchToProcess(PspSystemProcess);
        if (ki_current) ki_current->Process = PspSystemProcess;
        PspForgetUserImages(proc);
        PspForgetDiskModule(proc);
        MmDeleteAddressSpace(proc);
        return;
    }

    cpu_set_user_gs_base(USER_TEB_BASE);
    MmSwitchToProcess(proc);

    __asm__ volatile(
        "lea 1f(%%rip), %%rcx\n"
        "mov %%rcx, %[rip]\n"
        "mov %%rsp, %[rsp]\n"
        "mov %[frame], %%rsp\n"
        "swapgs\n"
        "iretq\n"
        "1:\n"
        : [rip] "=m"(user_saved_rip), [rsp] "=m"(user_saved_ksp)
        : [frame] "r"(s)
        : "rcx", "memory"
    );

    MmSwitchToProcess(PspSystemProcess);

    if (ki_current)
        ki_current->Process = PspSystemProcess;

    DbgPrint("user: all user processes exited, back in kernel\n");
}
