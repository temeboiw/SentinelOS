#pragma once
#include "ata.h"
#include "virtio_blk.h"
#include "block.h"
#include "partition.h"

#define E16(p,o) (*(uint16_t *)((uint8_t *)(p) + (o)))
#define E32(p,o) (*(uint32_t *)((uint8_t *)(p) + (o)))

typedef struct {
    uint64_t part_off, volume_bytes;
    SENTINEL_BLOCK_DEVICE *device;
    uint32_t blksz, ipg, isize, dsize, first_data, bpg;
    uint32_t feature_compat, feature_incompat, feature_ro_compat;
    uint64_t total_blocks,free_blocks,reserved_blocks;
    uint32_t total_inodes,free_inodes,volume_serial;
    char volume_label[17];
    int is64;
    uint8_t blk[4096];
    int ok;
    int write_faulted; /* Set if a failed write cannot be rolled back safely. */
} Ext4k;

static int SentinelVirtioBlockRead(void *context, uint64_t off, void *dst, uint64_t len) {
    (void)context;
    return vb_ok ? blk_read(off, dst, len) : -1;
}
static int SentinelVirtioBlockWrite(void *context, uint64_t off, const void *src, uint64_t len) {
    (void)context;
    return vb_ok ? blk_write(off, src, len) : -1;
}
static int SentinelAtaBlockRead(void *context, uint64_t off, void *dst, uint64_t len) {
    (void)context;
    return ata_present ? ata_read(off, dst, len) : -1;
}
static int SentinelAtaBlockWrite(void *context, uint64_t off, const void *src, uint64_t len) {
    (void)context;
    return ata_present ? ata_write(off, src, len) : -1;
}

/* Register available transports behind the common block-device interface.
 * New AHCI, NVMe, USB mass-storage, or other drivers can register here without
 * teaching ext4 about their controller-specific implementation. */
static int SentinelRegisterBuiltinBlockDevices(void) {
    int registered = 0;
    if (vb_ok) {
        SENTINEL_BLOCK_DEVICE d = {0};
        d.size = sizeof(d); d.abi_version = SENTINEL_BLOCK_ABI_VERSION;
        const char *name = "virtio-blk0";
        for (uint32_t i = 0; i < SENTINEL_BLOCK_NAME_MAX && name[i]; ++i) d.name[i] = name[i];
        const char *model = "VirtIO block device";
        for (uint32_t i = 0; i < sizeof(d.model)-1 && model[i]; ++i) d.model[i] = model[i];
        d.sector_size = 512; d.sector_count = vb_sectors;
        d.read = SentinelVirtioBlockRead; d.write = SentinelVirtioBlockWrite;
        if (SentinelBlockRegister(&d) == 0) ++registered;
    }
    if (ata_present) {
        SENTINEL_BLOCK_DEVICE d = {0};
        d.size = sizeof(d); d.abi_version = SENTINEL_BLOCK_ABI_VERSION;
        const char *name = "ata0";
        for (uint32_t i = 0; i < SENTINEL_BLOCK_NAME_MAX && name[i]; ++i) d.name[i] = name[i];
        for (uint32_t i = 0; i < sizeof(d.model)-1 && ata_model[i]; ++i) d.model[i] = ata_model[i];
        d.sector_size = 512; d.sector_count = ata_sector_count;
        d.read = SentinelAtaBlockRead; d.write = SentinelAtaBlockWrite;
        if (SentinelBlockRegister(&d) == 0) ++registered;
    }
    DbgPrint("block: registered %u device(s)\n", (unsigned)registered);
    return registered;
}

static int e4_read(Ext4k *fs, uint64_t off, void *dst, uint64_t len) {
    if (!fs || off > fs->volume_bytes || len > fs->volume_bytes - off ||
        fs->part_off > UINT64_MAX - off) return -1;
    if (fs->device)
        return SentinelBlockReadDevice(fs->device, fs->part_off + off, dst, len);
    return SentinelBlockRead(fs->part_off + off, dst, len);
}

/*
 * Byte-range disk writes use the same device selection as reads. The block
 * backends perform sector read/modify/write for unaligned ranges, which is
 * required for ext4 metadata and file tails.
 */
static int e4_raw_write(Ext4k *fs, uint64_t off,
                          const void *src, uint64_t len) {
    if (fs->device)
        return SentinelBlockWriteDevice(fs->device, fs->part_off + off, src, len);
    return SentinelBlockWrite(fs->part_off + off, src, len);
}

/*
 * Failure-contained byte write. Snapshot each bounded chunk before writing;
 * if the device reports failure, restore that exact range. If restoration
 * itself fails, permanently fence this mounted instance against further
 * writes so a later operation cannot compound known metadata damage.
 *
 * This handles reported I/O errors, not power loss or a device that lies about
 * successful writes. Filesystem-wide multi-block atomicity still requires a
 * persistent journal and is deliberately not claimed here.
 */
static int e4_bytes_equal(const uint8_t *a, const uint8_t *b, uint64_t n) {
    for (uint64_t i = 0; i < n; ++i) if (a[i] != b[i]) return 0;
    return 1;
}

/*
 * Failure-contained byte write. Verify successful writes by reading them back.
 * If the device reports failure or readback differs, restore the saved bytes.
 * Restoration is retried because ATA/virtio errors may be transient; if the
 * old bytes cannot be verified, fence the mounted filesystem against writes.
 * This is operation-level recovery, not power-loss recovery: that needs a
 * persistent journal and ordered flush/barrier support.
 */
static int e4_write(Ext4k *fs, uint64_t off, const void *src, uint64_t len) {
    if (!fs || !fs->ok || fs->write_faulted || (!src && len)) return -1;
    if (!len) return 0;
    if (len > fs->blksz || len > sizeof(fs->blk) || off > UINT64_MAX - len)
        return -1;

    uint8_t before[4096], verify[4096];
    if (e4_read(fs, off, before, len) < 0) return -1;
    int write_ok = 0;
    for (int attempt = 0; attempt < 3; ++attempt) {
        if (e4_raw_write(fs, off, src, len) == 0 &&
            e4_read(fs, off, verify, len) == 0 &&
            e4_bytes_equal(verify, (const uint8_t *)src, len)) {
            write_ok = 1;
            break;
        }
    }
    if (write_ok) return 0;

    for (int attempt = 0; attempt < 3; ++attempt) {
        if (e4_raw_write(fs, off, before, len) == 0 &&
            e4_read(fs, off, verify, len) == 0 &&
            e4_bytes_equal(verify, before, len))
            return -1;
    }
    fs->write_faulted = 1;
    fs->ok = 0;
    return -1;
}

static uint64_t e4_size(uint8_t *inode);
static uint64_t e4_map(Ext4k *fs, uint8_t *inode, uint32_t lb);

/*
 * Write bytes into already allocated extents of an existing inode.
 * This deliberately does not allocate blocks, grow files, or create names;
 * callers must stay within the inode's current size until the allocator and
 * directory transaction code are in place.
 */
static int e4_write_inode_at(Ext4k *fs, uint8_t *inode,
                             uint64_t pos, const void *src, uint64_t len) {
    if (!fs || !fs->ok || !inode || (!src && len)) return -1;
    uint64_t size = e4_size(inode);
    if (pos > size || len > size - pos) return -1;
    const uint8_t *in = (const uint8_t *)src;
    uint8_t block[4096];
    while (len) {
        uint32_t in_block = (uint32_t)(pos % fs->blksz);
        uint32_t n = fs->blksz - in_block;
        if ((uint64_t)n > len) n = (uint32_t)len;
        uint64_t physical = e4_map(fs, inode, (uint32_t)(pos / fs->blksz));
        if (!physical) return -1;
        if (in_block == 0 && n == fs->blksz) {
            if (e4_write(fs, physical * fs->blksz, in, n) < 0) return -1;
        } else {
            if (e4_read(fs, physical * fs->blksz, block, fs->blksz) < 0)
                return -1;
            for (uint32_t i = 0; i < n; ++i) block[in_block + i] = in[i];
            if (e4_write(fs, physical * fs->blksz, block, fs->blksz) < 0)
                return -1;
        }
        pos += n;
        in += n;
        len -= n;
    }
    return 0;
}

static int e4_mount_device(Ext4k *fs, SENTINEL_BLOCK_DEVICE *device,
                           uint64_t part_lba, uint64_t part_sectors) {
    uint8_t sb[1024];
    if (!fs || !device || !device->online || !device->sector_size ||
        part_lba > UINT64_MAX / device->sector_size ||
        part_sectors > UINT64_MAX / device->sector_size ||
        part_lba > device->sector_count ||
        part_sectors > device->sector_count - part_lba) return -1;
    fs->part_off = part_lba * (uint64_t)device->sector_size;
    fs->volume_bytes = part_sectors * (uint64_t)device->sector_size;
    fs->ok = 0;
    fs->device = device;
    if (fs->volume_bytes < 2048 ||
        SentinelBlockReadDevice(device, fs->part_off + 1024, sb, sizeof(sb)) < 0 ||
        E16(sb, 56) != 0xEF53) return -1;
    fs->blksz = 1024u << E32(sb, 24);
    fs->first_data = E32(sb, 20);
    fs->bpg = E32(sb, 32);
    fs->feature_compat = E32(sb, 92);
    fs->feature_incompat = E32(sb, 96);
    fs->feature_ro_compat = E32(sb, 100);
    fs->bpg = E32(sb, 32);
    fs->ipg = E32(sb, 40);
    fs->isize = E16(sb, 88);
    if (fs->isize < 128) fs->isize = 128;
    fs->is64 = (E32(sb, 96) & 0x80) != 0;
    fs->total_blocks=E32(sb,4);fs->free_blocks=E32(sb,12);fs->reserved_blocks=E32(sb,8);
    if(fs->is64){fs->total_blocks|=(uint64_t)E32(sb,0x150)<<32;fs->free_blocks|=(uint64_t)E32(sb,0x158)<<32;fs->reserved_blocks|=(uint64_t)E32(sb,0x154)<<32;}
    fs->total_inodes=E32(sb,0);fs->free_inodes=E32(sb,16);fs->volume_serial=E32(sb,104);
    for(int i=0;i<16;i++)fs->volume_label[i]=(char)sb[120+i];fs->volume_label[16]=0;
    fs->dsize = fs->is64 ? E16(sb, 254) : 32;
    if (!fs->dsize) fs->dsize = 32;
    if (fs->blksz > 4096 || fs->blksz < 1024 || !fs->ipg ||
        !fs->bpg || !fs->total_blocks || !fs->total_inodes ||
        fs->isize < 128 || fs->isize > 256 ||
        fs->dsize < 32 || fs->dsize > 64 ||
        fs->total_blocks > (UINT64_MAX / fs->blksz) ||
        fs->total_blocks > fs->volume_bytes / fs->blksz ||
        fs->part_off > UINT64_MAX - fs->total_blocks * fs->blksz)
        return -1;
    fs->write_faulted = 0;
    fs->ok = 1;
    return 0;
}


/*
 * Allocate one data block using ext4's block bitmap.
 * SentinelOS's formatter disables the journal, metadata_csum, and 64bit
 * features. Refuse other incompatible layouts instead of writing metadata
 * with assumptions that do not hold for that filesystem.
 */
/* Writable subset only: no journal, metadata checksums, bigalloc, 64-bit
   descriptors, or unknown incompatible features. Unsupported images stay read-only. */
static int e4_write_supported(Ext4k *fs) {
    if (!fs || !fs->ok || fs->is64 || fs->blksz != 4096 ||
        fs->dsize != 32 || !fs->bpg || !fs->ipg)
        return 0;
    if (fs->feature_compat & (0x0004u | 0x0020u)) return 0; /* journal or dir_index */
    if (fs->feature_ro_compat & (0x0010u | 0x0200u | 0x0400u))
        return 0; /* GDT checksum, bigalloc, metadata checksum */
    if (fs->feature_incompat & ~0x00000242u) return 0;
    return 1;
}

static int e4_alloc_block(Ext4k *fs, uint64_t *block_out) {
    if (!e4_write_supported(fs) || !block_out || !fs->free_blocks) return -1;
    uint8_t sb[1024], gd[64], old_gd[64], bitmap[4096], old_bitmap[4096];
    if (e4_read(fs, 1024, sb, sizeof(sb)) < 0) return -1;
    uint64_t usable = fs->total_blocks > fs->first_data ? fs->total_blocks - fs->first_data : 0;
    uint64_t groups = (usable + fs->bpg - 1) / fs->bpg;
    uint64_t gdt_off = (uint64_t)(fs->first_data + 1) * fs->blksz;
    for (uint64_t g = 0; g < groups; ++g) {
        uint64_t gd_off = gdt_off + g * fs->dsize;
        if (e4_read(fs, gd_off, gd, fs->dsize) < 0) return -1;
        uint16_t free_count = E16(gd, 12);
        if (!free_count) continue;
        uint64_t bb = E32(gd, 0);
        if (!bb || bb >= fs->total_blocks) return -1;
        uint64_t first = (uint64_t)fs->first_data + g * fs->bpg;
        if (first >= fs->total_blocks) break;
        uint64_t span = fs->total_blocks - first;
        if (span > fs->bpg) span = fs->bpg;
        if (e4_read(fs, bb * fs->blksz, bitmap, fs->blksz) < 0) return -1;
        for (uint64_t bit = 0; bit < span; ++bit) {
            if (bitmap[bit >> 3] & (uint8_t)(1u << (bit & 7))) continue;
            uint64_t block = first + bit;
            if (block < fs->first_data || block >= fs->total_blocks || !E32(sb, 12)) continue;
            for (uint32_t i = 0; i < fs->blksz; ++i) old_bitmap[i] = bitmap[i];
            for (uint32_t i = 0; i < fs->dsize; ++i) old_gd[i] = gd[i];
            bitmap[bit >> 3] |= (uint8_t)(1u << (bit & 7));
            E16(gd, 12) = (uint16_t)(free_count - 1);
            E32(sb, 12) = E32(sb, 12) - 1;
            if (e4_write(fs, bb * fs->blksz, bitmap, fs->blksz) < 0) return -1;
            if (e4_write(fs, gd_off, gd, fs->dsize) < 0) {
                if (e4_write(fs, bb * fs->blksz, old_bitmap, fs->blksz) < 0) {
                    fs->write_faulted = 1; fs->ok = 0;
                }
                return -1;
            }
            if (e4_write(fs, 1024, sb, sizeof(sb)) < 0) {
                int bad = 0;
                if (e4_write(fs, gd_off, old_gd, fs->dsize) < 0) bad = 1;
                if (e4_write(fs, bb * fs->blksz, old_bitmap, fs->blksz) < 0) bad = 1;
                if (bad) { fs->write_faulted = 1; fs->ok = 0; }
                return -1;
            }
            fs->free_blocks = E32(sb, 12);
            *block_out = block;
            return 0;
        }
        return -1;
    }
    return -1;
}
static int e4_inode(Ext4k *fs, uint32_t ino, uint8_t *out) {
    uint32_t g = (ino - 1) / fs->ipg, idx = (ino - 1) % fs->ipg;
    uint8_t gd[64];
    uint64_t gdt = (uint64_t)(fs->first_data + 1) * fs->blksz;
    if (e4_read(fs, gdt + (uint64_t)g * fs->dsize, gd, fs->dsize) < 0) return -1;
    uint64_t itab = E32(gd, 8);
    if (fs->is64) itab |= (uint64_t)E32(gd, 0x28) << 32;
    uint32_t n = fs->isize > 256 ? 256 : fs->isize;
    return e4_read(fs, itab * fs->blksz + (uint64_t)idx * fs->isize, out, n);
}

/*
 * Reserve an inode number using the ext4 inode bitmap. This is only a
 * reservation primitive: callers must initialize and persist the inode
 * before publishing a directory entry. Unsupported metadata-checksum and
 * bigalloc variants are refused rather than silently corrupting metadata.
 */
static int e4_alloc_inode(Ext4k *fs, uint32_t *out_ino) {
    if (!e4_write_supported(fs) || !out_ino || !fs->total_inodes ||
        fs->isize > 256 || !fs->ipg || !fs->free_inodes) return -1;
    uint64_t groups = ((uint64_t)fs->total_inodes + fs->ipg - 1) / fs->ipg;
    uint64_t gdt_off = (uint64_t)(fs->first_data + 1) * fs->blksz;
    uint8_t gd[64], old_gd[64], sb[1024], bitmap[4096], old_bitmap[4096];
    for (uint64_t g = 0; g < groups; ++g) {
        uint64_t gd_off = gdt_off + g * fs->dsize;
        if (e4_read(fs, gd_off, gd, fs->dsize) < 0) return -1;
        uint16_t free_count = E16(gd, 14);
        if (!free_count) continue;
        uint64_t ib = E32(gd, 4);
        if (!ib || ib >= fs->total_blocks ||
            e4_read(fs, ib * fs->blksz, bitmap, fs->blksz) < 0) return -1;
        uint64_t first_ino = g * fs->ipg;
        uint64_t span = fs->total_inodes > first_ino ? fs->total_inodes - first_ino : 0;
        if (span > fs->ipg) span = fs->ipg;
        for (uint64_t bit = 0; bit < span; ++bit) {
            uint8_t mask = (uint8_t)(1u << (bit & 7));
            if (bitmap[bit >> 3] & mask) continue;
            /* Inodes 1-10 are reserved by ext4 even if a damaged bitmap says free. */
            if (first_ino + bit + 1 < 11) continue;
            if (e4_read(fs, 1024, sb, sizeof(sb)) < 0 || E32(sb, 16) == 0)
                return -1;
            for (uint32_t i = 0; i < fs->blksz; ++i) old_bitmap[i] = bitmap[i];
            for (uint32_t i = 0; i < fs->dsize; ++i) old_gd[i] = gd[i];
            bitmap[bit >> 3] |= mask;
            E16(gd, 14) = (uint16_t)(free_count - 1);
            E32(sb, 16) = E32(sb, 16) - 1;
            if (e4_write(fs, ib * fs->blksz, bitmap, fs->blksz) < 0) return -1;
            if (e4_write(fs, gd_off, gd, fs->dsize) < 0) {
                if (e4_write(fs, ib * fs->blksz, old_bitmap, fs->blksz) < 0) {
                    fs->write_faulted = 1; fs->ok = 0;
                }
                return -1;
            }
            if (e4_write(fs, 1024, sb, sizeof(sb)) < 0) {
                int bad = 0;
                if (e4_write(fs, gd_off, old_gd, fs->dsize) < 0) bad = 1;
                if (e4_write(fs, ib * fs->blksz, old_bitmap, fs->blksz) < 0) bad = 1;
                if (bad) { fs->write_faulted = 1; fs->ok = 0; }
                return -1;
            }
            fs->free_inodes = E32(sb, 16);
            *out_ino = (uint32_t)(first_ino + bit + 1);
            return 0;
        }
        return -1;
    }
    return -1;
}


static int e4_inode_write(Ext4k *fs, uint32_t ino, const uint8_t *inode);

/*
 * Append one logical block to an inode whose extents are stored in the inode
 * root. Supports up to four root extents, merges physically adjacent blocks,
 * and refuses external extent trees rather than rewriting them incorrectly.
 * The caller owns rollback if a later write fails.
 */
static int e4_extent_append_root(Ext4k *fs, uint8_t *inode,
                                 uint32_t logical, uint64_t physical) {
    if (!fs || !fs->ok || !inode || !physical ||
        !(E32(inode, 32) & 0x80000u))
        return -1;
    uint8_t *root = inode + 40;
    if (E16(root, 0) != 0xF30A || E16(root, 6) != 0)
        return -2;
    uint16_t entries = E16(root, 2), max = E16(root, 4);
    if (max > 4 || entries > max || entries > 4) return -2;
    uint8_t *last = entries ? root + 12 + (entries - 1) * 12 : 0;
    if (last) {
        uint32_t start = E32(last, 0);
        uint16_t count = E16(last, 4) & 0x7FFFu;
        uint64_t pstart = ((uint64_t)E16(last, 6) << 32) | E32(last, 8);
        if (count && start + count == logical && pstart + count == physical &&
            count < 0x7FFFu) {
            E16(last, 4) = (uint16_t)(count + 1);
            return 0;
        }
        if (logical <= start) return -1;
    }
    if (entries >= max || entries >= 4) return -2;
    uint8_t *e = root + 12 + entries * 12;
    E32(e, 0) = logical;
    E16(e, 4) = 1;
    E16(e, 6) = (uint16_t)(physical >> 32);
    E32(e, 8) = (uint32_t)physical;
    E16(root, 2) = (uint16_t)(entries + 1);
    return 0;
}

/*
 * Grow a regular file and write bytes using inline extent-root entries.
 * Limited to files represented by at most four root extents. This intentionally
 * rejects unsupported extent trees and files larger than that format can map.
 * Allocation and metadata updates are not yet journaled, so failures may leak
 * a block; callers must not treat this as crash-atomic installation.
 */
static int e4_free_block(Ext4k *fs, uint64_t block) {
    if (!e4_write_supported(fs) || block < fs->first_data || block >= fs->total_blocks)
        return -1;
    uint64_t rel = block - fs->first_data;
    uint64_t group = rel / fs->bpg, bit = rel % fs->bpg;
    uint64_t gdt = (uint64_t)(fs->first_data + 1) * fs->blksz;
    uint64_t gd_off = gdt + group * fs->dsize;
    uint8_t gd[64], old_gd[64], sb[1024], bitmap[4096], old_bitmap[4096];
    if (e4_read(fs, gd_off, gd, fs->dsize) < 0) return -1;
    uint64_t bb = E32(gd, 0);
    if (!bb || bb >= fs->total_blocks ||
        e4_read(fs, bb * fs->blksz, bitmap, fs->blksz) < 0 ||
        e4_read(fs, 1024, sb, sizeof(sb)) < 0) return -1;
    uint8_t mask = (uint8_t)(1u << (bit & 7));
    if (!(bitmap[bit >> 3] & mask)) return 0;
    for (uint32_t i = 0; i < fs->blksz; ++i) old_bitmap[i] = bitmap[i];
    for (uint32_t i = 0; i < fs->dsize; ++i) old_gd[i] = gd[i];
    bitmap[bit >> 3] &= (uint8_t)~mask;
    E16(gd, 12) = (uint16_t)(E16(gd, 12) + 1);
    E32(sb, 12) = E32(sb, 12) + 1;
    if (e4_write(fs, bb * fs->blksz, bitmap, fs->blksz) < 0) return -1;
    if (e4_write(fs, gd_off, gd, fs->dsize) < 0) {
        if (e4_write(fs, bb * fs->blksz, old_bitmap, fs->blksz) < 0) {
            fs->write_faulted = 1; fs->ok = 0;
        }
        return -1;
    }
    if (e4_write(fs, 1024, sb, sizeof(sb)) < 0) {
        int bad = 0;
        if (e4_write(fs, gd_off, old_gd, fs->dsize) < 0) bad = 1;
        if (e4_write(fs, bb * fs->blksz, old_bitmap, fs->blksz) < 0) bad = 1;
        if (bad) { fs->write_faulted = 1; fs->ok = 0; }
        return -1;
    }
    fs->free_blocks = E32(sb, 12);
    return 0;
}

static int e4_write_inode_grow(Ext4k *fs, uint32_t ino,
                               uint64_t pos, const void *src, uint64_t len) {
    if (!fs || !fs->ok || !src || !len || !ino ||
        fs->blksz != 4096 || fs->is64 || fs->dsize != 32 ||
        pos > UINT32_MAX || len > UINT32_MAX - pos ||
        (fs->feature_ro_compat & (0x10u | 0x200u | 0x400u)) ||
        (fs->feature_incompat & ~0x00000242u))
        return -1;

    uint8_t original[256], inode[256], tail_backup[4096];
    if (e4_inode(fs, ino, original) < 0 ||
        (E16(original, 0) & 0xF000u) != 0x8000u ||
        !(E32(original, 32) & 0x80000u))
        return -1;
    for (uint32_t i = 0; i < fs->isize; ++i) inode[i] = original[i];

    uint64_t old_size = e4_size(original), end = pos + len;
    /* Only append is supported. This keeps rollback from needing to restore
       arbitrary existing file contents. */
    if (pos != old_size) return -1;
    uint64_t old_blocks = (old_size + fs->blksz - 1) / fs->blksz;
    uint64_t new_blocks = (end + fs->blksz - 1) / fs->blksz;
    if (new_blocks > UINT32_MAX) return -1;

    uint8_t *root = inode + 40;
    if (E16(root, 0) != 0xF30A || E16(root, 6) != 0 ||
        E16(root, 2) > 4 || E16(root, 4) != 4)
        return -1;

    /* Track up to four allocated physical runs; root extents have this same
       hard limit. This avoids a large kernel-stack allocation. */
    uint64_t run_start[4], run_count[4], runs = 0;
    uint64_t tail_physical = 0;
    int tail_saved = 0;
    if (old_size && (old_size % fs->blksz)) {
        tail_physical = e4_map(fs, original, (uint32_t)(old_size / fs->blksz));
        if (!tail_physical ||
            e4_read(fs, tail_physical * fs->blksz, tail_backup, fs->blksz) < 0)
            return -1;
        tail_saved = 1;
    }

    uint8_t zero[4096];
    for (uint32_t i = 0; i < fs->blksz; ++i) zero[i] = 0;
    for (uint64_t lb = old_blocks; lb < new_blocks; ++lb) {
        uint64_t physical = 0;
        if (e4_alloc_block(fs, &physical) < 0) goto rollback;
        if (runs && run_start[runs - 1] + run_count[runs - 1] == physical) {
            ++run_count[runs - 1];
        } else {
            if (runs >= 4) {
                (void)e4_free_block(fs, physical);
                goto rollback;
            }
            run_start[runs] = physical;
            run_count[runs] = 1;
            ++runs;
        }
        if (e4_write(fs, physical * fs->blksz, zero, fs->blksz) < 0)
            goto rollback;
        if (e4_extent_append_root(fs, inode, (uint32_t)lb, physical) < 0)
            goto rollback;
        E32(inode, 28) += fs->blksz / 512;
    }

    E32(inode, 4) = (uint32_t)end;
    if (fs->isize >= 112) E32(inode, 108) = (uint32_t)(end >> 32);
    if (e4_inode_write(fs, ino, inode) < 0) goto rollback;
    if (e4_write_inode_at(fs, inode, pos, src, len) < 0) goto rollback;
    if (e4_inode_write(fs, ino, inode) < 0) goto rollback;
    return 0;

rollback:
    (void)e4_inode_write(fs, ino, original);
    if (tail_saved)
        (void)e4_write(fs, tail_physical * fs->blksz, tail_backup, fs->blksz);
    while (runs) {
        --runs;
        for (uint64_t n = 0; n < run_count[runs]; ++n)
            (void)e4_free_block(fs, run_start[runs] + n);
    }
    return -1;
}

/* Persist an inode record without disturbing adjacent inode-table entries. */
static int e4_inode_write(Ext4k *fs, uint32_t ino, const uint8_t *inode) {
    if (!fs || !fs->ok || !inode || !ino || ino > fs->total_inodes ||
        fs->isize > 256)
        return -1;
    uint32_t group = (ino - 1) / fs->ipg;
    uint32_t index = (ino - 1) % fs->ipg;
    uint8_t gd[64];
    uint64_t gdt = (uint64_t)(fs->first_data + 1) * fs->blksz;
    if (e4_read(fs, gdt + (uint64_t)group * fs->dsize, gd, fs->dsize) < 0)
        return -1;
    uint64_t inode_table = E32(gd, 8);
    if (fs->is64) inode_table |= (uint64_t)E32(gd, 0x28) << 32;
    return e4_write(fs,
                    inode_table * fs->blksz + (uint64_t)index * fs->isize,
                    inode, fs->isize);
}

/*
 * Allocate and initialize an empty regular-file inode. This does not publish
 * a name in a directory and must not be mistaken for complete file creation.
 * Bitmap/counter reservation and inode write are not transactional yet.
 */
static int e4_free_inode(Ext4k *fs, uint32_t ino);

static int e4_create_empty_file_inode(Ext4k *fs, uint32_t *out_ino) {
    if (!fs || !fs->ok || !out_ino || fs->isize < 128 || fs->isize > 256)
        return -1;
    uint32_t ino = 0;
    int rc = e4_alloc_inode(fs, &ino);
    if (rc < 0) return rc;

    uint8_t inode[256];
    for (uint32_t i = 0; i < fs->isize; ++i) inode[i] = 0;
    E16(inode, 0) = 0100644; /* regular file, rw-r--r-- */
    E32(inode, 4) = 0;
    E16(inode, 26) = 1;
    E32(inode, 28) = 0;
    E32(inode, 32) = 0x00080000u; /* EXT4_EXTENTS_FL */
    E16(inode, 40) = 0xF30A;
    E16(inode, 42) = 0;
    E16(inode, 44) = 4;
    E16(inode, 46) = 0;
    E32(inode, 48) = 0;
    if (fs->isize >= 130)
        E16(inode, 128) = (uint16_t)(fs->isize - 128 >= 32 ? 32 : fs->isize - 128);
    if (e4_inode_write(fs, ino, inode) < 0) {
        (void)e4_free_inode(fs, ino);
        return -1;
    }
    *out_ino = ino;
    return 0;
}

/*
 * Allocate one ext4 data block from an existing block group's bitmap.
 * Deliberately refuses metadata-checksummed and bigalloc filesystems because
 * those require checksum/cluster accounting updates that this small VFS does
 * not yet implement. Callers must subsequently attach the block to an inode.
 */


static uint64_t e4_size(uint8_t *inode) {
    return E32(inode, 4) | ((uint64_t)E32(inode, 108) << 32);
}

static uint64_t e4_map(Ext4k *fs, uint8_t *inode, uint32_t lb) {
    if (!(E32(inode, 32) & 0x80000)) return 0;
    uint8_t *node = inode + 40;
    for (int depth = 0; depth < 5; depth++) {
        if (E16(node, 0) != 0xF30A) return 0;
        uint16_t n = E16(node, 2);
        uint16_t depth_v = E16(node, 6);
        uint8_t *e = node + 12;
        if (depth_v == 0) {
            for (uint16_t i = 0; i < n; i++, e += 12) {
                uint32_t ee = E32(e, 0);
                uint16_t len = E16(e, 4) & 0x7FFF;
                if (lb >= ee && lb < ee + len) {
                    uint64_t start = ((uint64_t)E16(e, 6) << 32) | E32(e, 8);
                    return start + (lb - ee);
                }
            }
            return 0;
        }
        uint64_t leaf = 0;
        for (uint16_t i = 0; i < n; i++, e += 12) {
            if (E32(e, 0) <= lb)
                leaf = ((uint64_t)E16(e, 8) << 32) | E32(e, 4);
        }
        if (!leaf || e4_read(fs, leaf * fs->blksz, fs->blk, fs->blksz) < 0) return 0;
        node = fs->blk;
    }
    return 0;
}


/* Resolve one logical block and the remaining contiguous blocks in its
 * extent. Bulk file reads use this to avoid re-reading an extent-tree node
 * for every 4 KiB block of large files. */
static uint64_t e4_map_run(Ext4k *fs, uint8_t *inode, uint32_t lb,
                           uint32_t *run_out) {
    if (run_out) *run_out = 0;
    if (!fs || !inode || !run_out || !(E32(inode, 32) & 0x80000)) return 0;
    uint8_t *node = inode + 40;
    for (int depth = 0; depth < 5; depth++) {
        if (E16(node, 0) != 0xF30A) return 0;
        uint16_t n = E16(node, 2);
        uint16_t depth_v = E16(node, 6);
        uint8_t *e = node + 12;
        if (depth_v == 0) {
            for (uint16_t i = 0; i < n; i++, e += 12) {
                uint32_t first = E32(e, 0);
                uint32_t len = E16(e, 4) & 0x7FFF;
                if (len && lb >= first && lb - first < len) {
                    uint64_t start = ((uint64_t)E16(e, 6) << 32) | E32(e, 8);
                    *run_out = len - (lb - first);
                    return start + (lb - first);
                }
            }
            return 0;
        }
        uint64_t leaf = 0;
        for (uint16_t i = 0; i < n; i++, e += 12) {
            if (E32(e, 0) <= lb)
                leaf = ((uint64_t)E16(e, 8) << 32) | E32(e, 4);
        }
        if (!leaf || e4_read(fs, leaf * fs->blksz, fs->blk, fs->blksz) < 0)
            return 0;
        node = fs->blk;
    }
    return 0;
}

static uint32_t e4_lookup(Ext4k *fs, uint32_t dir, const char *name) {
    uint8_t inode[256];
    if (e4_inode(fs, dir, inode) < 0) return 0;
    int nl = 0; while (name[nl]) nl++;
    uint64_t size = e4_size(inode);
    static uint8_t buf[4096];
    for (uint64_t pos = 0; pos < size; pos += fs->blksz) {
        uint64_t pb = e4_map(fs, inode, (uint32_t)(pos / fs->blksz));
        if (!pb || e4_read(fs, pb * fs->blksz, buf, fs->blksz) < 0) continue;
        for (uint32_t o = 0; o + 8 <= fs->blksz; ) {
            uint16_t rl = E16(buf, o + 4);
            if (rl < 8) break;
            uint8_t namelen = buf[o + 6];
            if (E32(buf, o) && namelen == nl) {
                int i = 0;
                while (i < nl) {
                    char a = (char)buf[o + 8 + i];
                    char b = name[i];
                    if (a >= 'A' && a <= 'Z') a = (char)(a + ('a' - 'A'));
                    if (b >= 'A' && b <= 'Z') b = (char)(b + ('a' - 'A'));
                    if (a != b) break;
                    i++;
                }
                if (i == nl) return E32(buf, o);
            }
            o += rl;
        }
    }
    return 0;
}



/* Best-effort inverse for a block successfully returned by e4_alloc_block. */


/* Best-effort inverse for an inode successfully returned by e4_alloc_inode. */
static int e4_free_inode(Ext4k *fs, uint32_t ino) {
    if (!e4_write_supported(fs) || !ino || ino > fs->total_inodes) return -1;
    uint32_t group = (ino - 1) / fs->ipg, bit = (ino - 1) % fs->ipg;
    uint64_t gdt = (uint64_t)(fs->first_data + 1) * fs->blksz;
    uint64_t gd_off = gdt + (uint64_t)group * fs->dsize;
    uint8_t gd[64], old_gd[64], sb[1024], bitmap[4096], old_bitmap[4096];
    if (e4_read(fs, gd_off, gd, fs->dsize) < 0) return -1;
    uint64_t ib = E32(gd, 4);
    if (!ib || ib >= fs->total_blocks ||
        e4_read(fs, ib * fs->blksz, bitmap, fs->blksz) < 0 ||
        e4_read(fs, 1024, sb, sizeof(sb)) < 0) return -1;
    uint8_t mask = (uint8_t)(1u << (bit & 7));
    if (!(bitmap[bit >> 3] & mask)) return 0;
    for (uint32_t i = 0; i < fs->blksz; ++i) old_bitmap[i] = bitmap[i];
    for (uint32_t i = 0; i < fs->dsize; ++i) old_gd[i] = gd[i];
    bitmap[bit >> 3] &= (uint8_t)~mask;
    E16(gd, 14) = (uint16_t)(E16(gd, 14) + 1);
    E32(sb, 16) = E32(sb, 16) + 1;
    if (e4_write(fs, ib * fs->blksz, bitmap, fs->blksz) < 0) return -1;
    if (e4_write(fs, gd_off, gd, fs->dsize) < 0) {
        if (e4_write(fs, ib * fs->blksz, old_bitmap, fs->blksz) < 0) {
            fs->write_faulted = 1; fs->ok = 0;
        }
        return -1;
    }
    if (e4_write(fs, 1024, sb, sizeof(sb)) < 0) {
        int bad = 0;
        if (e4_write(fs, gd_off, old_gd, fs->dsize) < 0) bad = 1;
        if (e4_write(fs, ib * fs->blksz, old_bitmap, fs->blksz) < 0) bad = 1;
        if (bad) { fs->write_faulted = 1; fs->ok = 0; }
        return -1;
    }
    fs->free_inodes = E32(sb, 16);
    return 0;
}

/*
 * Insert a regular-file name into slack space in an existing directory block.
 * Does not grow directories; returns failure if no safe slot exists. Caller
 * must initialize the child inode first and handle rollback on failure.
 */
/* Discard an unpublished regular file and reclaim its inline extent blocks.
   This is best-effort rollback, not crash recovery or a substitute for journaling. */
static int e4_discard_file_inode(Ext4k *fs, uint32_t ino) {
    if (!e4_write_supported(fs) || !ino || fs->write_faulted) return -1;
    uint8_t inode[256], zero_inode[256];
    uint64_t starts[4], counts[4], nruns = 0;
    if (e4_inode(fs, ino, inode) < 0) return -1;
    if ((E16(inode, 0) & 0xF000u) == 0x8000u &&
        (E32(inode, 32) & 0x80000u)) {
        uint8_t *root = inode + 40;
        if (E16(root, 0) != 0xF30A || E16(root, 6) != 0 ||
            E16(root, 2) > 4) return -1;
        uint16_t entries = E16(root, 2);
        for (uint16_t i = 0; i < entries; ++i) {
            uint8_t *ex = root + 12 + i * 12;
            uint32_t count = E16(ex, 4) & 0x7FFFu;
            uint64_t physical = ((uint64_t)E16(ex, 6) << 32) | E32(ex, 8);
            if (!count || !physical || nruns >= 4 ||
                physical >= fs->total_blocks ||
                count > fs->total_blocks - physical)
                return -1;
            starts[nruns] = physical;
            counts[nruns++] = count;
        }
    }
    /* Unpublish the inode before returning any of its blocks to the allocator. */
    for (uint32_t i = 0; i < fs->isize; ++i) zero_inode[i] = 0;
    if (e4_inode_write(fs, ino, zero_inode) < 0) return -1;
    for (uint64_t r = 0; r < nruns; ++r)
        for (uint64_t n = 0; n < counts[r]; ++n)
            if (e4_free_block(fs, starts[r] + n) < 0) return -1;
    return e4_free_inode(fs, ino);
}

static int e4_dir_add_file(Ext4k *fs, uint32_t dir_ino,
                           const char *name, uint32_t child_ino) {
    if (!e4_write_supported(fs) || !name || !child_ino || !dir_ino || fs->write_faulted)
        return -1;
    uint32_t nl = 0;
    while (name[nl] && nl < 256) {
        if (name[nl] == '/' || name[nl] == '\\') return -1;
        ++nl;
    }
    if (!nl || nl > 255 || name[0] == '.' || e4_lookup(fs, dir_ino, name))
        return -1;

    uint8_t dir[256];
    if (e4_inode(fs, dir_ino, dir) < 0) return -1;
    if ((E16(dir, 0) & 0xF000u) != 0x4000u) return -1;
    uint64_t size = e4_size(dir);
    uint32_t need = (8u + nl + 3u) & ~3u;
    uint8_t block[4096], original_block[4096];

    for (uint64_t pos = 0; pos < size; pos += fs->blksz) {
        uint64_t pb = e4_map(fs, dir, (uint32_t)(pos / fs->blksz));
        if (!pb || e4_read(fs, pb * fs->blksz, block, fs->blksz) < 0)
            return -1;
        for (uint32_t bi = 0; bi < fs->blksz; ++bi) original_block[bi] = block[bi];
        for (uint32_t off = 0; off + 8 <= fs->blksz; ) {
            uint32_t ino = E32(block, off);
            uint16_t rec = E16(block, off + 4);
            uint8_t old_nl = block[off + 6];
            if (rec < 8 || (rec & 3u) || rec > fs->blksz - off)
                return -1;
            uint32_t used = (8u + old_nl + 3u) & ~3u;
            if (ino == 0 && rec >= need) {
                E32(block, off) = child_ino;
                E16(block, off + 4) = rec;
                block[off + 6] = (uint8_t)nl;
                block[off + 7] = 1; /* EXT4_FT_REG_FILE */
                for (uint32_t j = 0; j < nl; ++j) block[off + 8 + j] = (uint8_t)name[j];
                if (e4_write(fs, pb * fs->blksz, block, fs->blksz) < 0) return -1;
                /* Confirm the directory entry reached stable readable media. */
                uint8_t check[4096];
                if (e4_read(fs, pb * fs->blksz, check, fs->blksz) < 0 ||
                    E32(check, off) != child_ino || check[off + 6] != nl) {
                    if (e4_write(fs, pb * fs->blksz, original_block, fs->blksz) < 0) {
                        fs->write_faulted = 1; fs->ok = 0;
                    }
                    return -1;
                }
                for (uint32_t j = 0; j < nl; ++j) if (check[off + 8 + j] != (uint8_t)name[j]) {
                    if (e4_write(fs, pb * fs->blksz, original_block, fs->blksz) < 0) {
                        fs->write_faulted = 1; fs->ok = 0;
                    }
                    return -1;
                }
                return 0;
            }
            if (ino != 0 && used <= rec && rec - used >= need) {
                E16(block, off + 4) = (uint16_t)used;
                uint32_t noff = off + used;
                E32(block, noff) = child_ino;
                E16(block, noff + 4) = (uint16_t)(rec - used);
                block[noff + 6] = (uint8_t)nl;
                block[noff + 7] = 1;
                for (uint32_t j = 0; j < nl; ++j) block[noff + 8 + j] = (uint8_t)name[j];
                if (e4_write(fs, pb * fs->blksz, block, fs->blksz) < 0) return -1;
                uint8_t check[4096];
                if (e4_read(fs, pb * fs->blksz, check, fs->blksz) < 0 ||
                    E32(check, noff) != child_ino || check[noff + 6] != nl) {
                    if (e4_write(fs, pb * fs->blksz, original_block, fs->blksz) < 0) {
                        fs->write_faulted = 1; fs->ok = 0;
                    }
                    return -1;
                }
                for (uint32_t j = 0; j < nl; ++j) if (check[noff + 8 + j] != (uint8_t)name[j]) {
                    if (e4_write(fs, pb * fs->blksz, original_block, fs->blksz) < 0) {
                        fs->write_faulted = 1; fs->ok = 0;
                    }
                    return -1;
                }
                return 0;
            }
            off += rec;
        }
    }
    return -2; /* directory has no suitable slack; growth is not implemented */
}



/*
 * Extend a directory by one block and put a single file entry in that block.
 * Inline extent-root only; metadata rollback is best-effort and cannot recover
 * from power loss or a failed rollback write.
 */
static int e4_dir_grow_add_file(Ext4k *fs, uint32_t dir_ino,
                                const char *name, uint32_t child_ino) {
    if (!fs || !fs->ok || !name || !child_ino || fs->is64 ||
        fs->blksz != 4096) return -1;
    uint8_t dir[256], block[4096];
    if (e4_inode(fs, dir_ino, dir) < 0 ||
        (E16(dir, 0) & 0xF000u) != 0x4000u) return -1;
    uint8_t original[256];
    for (uint32_t i = 0; i < fs->isize; ++i) original[i] = dir[i];
    uint64_t old_size = e4_size(dir);
    if (old_size % fs->blksz) return -1;
    uint64_t lb = old_size / fs->blksz;
    if (lb > UINT32_MAX) return -1;
    uint64_t physical = 0;
    if (e4_alloc_block(fs, &physical) < 0) return -1;
    for (uint32_t i = 0; i < fs->blksz; ++i) block[i] = 0;
    E32(block, 0) = child_ino;
    E16(block, 4) = (uint16_t)fs->blksz;
    uint32_t nl = 0;
    while (name[nl] && nl < 255) ++nl;
    if (!nl || name[nl]) { e4_free_block(fs, physical); return -1; }
    block[6] = (uint8_t)nl;
    block[7] = 1;
    for (uint32_t i = 0; i < nl; ++i) block[8 + i] = (uint8_t)name[i];
    if (e4_write(fs, physical * fs->blksz, block, fs->blksz) < 0) {
        e4_free_block(fs, physical); return -1;
    }
    if (e4_extent_append_root(fs, dir, (uint32_t)lb, physical) < 0) {
        e4_free_block(fs, physical); return -1;
    }
    E32(dir, 4) = (uint32_t)(old_size + fs->blksz);
    E32(dir, 28) += fs->blksz / 512;
    if (e4_inode_write(fs, dir_ino, dir) < 0) {
        (void)e4_inode_write(fs, dir_ino, original);
        (void)e4_free_block(fs, physical);
        return -1;
    }
    uint8_t verify_inode[256];
    if (e4_inode(fs, dir_ino, verify_inode) < 0 ||
        e4_size(verify_inode) != old_size + fs->blksz ||
        e4_map(fs, verify_inode, (uint32_t)lb) != physical) {
        if (e4_inode_write(fs, dir_ino, original) < 0) {
            fs->write_faulted = 1; fs->ok = 0;
        }
        if (e4_free_block(fs, physical) < 0) {
            fs->write_faulted = 1; fs->ok = 0;
        }
        return -1;
    }
    return 0;
}

/*
 * Compose the existing inode and directory primitives into a named empty
 * regular file. Directory space is checked before reserving the inode, but
 * disk I/O failures can still leave an allocated, unreachable inode; full
 * journaling/rollback and directory growth remain future work.
 */
static int e4_create_empty_file(Ext4k *fs, uint32_t dir_ino,
                                const char *name, uint32_t *out_ino) {
    if (!fs || !fs->ok || !name || !out_ino || !dir_ino) return -1;
    uint32_t nl = 0;
    while (name[nl] && nl < 256) {
        if (name[nl] == '/' || name[nl] == '\\') return -1;
        ++nl;
    }
    if (!nl || nl > 255 || name[0] == '.' ||
        e4_lookup(fs, dir_ino, name))
        return -1;

    uint8_t dir[256];
    if (e4_inode(fs, dir_ino, dir) < 0 ||
        (E16(dir, 0) & 0xF000u) != 0x4000u)
        return -1;

    uint32_t ino = 0;
    if (e4_create_empty_file_inode(fs, &ino) < 0) return -1;
    int drc = e4_dir_add_file(fs, dir_ino, name, ino);
    if (drc == -2) drc = e4_dir_grow_add_file(fs, dir_ino, name, ino);
    if (drc < 0) { (void)e4_discard_file_inode(fs, ino); return -1; }
    *out_ino = ino;
    return 0;
}


/*
 * Create a named file and populate it. Metadata writes are not journaled;
 * failures may leave an incomplete published entry and require recovery.
 */
static int e4_create_file_with_data(Ext4k *fs, uint32_t dir_ino,
                                    const char *name, const void *data,
                                    uint64_t len, uint32_t *out_ino) {
    if (!fs || !fs->ok || !name || !data || !len || !out_ino ||
        len > UINT32_MAX || !dir_ino)
        return -1;

    /* Validate the parent and reject duplicates before reserving resources. */
    uint8_t dir[256];
    if (e4_inode(fs, dir_ino, dir) < 0 ||
        (E16(dir, 0) & 0xF000u) != 0x4000u ||
        e4_lookup(fs, dir_ino, name))
        return -1;

    /* Keep the inode unreachable until its payload is written successfully. */
    uint32_t ino = 0;
    if (e4_create_empty_file_inode(fs, &ino) < 0) return -1;
    if (e4_write_inode_grow(fs, ino, 0, data, len) < 0) {
        /* No directory entry was published; inode/data cleanup is best-effort. */
        (void)e4_discard_file_inode(fs, ino);
        return -1;
    }

    int rc = e4_dir_add_file(fs, dir_ino, name, ino);
    if (rc == -2) rc = e4_dir_grow_add_file(fs, dir_ino, name, ino);
    if (rc < 0) {
        (void)e4_discard_file_inode(fs, ino);
        return -1;
    }
    *out_ino = ino;
    return 0;
}

#define VFS_MAX_ENT 1024
typedef struct { char name[256]; uint8_t is_dir; uint32_t ino; } VfsEnt;
static VfsEnt vfs_ents[VFS_MAX_ENT];
static int vfs_nent;
static Ext4k g_ext4;
static int g_ext4_ok;
static uint32_t vfs_parent_ino;
#define VFS_MAX_DEPTH 64
static uint32_t vfs_dir_stack[VFS_MAX_DEPTH];
static int vfs_depth;
static char vfs_cwd[128];
static uint32_t vfs_cwd_ino = 2;

static int vfs_listdir(uint32_t dir_ino) {
    uint8_t inode[256];
    vfs_nent = 0;
    /* The NTFS path can reach this legacy ext4 cache through file-close and
       output-file syscall paths. Never use the unmounted ext4 volume's zero
       block size as a divisor. */
    if (!g_ext4_ok || !g_ext4.blksz || g_ext4.blksz > sizeof(g_ext4.blk))
        return -1;
    if (e4_inode(&g_ext4, dir_ino, inode) < 0) return -1;
    uint64_t size = e4_size(inode);
    static uint8_t buf[4096];
    for (uint64_t pos = 0; pos < size && vfs_nent < VFS_MAX_ENT; pos += g_ext4.blksz) {
        uint64_t pb = e4_map(&g_ext4, inode, (uint32_t)(pos / g_ext4.blksz));
        if (!pb || e4_read(&g_ext4, pb * g_ext4.blksz, buf, g_ext4.blksz) < 0) continue;
        for (uint32_t o = 0; o + 8 <= g_ext4.blksz && vfs_nent < VFS_MAX_ENT; ) {
            uint16_t rl = E16(buf, o + 4);
            if (rl < 8) break;
            uint32_t ino = E32(buf, o);
            uint8_t nl = buf[o + 6];
            uint8_t ft = buf[o + 7];
            if (ino && nl > 0) {
                if (!(nl == 1 && buf[o + 8] == '.') &&
                    !(nl == 2 && buf[o + 8] == '.' && buf[o + 9] == '.')) {
                    VfsEnt *e = &vfs_ents[vfs_nent++];
                    for (int i = 0; i < nl; i++) e->name[i] = (char)buf[o + 8 + i];
                    e->name[nl] = 0;
                    e->ino = ino;
                    /*
                     * Do not rely solely on the directory-entry file_type.
                     * Some ext filesystems omit that field or have entries
                     * whose type is unknown. The inode's i_mode is authoritative.
                     */
                    e->is_dir = (ft == 2);
                    {
                        uint8_t in2[256];
                        if (e4_inode(&g_ext4, ino, in2) == 0) {
                            uint16_t mode = E16(in2, 0) & 0xF000;
                            if (mode == 0x4000) e->is_dir = 1;
                            else if (mode == 0x8000 || mode == 0xA000 ||
                                     mode == 0x2000 || mode == 0x6000 ||
                                     mode == 0x1000 || mode == 0xC000)
                                e->is_dir = 0;
                        }
                    }
                }
            }
            o += rl;
        }
    }
    return vfs_nent;
}

static int vfs_partition_read(void *context,uint64_t offset,void *dst,uint64_t len) {
    return SentinelBlockReadDevice((SENTINEL_BLOCK_DEVICE *)context,offset,dst,len);
}


static int vfs_chdir(const char *name) {
    if (!name || !name[0]) return -1;
    /* parent */
    if (name[0]=='.' && name[1]=='.' && name[2]==0) {
        if (vfs_depth <= 0) return 0;
        vfs_cwd_ino = vfs_dir_stack[--vfs_depth];
        vfs_parent_ino = vfs_depth > 0 ? vfs_dir_stack[vfs_depth - 1] : 2;
        return vfs_listdir(vfs_cwd_ino) >= 0 ? 0 : -1;
    }
    for (int i = 0; i < vfs_nent; i++) {
        const char *a = vfs_ents[i].name, *b = name;
        int ok = 1;
        while (*a || *b) { if (*a++ != *b++) { ok = 0; break; } }
        if (!ok) continue;
        if (!vfs_ents[i].is_dir) return -2;
        if (vfs_depth >= VFS_MAX_DEPTH) return -1;
        vfs_dir_stack[vfs_depth++] = vfs_cwd_ino;
        vfs_parent_ino = vfs_cwd_ino;
        vfs_cwd_ino = vfs_ents[i].ino;
        return vfs_listdir(vfs_cwd_ino) >= 0 ? 0 : -1;
    }
    return -1;
}

static int vfs_mount_c(void) {
    SENTINEL_PARTITION partitions[SENTINEL_PARTITION_MAX];
    int mounted = 0;
    for (uint32_t i=0;i<SentinelBlockDeviceCount&&!mounted;i++) {
        SENTINEL_BLOCK_DEVICE *device=SentinelBlockGet(i);
        if(!device||!device->sector_size||device->sector_count>UINT64_MAX/device->sector_size)continue;
        int count=SentinelPartitionScan(vfs_partition_read,device,device->sector_count,
                                        device->sector_size,partitions,SENTINEL_PARTITION_MAX);
        if(count<0){DbgPrint("fs: %s partition scan failed (%d)\n",device->name,count);continue;}
        for(int p=0;p<count;p++) {
            Ext4k candidate={0};
            if(e4_mount_device(&candidate,device,partitions[p].first_lba,
                               partitions[p].sector_count)==0) {
                g_ext4=candidate;
                DbgPrint("fs: ext4 on %s partition %d at LBA %llu (%llu sectors)\n",
                         device->name,p,(unsigned long long)partitions[p].first_lba,
                         (unsigned long long)partitions[p].sector_count);
                mounted=1;break;
            }
        }
    }
    if(!mounted){DbgPrint("fs: no valid ext4 partition found\n");return -1;}
    vfs_cwd_ino = 2;
    vfs_parent_ino = 2;
    vfs_depth = 0;
    vfs_cwd[0] = 67;
    vfs_cwd[1] = 58;
    vfs_cwd[2] = 92;
    vfs_cwd[3] = 0;
    vfs_listdir(2);
    g_ext4_ok = 1;
    DbgPrint("fs: C: volume root");
    return 0;
}
