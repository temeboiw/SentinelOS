/*
 * SentinelOS VirGL GPU triangle test.
 * Freestanding C++ PE: no CRT, exceptions, RTTI, or import libraries.
 * Submits a spinning, perspective-projected 3D triangle through the existing
 * VirGL vertex-buffer and render-target resources. VirGL executes TGSI vertex
 * and fragment shaders and rasterizes the triangle; CPU code animates the
 * triangle's three input vertices. This is not a Vulkan graphics-pipeline test.
 */
#include <stdint.h>
#include "virgl_protocol.h"
#include "../user/soft3d.h"
#include "../user/font8x8.h"

using u64 = unsigned long long;
using u32 = unsigned int;
using i32 = int;
using BOOL = int;
using LPCSTR = const char *;

enum : u64 { SYS_TERMINATE_PROCESS=0, SYS_WRITE_FILE=1, SYS_GET_PROC_ADDRESS=9,
             SYS_GET_INPUT=10, SYS_GET_TICK_COUNT=24, SYS_GRAPHICS_INFO=32,
             SYS_FLUSH_GRAPHICS=33, SYS_YIELD=21, SYS_GAME_KEY_STATE=38, SYS_GAME_MOUSE_DELTA=39, SYS_SUBMIT_3D=34, SYS_PRESENT_LAYER=37 };

static u64 syscall3(u64 n,u64 a,u64 b,u64 c) {
    u64 r;
    __asm__ volatile("mov %[n], %%rax\nmov %[a], %%rdi\nmov %[b], %%rsi\nmov %[c], %%rdx\nint $0x80\nmov %%rax, %[r]"
      : [r]"=r"(r):[n]"r"(n),[a]"r"(a),[b]"r"(b),[c]"r"(c):"rax","rdi","rsi","rdx","memory","cc");
    return r;
}
static void *get_proc(const char *dll,const char *name) {
    return (void*)(uintptr_t)syscall3(SYS_GET_PROC_ADDRESS,(u64)dll,(u64)name,0);
}
static void print(const char *s) {
    u64 n=0; while(s[n]) ++n; (void)syscall3(SYS_WRITE_FILE,1,(u64)s,n);
}
static void print_hex(u64 v) {
    static const char digits[]="0123456789ABCDEF";
    char out[19];out[0]='0';out[1]='x';
    for(int i=0;i<16;i++)out[2+i]=digits[(v>>((15-i)*4))&15u];
    out[18]=0;print(out);
}

using CreateWindowExA_t=void*(*)(u32,LPCSTR,LPCSTR,u32,int,int,int,int,void*,void*,void*,void*);
using ShowWindow_t=BOOL(*)(void*,int);
using GetMessageA_t=BOOL(*)(void*,void*,u32,u32);
using PeekMessageA_t=BOOL(*)(void*,void*,u32,u32,u32);
using TranslateMessage_t=BOOL(*)(const void*);
using DispatchMessageA_t=long long(*)(const void*);
using UpdateWindow_t=BOOL(*)(void*);
struct ClipRect { int left,top,right,bottom; };
using ShowCursor_t=int(*)(BOOL);
using SetCursorPos_t=BOOL(*)(int,int);
using ClipCursor_t=BOOL(*)(const ClipRect*);
using VkCreateInstance_t=int(__attribute__((ms_abi)) *)(const void*,const void*,void**);
using VkEnumerateInstanceVersion_t=int(__attribute__((ms_abi)) *)(u32*);
using VkGetInstanceProcAddr_t=void*(__attribute__((ms_abi)) *)(void*,const char*);
using VkEnumeratePhysicalDevices_t=int(__attribute__((ms_abi)) *)(void*,u32*,void**);
using VkGetPhysicalDeviceQueueFamilyProperties_t=void(__attribute__((ms_abi)) *)(void*,u32*,void*);
using VkCreateDevice_t=int(__attribute__((ms_abi)) *)(void*,const void*,const void*,void**);
using VkGetDeviceQueue_t=void(__attribute__((ms_abi)) *)(void*,u32,u32,void**);
using VkDestroyDevice_t=void(__attribute__((ms_abi)) *)(void*,const void*);
using VkDestroyInstance_t=void(__attribute__((ms_abi)) *)(void*,const void*);
using VkDeviceWaitIdle_t=int(__attribute__((ms_abi)) *)(void*);
using VkSubmitVirGLStream_t=int(__attribute__((ms_abi)) *)(const u32*,u32);
using VkPresentVirGL_t=int(__attribute__((ms_abi)) *)();
struct VkAppInfoMaze { u32 sType; const void *pNext; const char *pApplicationName; u32 applicationVersion; const char *pEngineName; u32 engineVersion; u32 apiVersion; };
struct VkInstanceInfoMaze { u32 sType; const void *pNext; u32 flags; const VkAppInfoMaze *pApplicationInfo; u32 enabledLayerCount; const char *const *ppEnabledLayerNames; u32 enabledExtensionCount; const char *const *ppEnabledExtensionNames; };
struct VkQueueInfoMaze { u32 sType; const void *pNext; u32 flags; u32 queueFamilyIndex; u32 queueCount; const float *pQueuePriorities; };
struct VkDeviceInfoMaze { u32 sType; const void *pNext; u32 flags; u32 queueCreateInfoCount; const VkQueueInfoMaze *pQueueCreateInfos; u32 enabledLayerCount; const char *const *ppEnabledLayerNames; u32 enabledExtensionCount; const char *const *ppEnabledExtensionNames; const void *pEnabledFeatures; };
struct VkQueueFamilyMaze { u32 queueFlags,queueCount,timestampValidBits; struct { i32 width,height,depth; } minImageTransferGranularity; };
struct VkRuntimeMaze { void *instance,*physical,*device,*queue; VkDestroyDevice_t destroyDevice; VkDestroyInstance_t destroyInstance; VkDeviceWaitIdle_t waitIdle; u32 ready; };
static VkRuntimeMaze vkrt{};
static VkSubmitVirGLStream_t submit_virgl_stream;
static VkPresentVirGL_t present_virgl;
static int gpu_scene_ready=0;
static int gpu_rasterizer_created=0;
static S3D_SURFACE gpu_triangle_surface{};
static int gpu_triangle_surface_ready=0;
static int gpu_triangle_error_reported=0;
static float g_triangle_angle=0.0f;
static S3D_CONTEXT g_triangle_ctx;
static uint32_t g_triangle_depth[1920u*1080u];
static int g_triangle_ctx_ready=0;

/* Match user32.c MSG exactly: HWND is a 32-bit handle in this OS ABI,
   followed by message, then naturally aligned WPARAM/LPARAM fields. */
struct Message {
    u32 hwnd;
    u32 message;
    u64 wParam;
    long long lParam;
    u32 time;
    int x, y;
};
struct SurfaceInfo { u64 va; u32 w,h,pitch; };
struct GraphicsBootInfo {
    u32 size,version,backend,capabilities,width,height,pitch;
    u32 pci_bus,pci_device,pci_function;
    unsigned short vendor_id,device_id;
    unsigned char pci_class,pci_subclass,pci_prog_if,initialized;
    u64 surface_va,virgl_buffer_va;
    u32 virgl_buffer_resource_id,virgl_buffer_size;
};
struct Rect { u32 x,y,w,h; };
struct PresentLayerArgs { u64 pixels; u32 layer,x,y,w,h,width,height; };
using PresentWindowSurface_t=BOOL(*)(const u32*,u32,u32,u32,u32,u32,u32);
static PresentWindowSurface_t present_window_surface;
static int layer_present_warned=0;
/* Dedicated tightly packed CPU staging surface for the window manager.
 * GPU output is copied here before the kernel compositor consumes it, so
 * later desktop redraws no longer treat the shared scanout as Maze's layer. */
static u32 maze_window_surface[1920u*1080u];
static const int MW=16,MH=16;
static const char maze[MH][MW+1]={
"################",
"#..............#",
"#..##.....##...#",
"#..##.....##...#",
"#......##......#",
"####...##...####",
"#..............#",
"#..####..####..#",
"#..#........#..#",
"#..#..##....#..#",
"#.....##.......#",
"###..........###",
"#..............#",
"#....####......#",
"#.............E#",
"################"
};
static u32 *pixels;
static u32 screen_w,screen_h,pitch;
/* GPU rendering still targets the shared scanout, but Maze owns a clipped
   viewport and publishes only that rectangle as its window-local surface. */
static u32 maze_view_x,maze_view_y,maze_view_w,maze_view_h;
static float player_x=2.5f, player_y=2.5f;
static float camera_yaw=-1.57079632679f;
static int won=0;
static void *window_handle;
static UpdateWindow_t update_window;
static PeekMessageA_t peek_message;
static SetCursorPos_t set_cursor_pos;
static ClipCursor_t clip_cursor;

static const int dirx[4]={0,1,0,-1};
static const int diry[4]={-1,0,1,0};
static int blocked(int x,int y) {
    return x<0||x>=MW||y<0||y>=MH||maze[y][x]=='#';
}
static u64 read_tsc() {
    u32 lo,hi;
    __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
    return ((u64)hi<<32)|lo;
}
static u64 tsc_frequency() {
    u32 a,b,c,d;
    u64 hz=0;
    __asm__ volatile("cpuid" : "=a"(a),"=b"(b),"=c"(c),"=d"(d) : "a"(0x15),"c"(0));
    if(a&&b&&c) hz=((u64)c*b)/a;
    if(!hz) {
        __asm__ volatile("cpuid" : "=a"(a),"=b"(b),"=c"(c),"=d"(d) : "a"(0x16),"c"(0));
        if(a) hz=(u64)a*1000000ULL;
    }
    /* Conservative fallback for virtual CPUs that omit TSC frequency leaves. */
    return hz?hz:1000000000ULL;
}
static u32 rgb(u32 r,u32 g,u32 b) { return 0xff000000u|(r<<16)|(g<<8)|b; }
static void put_pixel(int x,int y,u32 c) {
    if(!pixels||x<0||y<0||(u32)x>=maze_view_w||(u32)y>=maze_view_h)return;
    u32 sx=maze_view_x+(u32)x,sy=maze_view_y+(u32)y;
    if(sx<screen_w&&sy<screen_h)pixels[(u64)sy*pitch+sx]=c;
}
static void rect(int x,int y,int w,int h,u32 c) {
    if(w<=0||h<=0)return;
    for(int yy=y;yy<y+h;yy++)for(int xx=x;xx<x+w;xx++)put_pixel(xx,yy,c);
}

/* Publish Maze through its own window-local surface. The shared GPU
 * scanout remains the GPU driver's render target for now; this staging step
 * separates the app's presented image from the compositor's output buffer. */
static void present_maze_layer() {
    if(!pixels||!screen_w||!screen_h||!maze_view_w||!maze_view_h||
       maze_view_w>1920u||maze_view_h>1080u||
       maze_view_x>screen_w||maze_view_y>screen_h||
       maze_view_w>screen_w-maze_view_x||maze_view_h>screen_h-maze_view_y)return;
    if(present_window_surface) {
        for(u32 y=0;y<maze_view_h;y++)
            for(u32 x=0;x<maze_view_w;x++)
                maze_window_surface[(u64)y*maze_view_w+x]=
                    0xFF000000u|(pixels[(u64)(maze_view_y+y)*pitch+maze_view_x+x]&0x00FFFFFFu);
        if(!present_window_surface(maze_window_surface,maze_view_w,maze_view_h,
                                   0,0,maze_view_w,maze_view_h) && !layer_present_warned) {
            print("maze.exe: window-local surface presentation rejected; game may remain hidden\n");
            layer_present_warned=1;
        }
        return;
    }
    /* Backward-compatible fallback for older USER32 builds. */
    PresentLayerArgs a={(u64)(uintptr_t)maze_window_surface,2u,0u,0u,maze_view_w,maze_view_h,maze_view_w,maze_view_h};
    if(!syscall3(SYS_PRESENT_LAYER,(u64)(uintptr_t)&a,0,0) && !layer_present_warned) {
        print("maze.exe: legacy window-layer presentation rejected; game may remain hidden\n");
        layer_present_warned=1;
    }
}

static void draw_status_text(int x,int y,const char *s,u32 color,int scale) {
    for(;*s;s++,x+=8*scale) {
        unsigned char ch=(unsigned char)*s;
        if(ch>=128)continue;
        for(int row=0;row<8;row++) {
            unsigned char bits=font8x8_basic[ch][row];
            for(int col=0;col<8;col++)
                if(bits&(1u<<col))rect(x+col*scale,y+row*scale,scale,scale,color);
        }
    }
}

/* x87 trigonometry avoids a CRT/libm dependency in this freestanding PE. */
static float fsin(float angle) {
    double a=(double)angle,r;
    __asm__ volatile("fldl %1; fsin; fstpl %0":"=m"(r):"m"(a));
    return (float)r;
}
static float fcos(float angle) {
    double a=(double)angle,r;
    __asm__ volatile("fldl %1; fcos; fstpl %0":"=m"(r):"m"(a));
    return (float)r;
}
static u64 fps_window_start;
static u32 fps_window_frames;
static void print_u32(u32 value) {
    char digits[11];u32 n=0;
    do { digits[n++]=(char)('0'+value%10u); value/=10u; } while(value&&n<sizeof(digits));
    while(n) { char one[2]={digits[--n],0}; print(one); }
}
static void report_frame_rate() {
    ++fps_window_frames;
    if(fps_window_frames<300u)return;
    u64 now=syscall3(SYS_GET_TICK_COUNT,0,0,0);
    if(!fps_window_start) { fps_window_start=now; fps_window_frames=0; return; }
    u64 elapsed=now-fps_window_start;
    if(elapsed<1000u)return;
    u32 fps=(u32)(((u64)fps_window_frames*1000u)/elapsed);
    print("maze.exe: measured VirGL Maze mesh frame rate = ");print_u32(fps);print(" FPS\n");
    fps_window_start=now;fps_window_frames=0;
}
/* GPU raster path: CPU computes one ray intersection per vertical strip;
 * VirGL/Gallium performs the actual pixel fills in its 3D render target. */
static u32 float_bits(float f) { union { float f; u32 u; } v; v.f=f; return v.u; }
static int gpu_append_scissor_clear(VirglStream *s,u32 x,u32 y,u32 w,u32 h,
                                    float r,float g,float b) {
    if(!w||!h)return 1;
    /* VirGL packs two 16-bit coordinates into each scissor dword. */
    const u32 scissor[3]={0u,(x&0xffffu)|((y&0xffffu)<<16),
                           ((x+w)&0xffffu)|(((y+h)&0xffffu)<<16)};
    const u32 clear[7]={4u,float_bits(r),float_bits(g),float_bits(b),
                        float_bits(1.0f),float_bits(1.0f),0u};
    return virgl_stream_command(s,VIRGL_CCMD_SET_SCISSOR_STATE,VIRGL_OBJECT_NULL,scissor,3) &&
           virgl_stream_command(s,VIRGL_CCMD_CLEAR,VIRGL_OBJECT_NULL,clear,7);
}
/* Batch 8: reject malformed or incomplete GPU frame streams before
 * crossing the kernel boundary. This validates transport packets, not shader
 * execution or proof that the GPU produced the expected pixels. */
static int gpu_frame_stream_ready(const VirglStream *stream) {
    if(!stream || stream->failed || !stream->words || !stream->used_dwords)
        return 0;
    if(!virgl_stream_validate(stream->words,stream->used_dwords))
        return 0;
    u32 commands=virgl_stream_count_commands(stream->words,stream->used_dwords);
    if(commands==UINT32_MAX || commands<5u)
        return 0;
    u32 bind=virgl_stream_find_command(stream->words,stream->used_dwords,
                                       VIRGL_CCMD_BIND_OBJECT);
    u32 framebuffer=virgl_stream_find_command(stream->words,stream->used_dwords,
                                              VIRGL_CCMD_SET_FRAMEBUFFER_STATE);
    u32 clear=virgl_stream_find_command(stream->words,stream->used_dwords,
                                        VIRGL_CCMD_CLEAR);
    if(bind==UINT32_MAX || framebuffer==UINT32_MAX || clear==UINT32_MAX)
        return 0;
    /* A clear command needs seven payload dwords; the framebuffer packet
       needs at least its count/depth header. Reject truncated/wrong packets. */
    if((stream->words[clear]>>16)!=7u ||
       (stream->words[framebuffer]>>16)<2u)
        return 0;
    return 1;
}

static i32 gpu_fixed16(float v) {
    double q=(double)v*65536.0;
    if(q>2147483000.0)q=2147483000.0;
    if(q< -2147483000.0)q= -2147483000.0;
    return (i32)q;
}

/* Batch 1 Maze engine: CPU builds and transforms world geometry; VirGL
 * executes one batched triangle-list draw for the complete scene. */
struct MazeWorldPoint { float x,y,z; };
struct MazeGpuFace { float depth; S3D_VERTEX v[6]; };
static S3D_VERTEX maze_gpu_vertices[16384];
static MazeGpuFace maze_gpu_wall_faces[1024];
static u32 maze_gpu_vertex_count;
static u32 maze_gpu_wall_face_count;
static float maze_cam_fx,maze_cam_fz,maze_cam_rx,maze_cam_rz;

static u32 maze_shade(u32 base,float depth) {
    float scale=1.0f-depth*0.035f;
    if(scale<0.42f)scale=0.42f;
    if(scale>1.0f)scale=1.0f;
    u32 r=(base>>16)&255u,g=(base>>8)&255u,b=base&255u;
    r=(u32)((float)r*scale);g=(u32)((float)g*scale);b=(u32)((float)b*scale);
    return rgb(r,g,b);
}
static int maze_project_world(float wx,float wy,float wz,u32 color,
                              S3D_VERTEX *out,float *depth_out) {
    if(!out)return 0;
    const float dx=wx-player_x,dz=wz-player_y;
    const float depth=dx*maze_cam_fx+dz*maze_cam_fz;
    if(depth<0.12f||depth>24.0f)return 0;
    const float camera_x=dx*maze_cam_rx+dz*maze_cam_rz;
    const float focal=1.05f;
    const float nx=(camera_x*focal)/depth;
    const float ny=((wy-0.78f)*focal)/depth;
    /* Convert viewport-local normalized device coordinates into the full
       scanout's NDC so the GPU writes only into Maze's window rectangle. */
    const float screen_nx=(2.0f*((float)maze_view_x+
        ((nx+1.0f)*0.5f*(float)maze_view_w))/(float)screen_w)-1.0f;
    const float screen_ny=(2.0f*((float)maze_view_y+
        ((1.0f-ny)*0.5f*(float)maze_view_h))/(float)screen_h)-1.0f;
    out->x=gpu_fixed16(screen_nx);
    out->y=gpu_fixed16(screen_ny);
    out->z=gpu_fixed16(0.5f);
    out->color=color;
    if(depth_out)*depth_out=depth;
    return 1;
}
static int maze_append_projected_quad(const MazeWorldPoint p[4],u32 color) {
    if(maze_gpu_vertex_count+6u>16384u)return 0;
    S3D_VERTEX v[4];
    for(u32 i=0;i<4;i++)
        if(!maze_project_world(p[i].x,p[i].y,p[i].z,color,&v[i],0))return 0;
    S3D_VERTEX *out=&maze_gpu_vertices[maze_gpu_vertex_count];
    out[0]=v[0];out[1]=v[1];out[2]=v[2];
    out[3]=v[0];out[4]=v[2];out[5]=v[3];
    maze_gpu_vertex_count+=6u;
    return 1;
}
static int maze_append_wall_face(const MazeWorldPoint p[4],u32 base_color) {
    if(maze_gpu_wall_face_count>=1024u)return 0;
    S3D_VERTEX v[4];float depth_sum=0.0f;
    for(u32 i=0;i<4;i++) {
        float d=0.0f;
        if(!maze_project_world(p[i].x,p[i].y,p[i].z,base_color,&v[i],&d))return 0;
        depth_sum+=d;
    }
    MazeGpuFace *face=&maze_gpu_wall_faces[maze_gpu_wall_face_count++];
    face->depth=depth_sum*0.25f;
    const u32 color=maze_shade(base_color,face->depth);
    for(u32 i=0;i<4;i++)v[i].color=color;
    face->v[0]=v[0];face->v[1]=v[1];face->v[2]=v[2];
    face->v[3]=v[0];face->v[4]=v[2];face->v[5]=v[3];
    return 1;
}
static void maze_build_background_geometry() {
    maze_gpu_vertex_count=0;
    maze_gpu_wall_face_count=0;
    for(int z=0;z<MH;z++)for(int x=0;x<MW;x++) {
        if(maze[z][x]=='#')continue;
        const u32 floor_color=maze[z][x]=='E'
            ?rgb(34,142,94)
            :(((x+z)&1)?rgb(64,68,72):rgb(56,60,65));
        MazeWorldPoint floor[4]={
            {(float)x,0.0f,(float)z},{(float)x+1.0f,0.0f,(float)z},
            {(float)x+1.0f,0.0f,(float)z+1.0f},{(float)x,0.0f,(float)z+1.0f}
        };
        MazeWorldPoint ceiling[4]={
            {(float)x,2.0f,(float)z},{(float)x+1.0f,2.0f,(float)z},
            {(float)x+1.0f,2.0f,(float)z+1.0f},{(float)x,2.0f,(float)z+1.0f}
        };
        (void)maze_append_projected_quad(floor,floor_color);
        (void)maze_append_projected_quad(ceiling,rgb(24,31,43));
    }
    /* Only add the side of each wall facing the player. Faces are sorted
       back-to-front below because the current target has no depth attachment. */
    for(int z=0;z<MH;z++)for(int x=0;x<MW;x++) {
        if(maze[z][x]!='#')continue;
        const float x0=(float)x,x1=x0+1.0f,z0=(float)z,z1=z0+1.0f;
        const u32 stone=rgb(154,160,169);
        if(player_x<x0) {
            MazeWorldPoint p[4]={{x0,0,z0},{x0,0,z1},{x0,2,z1},{x0,2,z0}};
            (void)maze_append_wall_face(p,stone);
        } else if(player_x>x1) {
            MazeWorldPoint p[4]={{x1,0,z1},{x1,0,z0},{x1,2,z0},{x1,2,z1}};
            (void)maze_append_wall_face(p,rgb(134,144,157));
        }
        if(player_y<z0) {
            MazeWorldPoint p[4]={{x1,0,z0},{x0,0,z0},{x0,2,z0},{x1,2,z0}};
            (void)maze_append_wall_face(p,rgb(170,176,184));
        } else if(player_y>z1) {
            MazeWorldPoint p[4]={{x0,0,z1},{x1,0,z1},{x1,2,z1},{x0,2,z1}};
            (void)maze_append_wall_face(p,rgb(119,130,145));
        }
    }
}
static int maze_append_sorted_wall_faces() {
    u32 counts[64],offsets[65],cursor[64];
    u32 order[1024];
    /* Freestanding PE has no CRT memset; volatile stores keep the compiler
       from lowering aggregate zero-initialization back into a memset call. */
    volatile u32 *vc=counts,*vo=offsets,*vr=cursor;
    for(u32 i=0;i<64u;i++){vc[i]=0u;vo[i]=0u;vr[i]=0u;}
    vo[64]=0u;
    for(u32 i=0;i<maze_gpu_wall_face_count;i++) {
        int bucket=(int)(maze_gpu_wall_faces[i].depth*4.0f);
        if(bucket<0)bucket=0;if(bucket>63)bucket=63;
        counts[bucket]++;
    }
    for(u32 b=0;b<64;b++)offsets[b+1]=offsets[b]+counts[b];
    for(u32 b=0;b<64;b++)cursor[b]=offsets[b];
    for(u32 i=0;i<maze_gpu_wall_face_count;i++) {
        int bucket=(int)(maze_gpu_wall_faces[i].depth*4.0f);
        if(bucket<0)bucket=0;if(bucket>63)bucket=63;
        order[cursor[bucket]++]=i;
    }
    for(int b=63;b>=0;b--)for(u32 j=offsets[b];j<offsets[b+1];j++) {
        if(maze_gpu_vertex_count+6u>16384u)return 0;
        const MazeGpuFace *face=&maze_gpu_wall_faces[order[j]];
        for(u32 k=0;k<6;k++)maze_gpu_vertices[maze_gpu_vertex_count++]=face->v[k];
    }
    return 1;
}
static void draw_frame_gpu() {
    if(!gpu_triangle_surface_ready) {
        if(!S3DGetSurface(&gpu_triangle_surface) ||
           gpu_triangle_surface.backend!=2 ||
           gpu_triangle_surface.virgl_buffer_resource_id!=S3D_VIRGL_VERTEX_BUFFER_ID ||
           !gpu_triangle_surface.virgl_buffer ||
           gpu_triangle_surface.virgl_buffer_size<84u) {
            if(!gpu_triangle_error_reported) {
                print("maze.exe: FATAL: VirGL mesh target/vertex buffer unavailable\n");
                gpu_triangle_error_reported=1;
            }
            return;
        }
        gpu_triangle_surface_ready=1;
        print("maze.exe: VirGL mesh renderer ready; batching Maze geometry into GPU triangle lists\n");
    }
    /* Cache yaw basis once per frame; per-vertex x87 trig is far too costly. */
    maze_cam_fx=fcos(camera_yaw);maze_cam_fz=fsin(camera_yaw);
    maze_cam_rx=-maze_cam_fz;maze_cam_rz=maze_cam_fx;
    maze_build_background_geometry();
    if(!maze_append_sorted_wall_faces()) {
        if(!gpu_triangle_error_reported) {
            print("maze.exe: FATAL: Maze scene exceeded geometry buffer capacity\n");
            gpu_triangle_error_reported=1;
        }
        return;
    }
    if(maze_gpu_vertex_count<3u ||
       !S3DDrawMeshVirGL(&gpu_triangle_surface,maze_gpu_vertices,maze_gpu_vertex_count)) {
        if(!gpu_triangle_error_reported) {
            print("maze.exe: FATAL: VirGL Maze mesh submission/presentation failed\n");
            gpu_triangle_error_reported=1;
        }
        return;
    }
    present_maze_layer();
    report_frame_rate();
}

/* CPU software rasterizer fallback: render a single colored triangle
 * rotating around the viewport center using the soft3d fixed-point 3D
 * renderer. Demonstrates the graphics pipeline without VirGL. */
static void draw_spinning_triangle(void) {
    if (!pixels || !screen_w || !screen_h || screen_w > 1920u || screen_h > 1080u)
        return;

    if (!g_triangle_ctx_ready) {
        int32_t focal = (int32_t)(300.0f * 65536.0f);
        if (!S3DInitialize(&g_triangle_ctx, pixels, g_triangle_depth,
                           (uint32_t)screen_w, (uint32_t)screen_h, pitch, focal))
            return;
        g_triangle_ctx_ready = 1;
        print("maze.exe: VirGL unavailable; soft3d CPU spinning triangle demo\n");
    }

    S3DClear(&g_triangle_ctx, 0xFF101018u, S3D_DEPTH_FAR);

    float r = g_triangle_angle * 0.0174532925f; /* degrees to radians */
    float radius = (float)(screen_w < screen_h ? screen_w : screen_h) * 0.35f;
    float world_z = 3.0f;

    S3D_VERTEX v[3];
    for (int i = 0; i < 3; i++) {
        float a = r + (float)i * 2.09439510239f; /* 120 degrees apart */
        float world_x = radius * fcos(a);
        float world_y = radius * fsin(a);
        v[i].x = (int32_t)(world_x * 65536.0f);
        v[i].y = (int32_t)(world_y * 65536.0f);
        v[i].z = (int32_t)(world_z * 65536.0f);
        switch (i) {
            case 0: v[i].color = 0xFFFF0000u; break; /* red */
            case 1: v[i].color = 0xFF00FF00u; break; /* green */
            case 2: v[i].color = 0xFF0000FFu; break; /* blue */
        }
    }

    S3DDrawTriangle(&g_triangle_ctx, &v[0], &v[1], &v[2]);
    S3DPresent(&g_triangle_ctx);

    g_triangle_angle += 2.0f;
    if (g_triangle_angle >= 360.0f) g_triangle_angle -= 360.0f;
}

static void draw_frame() {
    if(gpu_scene_ready){draw_frame_gpu();return;}
    if(!pixels||!screen_w||!screen_h)return;
    draw_spinning_triangle();
    return;
    const int w=(int)screen_w,h=(int)screen_h;
    const int status_h=h>=240?18:0;
    const int view_h=h-status_h;
    const float dirx=fcos(camera_yaw), diry=fsin(camera_yaw);
    const float plane_x=-diry*0.66f, plane_y=dirx*0.66f;
    const int horizon=view_h/2;
    /* Per-column DDA ray casting gives continuous perspective as the camera turns. */
    for(int x=0;x<w;x++) {
        float camera_x=2.0f*(float)x/(float)w-1.0f;
        float ray_x=dirx+plane_x*camera_x;
        float ray_y=diry+plane_y*camera_x;
        int map_x=(int)player_x,map_y=(int)player_y;
        float delta_x=ray_x==0.0f?1.0e30f:(ray_x<0?-ray_x:ray_x);
        float delta_y=ray_y==0.0f?1.0e30f:(ray_y<0?-ray_y:ray_y);
        delta_x=1.0f/delta_x; delta_y=1.0f/delta_y;
        int step_x,step_y,hit=0,side=0;
        float side_x,side_y;
        if(ray_x<0) { step_x=-1; side_x=(player_x-(float)map_x)*delta_x; }
        else { step_x=1; side_x=((float)map_x+1.0f-player_x)*delta_x; }
        if(ray_y<0) { step_y=-1; side_y=(player_y-(float)map_y)*delta_y; }
        else { step_y=1; side_y=((float)map_y+1.0f-player_y)*delta_y; }
        for(int n=0;n<64&&!hit;n++) {
            if(side_x<side_y) { side_x+=delta_x; map_x+=step_x; side=0; }
            else { side_y+=delta_y; map_y+=step_y; side=1; }
            if(blocked(map_x,map_y)) hit=1;
        }
        float dist=side==0?(side_x-delta_x):(side_y-delta_y);
        if(dist<0.05f)dist=0.05f;
        int line_h=(int)((float)view_h/dist);
        int top=horizon-line_h/2, bottom=horizon+line_h/2;
        if(top<0)top=0;if(bottom>=view_h)bottom=view_h-1;
        /* Ceiling and floor gradients are independent of wall distance. */
        for(int y=0;y<view_h;y++) {
            u32 color;
            if(y<horizon) {
                int shade=27+(horizon-y)*24/(horizon?horizon:1);
                color=rgb(shade,shade+7,shade+17);
            } else {
                int depth=y-horizon;
                int shade=47-depth*22/(horizon?horizon:1);
                if(shade<17)shade=17;
                color=rgb(shade+5,shade,shade-5);
            }
            pixels[(u64)y*pitch+(u32)x]=color;
        }
        if(hit) {
            float wall_x=side==0?player_y+dist*ray_y:player_x+dist*ray_x;
            wall_x-= (float)(int)wall_x;
            int stripe=(int)(wall_x*8.0f);
            int base=side?106:139;
            if(stripe==0||stripe==7)base-=18;
            int shade=base-(int)(dist*9.0f);
            if(shade<28)shade=28;if(shade>180)shade=180;
            u32 wall=side?rgb(shade-17,shade-8,shade-2):rgb(shade,shade-13,shade-25);
            for(int y=top;y<=bottom;y++) {
                int edge=(y-top<2||bottom-y<2);
                pixels[(u64)y*pitch+(u32)x]=edge?rgb(42,43,45):wall;
            }
        }
    }
    /* Reticle and compact HUD are overlaid after the 3D view. */
    rect(w/2-5,horizon,11,1,rgb(235,235,220));
    rect(w/2,horizon-5,1,11,rgb(235,235,220));
    if(status_h) {
        rect(0,view_h,w,status_h,rgb(12,18,26));
        int dir=(int)((camera_yaw+6.28318530718f)*4.0f/6.28318530718f)&3;
        for(int i=0;i<4;i++)rect(10+i*10,view_h+6,6,6,i==dir?rgb(80,220,170):rgb(75,85,95));
    }
    if(won)rect(w/2-80,h/2-18,160,36,rgb(35,150,90));
    Rect dirty={0,0,screen_w,screen_h};
    (void)syscall3(SYS_FLUSH_GRAPHICS,(u64)&dirty,0,0);
    present_maze_layer();
    report_frame_rate();
}
static void move_player(float dx,float dy) {
    if(won)return;
    /* Axis-separated collision allows sliding along walls instead of sticking. */
    float nx=player_x+dx;
    if(!blocked((int)(nx+(dx>0?0.18f:-0.18f)),(int)player_y))player_x=nx;
    float ny=player_y+dy;
    if(!blocked((int)player_x,(int)(ny+(dy>0?0.18f:-0.18f))))player_y=ny;
    int gx=(int)player_x,gy=(int)player_y;
    if(gx>=0&&gx<MW&&gy>=0&&gy<MH&&maze[gy][gx]=='E')won=1;
}
extern "C" void maze_mainCRTStartup() {
    /* Bring up a real Vulkan instance, enumerate the software physical device,
       and create a graphics queue. Scene drawing is switched only after a
       pipeline and render target have been created successfully. */
    auto vkCreateInstance=(VkCreateInstance_t)get_proc("vulkan.dll","vkCreateInstance");
    auto vkEnumerateVersion=(VkEnumerateInstanceVersion_t)get_proc("vulkan.dll","vkEnumerateInstanceVersion");
    auto vkGetInstanceProcAddr=(VkGetInstanceProcAddr_t)get_proc("vulkan.dll","vkGetInstanceProcAddr");
    u32 vkVersion=0;
    int vulkan_available=0;
    const char *vk_failure="loader entry points missing";
    if(vkCreateInstance&&vkGetInstanceProcAddr) {
        VkAppInfoMaze app={0,0,"SentinelOS Maze",1,"SentinelOS",1,(1u<<22)};
        VkInstanceInfoMaze ici={1,0,0,&app,0,0,0,0};
        void *instance=0;
        int create_result=vkCreateInstance(&ici,0,&instance);
        if(create_result==0&&instance) {
            vk_failure="instance dispatch functions missing";
            auto vkEnumPhys=(VkEnumeratePhysicalDevices_t)vkGetInstanceProcAddr(instance,"vkEnumeratePhysicalDevices");
            auto vkQueueProps=(VkGetPhysicalDeviceQueueFamilyProperties_t)vkGetInstanceProcAddr(instance,"vkGetPhysicalDeviceQueueFamilyProperties");
            auto vkCreateDev=(VkCreateDevice_t)vkGetInstanceProcAddr(instance,"vkCreateDevice");
            auto vkGetQueue=(VkGetDeviceQueue_t)vkGetInstanceProcAddr(instance,"vkGetDeviceQueue");
            vkrt.destroyInstance=(VkDestroyInstance_t)vkGetInstanceProcAddr(instance,"vkDestroyInstance");
            if(vkEnumPhys&&vkQueueProps&&vkCreateDev&&vkGetQueue&&vkrt.destroyInstance) {
                vk_failure="physical-device enumeration failed";
                u32 count=0;
                int enum_result=vkEnumPhys(instance,&count,0);
                if(enum_result==0&&count>0&&count<=8) {
                    void *physical[8]={0}; u32 available=count;
                    vk_failure="physical-device handles unavailable";
                    enum_result=vkEnumPhys(instance,&available,physical);
                    if(enum_result==0&&available>0&&physical[0]) {
                        u32 qcount=0;
                        vk_failure="no graphics queue family";
                        vkQueueProps(physical[0],&qcount,0);
                        VkQueueFamilyMaze qprops[8]={{0}};
                        if(qcount>0&&qcount<=8) {
                            u32 qcap=qcount; vkQueueProps(physical[0],&qcap,qprops);
                            u32 qfamily=0; int found=0;
                            for(u32 qi=0;qi<qcap;qi++) if((qprops[qi].queueFlags&1u)&&qprops[qi].queueCount) {qfamily=qi;found=1;break;}
                            if(found) {
                                float priority=1.0f;
                                VkQueueInfoMaze qci={2,0,0,qfamily,1,&priority};
                                VkDeviceInfoMaze dci={3,0,0,1,&qci,0,0,0,0,0};
                                void *device=0;
                                vk_failure="vkCreateDevice failed";
                                int device_result=vkCreateDev(physical[0],&dci,0,&device);
                                if(device_result==0&&device) {
                                    vkrt.instance=instance;vkrt.physical=physical[0];vkrt.device=device;
                                    vkrt.destroyDevice=(VkDestroyDevice_t)vkGetInstanceProcAddr(instance,"vkDestroyDevice");
                                    vkrt.waitIdle=(VkDeviceWaitIdle_t)vkGetInstanceProcAddr(instance,"vkDeviceWaitIdle");
                                    vk_failure="device queue or required device functions missing";
                                    vkGetQueue(device,qfamily,0,&vkrt.queue);
                                    if(vkrt.queue&&vkrt.destroyDevice&&vkrt.waitIdle) {vkrt.ready=1;vulkan_available=1;}
                                    else { if(vkrt.destroyDevice)vkrt.destroyDevice(device,0);vkrt.device=0; }
                                }
                            }
                        } else vk_failure="invalid graphics queue family count";
                    } else vk_failure="physical-device enumeration failed";
                } else vk_failure="no Vulkan physical device";
            }
            if(!vkrt.ready) {
                if(vkrt.destroyInstance)vkrt.destroyInstance(instance,0);
                vkrt.instance=0;
            }
        } else {
            vk_failure="vkCreateInstance failed";
        }
    }
    if(vkEnumerateVersion && vkEnumerateVersion(&vkVersion)!=0) vkVersion=0;

    auto create_window=(CreateWindowExA_t)get_proc("user32.dll","CreateWindowExA");
    present_window_surface=(PresentWindowSurface_t)get_proc("user32.dll","PresentWindowSurface");
    auto show_window=(ShowWindow_t)get_proc("user32.dll","ShowWindow");
    auto show_cursor=(ShowCursor_t)get_proc("user32.dll","ShowCursor");
    set_cursor_pos=(SetCursorPos_t)get_proc("user32.dll","SetCursorPos");
    clip_cursor=(ClipCursor_t)get_proc("user32.dll","ClipCursor");
    update_window=(UpdateWindow_t)get_proc("user32.dll","UpdateWindow");
    auto get_message=(GetMessageA_t)get_proc("user32.dll","GetMessageA");
    peek_message=(PeekMessageA_t)get_proc("user32.dll","PeekMessageA");
    auto translate=(TranslateMessage_t)get_proc("user32.dll","TranslateMessage");
    auto dispatch=(DispatchMessageA_t)get_proc("user32.dll","DispatchMessageA");
    if(!create_window||!show_window||!get_message||!dispatch||!peek_message) {
        print("maze.exe: required USER32 functions missing\n");
        (void)syscall3(SYS_TERMINATE_PROCESS,1,0,0); for(;;)__asm__ volatile("pause");
    }
    /* Query the active display before creating the HWND so fullscreen
       geometry matches the real framebuffer instead of assuming 1280x800. */
    GraphicsBootInfo info{}; info.size=sizeof(info); info.version=1;
    u64 graphics_info_ok=syscall3(SYS_GRAPHICS_INFO,(u64)&info,0,0);
    if(graphics_info_ok&&info.surface_va&&info.width&&info.height&&info.pitch>=info.width*4) {
        pixels=(u32*)(uintptr_t)info.surface_va;
        screen_w=info.width; screen_h=info.height; pitch=info.pitch/4;
    }
    submit_virgl_stream=(VkSubmitVirGLStream_t)get_proc("vulkan.dll","SentinelVulkanSubmitVirGLStream");
    present_virgl=(VkPresentVirGL_t)get_proc("vulkan.dll","SentinelVulkanPresentVirGL");
    /* GPU-only mode: never silently substitute CPU rasterization. The
       VirGL span renderer submits GPU scissor/clear work and presents the
       GPU target; if the transport is unavailable, report that explicitly. */
    const int virgl_capable=(graphics_info_ok && (info.capabilities&(1u<<4))!=0);
    const int virgl_buffer_ok=(virgl_capable && info.virgl_buffer_va &&
                               info.virgl_buffer_resource_id==S3D_VIRGL_VERTEX_BUFFER_ID &&
                               info.virgl_buffer_size>=84u);
    int virgl_gpu_candidate=virgl_buffer_ok;
    gpu_scene_ready=virgl_gpu_candidate;
    if(gpu_scene_ready) {
        print("maze.exe: GPU-only mode; VirGL batched Maze mesh selected\n");
    } else {
        if(!graphics_info_ok) {
            print("maze.exe: GPU diagnostics: SYS_GRAPHICS_INFO failed; no GPU surface metadata\n");
        } else {
            print("maze.exe: GPU diagnostics: graphics info received; capabilities=");
            print_hex((u64)info.capabilities);
            print(" buffer_va=");print_hex(info.virgl_buffer_va);
            print(" buffer_id=");print_hex((u64)info.virgl_buffer_resource_id);
            print(" buffer_bytes=");print_hex((u64)info.virgl_buffer_size);
            print("\n");
            if(!virgl_capable)
                print("maze.exe: reason: kernel did not initialize a VirGL 3D target (2D/VNC mode or host VirGL unavailable)\n");
            else if(!virgl_buffer_ok)
                print("maze.exe: reason: VirGL is advertised but the shared vertex buffer mapping/size is invalid\n");
        }
    }
    /* Only probe transport after the kernel has positively advertised an
       initialized VirGL context, target, and shared buffer. Do not report a
       skipped probe as a command-submission failure in 2D-only mode. */
    int virgl_submit_ok=0;
    if(virgl_buffer_ok) {
        u32 command_words[1]={0};
        VirglStream stream{};
        virgl_stream_init(&stream,command_words,1);
        if(virgl_stream_command(&stream,VIRGL_CCMD_NOP,VIRGL_OBJECT_NULL,nullptr,0) &&
           virgl_stream_bytes(&stream)==sizeof(u32)) {
            virgl_submit_ok=(syscall3(SYS_SUBMIT_3D,(u64)command_words,sizeof(u32),0)!=0);
        }
        if(!virgl_submit_ok)
            print("maze.exe: reason: VirGL was initialized but its NOP command was rejected\n");
    }
    /* Open as a normal resizable desktop window, not a fullscreen popup.
       Keep the client area comfortably sized and centered within the display. */
    int display_w=screen_w?(int)screen_w:1280;
    int display_h=screen_h?(int)screen_h:800;
    int window_w=display_w<1000?display_w-48:960;
    int window_h=display_h<680?display_h-96:600;
    if(window_w<320)window_w=320;
    if(window_h<240)window_h=240;
    /* Keep the window rectangle inside small displays. Without this clamp,
       the minimum size above can produce negative centered coordinates, which
       become huge unsigned viewport offsets and make the GPU layer vanish. */
    if(window_w>display_w)window_w=display_w;
    if(window_h>display_h)window_h=display_h;
    int window_x=(display_w-window_w)/2;
    int window_y=(display_h-window_h)/2;
    maze_view_x=(u32)window_x;maze_view_y=(u32)window_y;
    maze_view_w=(u32)window_w;maze_view_h=(u32)window_h;
    /* WS_OVERLAPPEDWINDOW: title bar, system menu, minimize/maximize,
       sizing border. Rendering remains clipped to this HWND's client area. */
    window_handle=create_window(0,"STATIC","SentinelOS - 3D Maze",0x00CF0000u,
                                window_x,window_y,window_w,window_h,0,0,0,0);
    if(!window_handle) {
        print("maze.exe: window creation failed\n");
        (void)syscall3(SYS_TERMINATE_PROCESS,1,0,0); for(;;)__asm__ volatile("pause");
    }
    (void)show_window(window_handle,1);
    /* SentinelOS does not yet provide reliable per-window mouse capture
       and focus-loss notifications. Keep the desktop pointer usable rather
       than hiding/clipping it globally when this fullscreen window is shown.
       Mouse-look still consumes relative PS/2 deltas; do not warp the global
       pointer to the screen center every frame. */
    if(update_window)(void)update_window(window_handle);

    if(!pixels) {
        print("maze.exe: FATAL: no direct graphics surface; GPU-only rendering unavailable\n");
    } else {
        draw_frame();
    }
    if(vulkan_available) print(gpu_scene_ready ? "maze.exe: Vulkan device ready; Maze scene is rasterized by VirGL vertex/fragment shaders\n" : "maze.exe: Vulkan device ready, but GPU-only Maze mesh renderer unavailable; no CPU fallback\n");
    else { print("maze.exe: Vulkan runtime probe failed at "); print(vk_failure); print("; independent VirGL triangle path may still run\n"); }
    Message msg{};
    u64 hz=tsc_frequency();
    /* Keep a phase-locked 60 Hz deadline instead of resetting the clock
       to the late wakeup time every frame. This prevents scheduler jitter from
       accumulating into a progressively slower frame cadence. */
    u64 frame_cycles=hz/60ULL;
    if(!frame_cycles)frame_cycles=1;
    u64 last_frame=read_tsc();
    u64 next_frame=last_frame+frame_cycles;
    for(;;) {
        /* Poll messages without blocking the simulation thread. */
        while(peek_message(&msg,nullptr,0,0,1)) {
            if(msg.message==0x0010||msg.message==0x0012) goto game_exit;
            if(msg.message==0x0100 && (u32)msg.wParam==0x1b) goto game_exit;
            if(translate)(void)translate(&msg);
            (void)dispatch(&msg);
        }

        /* A make/break-aware kernel state keeps movement continuous while
         * a physical key is held, without depending on keyboard typematic. */
        u64 now=read_tsc();
        if(now>=next_frame) {
            u64 elapsed=now-last_frame;
            last_frame=now;
            /* Advance from the previous deadline, not from 'now'. If we fell
               far behind, drop missed presentation slots instead of spinning
               through a burst of stale frames. */
            next_frame+=frame_cycles;
            if(now>=next_frame && now-next_frame>=frame_cycles*3ULL)
                next_frame=now+frame_cycles;
            float dt=(float)elapsed/(float)hz;
            if(dt<0.0f)dt=0.0f;
            if(dt>0.05f)dt=0.05f;
            u64 keys=syscall3(SYS_GAME_KEY_STATE,0,0,0);
            u32 mouse=(u32)syscall3(SYS_GAME_MOUSE_DELTA,0,0,0);
            int mdx=(int)(short)(mouse&0xffffu);
            /* Continuous yaw: no 90-degree snapping or mouse threshold. */
            camera_yaw+=(float)mdx*0.035f;
            const float tau=6.28318530718f;
            while(camera_yaw<0.0f)camera_yaw+=tau;
            while(camera_yaw>=tau)camera_yaw-=tau;
            /* Do not SetCursorPos here: the current USER32 implementation
               has no reliable capture/focus lifecycle, and warping the shared
               pointer makes Explorer appear frozen while Maze is running. */
            if(keys&(1u<<4)) goto game_exit;
            float forward=0.0f,strafe=0.0f;
            if(keys&(1u<<0))forward+=1.0f;
            if(keys&(1u<<2))forward-=1.0f;
            if(keys&(1u<<1))strafe-=1.0f;
            if(keys&(1u<<3))strafe+=1.0f;
            if(forward!=0.0f||strafe!=0.0f) {
                float len=1.0f;
                if(forward!=0.0f&&strafe!=0.0f)len=0.70710678f;
                const float speed=2.8f*dt*len;
                float dx=(fcos(camera_yaw)*forward-fsin(camera_yaw)*strafe)*speed;
                float dy=(fsin(camera_yaw)*forward+fcos(camera_yaw)*strafe)*speed;
                move_player(dx,dy);
            }
            /* Redraw at the frame cadence even when standing still, so mouse
               look and animation never depend on a keypress edge. */
            draw_frame();
        }
        (void)syscall3(SYS_YIELD,0,0,0);
    }
game_exit:
    if(vkrt.ready) {
        if(vkrt.waitIdle) (void)vkrt.waitIdle(vkrt.device);
        if(vkrt.destroyDevice) vkrt.destroyDevice(vkrt.device,0);
        if(vkrt.destroyInstance) vkrt.destroyInstance(vkrt.instance,0);
        vkrt.ready=0;
    }
    (void)syscall3(SYS_TERMINATE_PROCESS,0,0,0);
    for(;;)__asm__ volatile("pause");
}
