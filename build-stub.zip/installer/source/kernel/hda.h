#pragma once
#include <stdint.h>
#include "serial.h"
#include "vmm.h"
#include "virtio_blk.h"

/*
 * SentinelOS Intel HD Audio — milestone 1.
 * Detects PCI class 04h / subclass 03h.
 * No controller registers are touched yet.
 */


static int hda_detected;
static uint8_t hda_bus, hda_slot, hda_func;
static uint64_t hda_bar0;
static volatile uint8_t *hda_regs;

#define HDA_REG_GCAP       0x00
#define HDA_REG_GCTL       0x08
#define HDA_REG_STATESTS   0x0E
#define HDA_REG_GCAP_EXT   0x00
#define HDA_REG_GCTL_CRST  0x01

static uint32_t hda_read32(uint32_t off) {
    return *(volatile uint32_t *)(hda_regs + off);
}

static void hda_write32(uint32_t off, uint32_t value) {
    *(volatile uint32_t *)(hda_regs + off) = value;
}

static uint8_t hda_read8(uint32_t off) {
    return *(volatile uint8_t *)(hda_regs + off);
}

static void hda_write8(uint32_t off, uint8_t value) {
    *(volatile uint8_t *)(hda_regs + off) = value;
}

static uint16_t hda_read16(uint32_t off) {
    return *(volatile uint16_t *)(hda_regs + off);
}

static int hda_wait_bit(uint32_t off, uint32_t mask, int set) {
    for (uint32_t i = 0; i < 1000000; i++) {
        int value = !!(hda_read32(off) & mask);
        if (value == set)
            return 0;
        __asm__ volatile("pause");
    }
    return -1;
}


/* HDA CORB/RIRB registers */
#define HDA_CORB_LO       0x40
#define HDA_CORB_HI       0x44
#define HDA_CORBWP        0x48
#define HDA_CORBRP        0x4A
#define HDA_CORBCTL       0x4C
#define HDA_CORBSIZE      0x4E
#define HDA_RIRB_LO       0x50
#define HDA_RIRB_HI       0x54
#define HDA_RIRBWP        0x58
#define HDA_RINTCNT       0x5A
#define HDA_RIRBCTL       0x5C
#define HDA_RIRBSIZE      0x5E

#define HDA_RING_COUNT    256
#define HDA_RING_BYTES    4096

static uint64_t hda_corb_pa;
static uint64_t hda_rirb_pa;
static uint16_t hda_corb_wp;
static uint16_t hda_rirb_last;

static void hda_write16(uint32_t off, uint16_t value) {
    *(volatile uint16_t *)(hda_regs + off) = value;
}

static int hda_wait16(uint32_t off, uint16_t mask, uint16_t expected) {
    for (uint32_t i = 0; i < 1000000; i++) {
        if ((hda_read16(off) & mask) == expected)
            return 0;
        __asm__ volatile("pause");
    }
    return -1;
}


static int hda_codec_verb(uint8_t cad, uint8_t nid,
                          uint16_t verb, uint8_t payload,
                          uint32_t *result) {
    uint16_t csz = hda_read8(HDA_CORBSIZE) & 3;
    uint16_t rsz = hda_read8(HDA_RIRBSIZE) & 3;
    uint16_t ccount = csz == 2 ? 256 : (csz == 1 ? 16 : 2);
    uint16_t rcount = rsz == 2 ? 256 : (rsz == 1 ? 16 : 2);

    uint16_t next = (uint16_t)((hda_corb_wp + 1) % ccount);
    static int ring_debug_count = 0;
    if (ring_debug_count < 3) {
        DbgPrint("hda: ring debug CORBSIZE=%02x RIRBSIZE=%02x "
                 "ccount=%u rcount=%u sw_wp=%u hw_rp=%u "
                 "CORB_LO=%08x HI=%08x\n",
                 hda_read8(HDA_CORBSIZE), hda_read8(HDA_RIRBSIZE),
                 ccount, rcount, hda_corb_wp, hda_read16(HDA_CORBRP),
                 hda_read32(HDA_CORB_LO), hda_read32(HDA_CORB_HI));
        ring_debug_count++;
    }
    uint32_t command =
        ((uint32_t)(cad & 0x0F) << 28) |
        ((uint32_t)nid << 20) |
        ((uint32_t)(verb & 0x0FFF) << 8) |
        payload;

    ((volatile uint32_t *)(HHDM_BASE + hda_corb_pa))[next] = command;
    __asm__ volatile("mfence" ::: "memory");

    DbgPrint("hda: enqueue slot=%u command=%08x slot_readback=%08x "
             "ring_pa=%p\n",
             next, command,
             ((volatile uint32_t *)(HHDM_BASE + hda_corb_pa))[next],
             (void *)hda_corb_pa);

    hda_write16(HDA_CORBWP, next);
    __asm__ volatile("mfence" ::: "memory");
    uint16_t wp_readback = hda_read16(HDA_CORBWP);
    hda_corb_wp = next;

    if (ring_debug_count <= 3) {
        DbgPrint("hda: CORBWP write=%u readback=%u CORBRP=%u\n",
                 next, wp_readback, hda_read16(HDA_CORBRP));
    }

    int corb_consumed = 0;

    for (uint32_t i = 0; i < 5000000; i++) {
        uint16_t rp = hda_read16(HDA_CORBRP) & (ccount - 1);
        if (rp == next) {
            corb_consumed = 1;
            break;
        }
        __asm__ volatile("pause");
    }

    if (!corb_consumed) {
        DbgPrint("hda: CORB stalled target=%u CORBWP=%04x CORBRP=%04x "
                 "CORBCTL=%02x CORBSTS=%02x RIRBCTL=%02x RIRBSTS=%02x\n",
                 next, hda_read16(HDA_CORBWP), hda_read16(HDA_CORBRP),
                 hda_read8(HDA_CORBCTL), hda_read8(0x4D),
                 hda_read8(HDA_RIRBCTL), hda_read8(0x5D));
        DbgPrint("hda: stalled-ring detail RIRBWP=%04x RIRBRP_SW=%u "
                 "GCTL=%08x STATESTS=%04x\n",
                 hda_read16(HDA_RIRBWP), hda_rirb_last,
                 hda_read32(HDA_REG_GCTL),
                 hda_read16(HDA_REG_STATESTS));
        return -1;
    }

    for (uint32_t i = 0; i < 5000000; i++) {
        uint16_t wp = hda_read16(HDA_RIRBWP) & (rcount - 1);

        if (wp != hda_rirb_last) {
            uint64_t response =
                ((volatile uint64_t *)(HHDM_BASE + hda_rirb_pa))[wp];
            hda_rirb_last = wp;

            /* Acknowledge response interrupt and reset QEMU's count. */
            hda_write8(0x5D, 0x01);

            DbgPrint("hda: verb cad=%u nid=%u verb=%03x param=%02x "
                     "rirb=%u response=%08x ext=%08x\n",
                     cad, nid, verb, payload, wp,
                     (uint32_t)response, (uint32_t)(response >> 32));

            if (((response >> 32) & 0x0F) != cad)
                continue;

            if (result)
                *result = (uint32_t)response;

            /* Clear write-one-to-clear status flags. */
            hda_write8(0x4D, 0x01); /* CORBSTS: CMEI */
            return 0;
        }

        __asm__ volatile("pause");
    }

    DbgPrint("hda: verb timeout cad=%u nid=%u verb=%03x param=%02x "
             "CORBWP=%04x CORBRP=%04x RIRBWP=%04x last=%u\n",
             cad, nid, verb, payload,
             hda_read16(HDA_CORBWP), hda_read16(HDA_CORBRP),
             hda_read16(HDA_RIRBWP), hda_rirb_last);
    return -1;
}

static int hda_codec_probe(void) {
    if (!hda_regs)
        return -1;

    uint32_t gcap = hda_read32(HDA_REG_GCAP);
    if (!(gcap & 1)) {
        DbgPrint("hda: controller lacks 64-bit DMA capability\n");
        return -1;
    }

    /* Allocate separate page-aligned, contiguous physical ring pages. */
    hda_corb_pa = pmm_alloc_n(1);
    hda_rirb_pa = pmm_alloc_n(1);
    if (!hda_corb_pa || !hda_rirb_pa) {
        DbgPrint("hda: unable to allocate DMA ring pages\n");
        if (hda_corb_pa) pmm_free(hda_corb_pa);
        if (hda_rirb_pa) pmm_free(hda_rirb_pa);
        hda_corb_pa = hda_rirb_pa = 0;
        return -1;
    }

    /* CPU accesses buffers through the higher-half direct map;
       the controller still receives the physical addresses below. */
    volatile uint8_t *corb =
        (volatile uint8_t *)(HHDM_BASE + hda_corb_pa);
    volatile uint8_t *rirb =
        (volatile uint8_t *)(HHDM_BASE + hda_rirb_pa);
    for (uint32_t i = 0; i < HDA_RING_BYTES; i++) {
        corb[i] = 0;
        rirb[i] = 0;
    }

    /* Stop DMA engines before reprogramming their ring registers. */
    hda_write8(HDA_CORBCTL, 0);
    hda_write8(HDA_RIRBCTL, 0);

    if (((hda_read8(HDA_CORBCTL) & 1) != 0) ||
        ((hda_read8(HDA_RIRBCTL) & 1) != 0)) {
        DbgPrint("hda: ring engines did not stop\n");
        return -1;
    }

    /* Select 256-entry rings when supported, otherwise 16 or 2. */
    uint16_t cs = hda_read8(HDA_CORBSIZE);
    uint16_t rs = hda_read8(HDA_RIRBSIZE);
    uint16_t csel = (cs & 0x40) ? 2 : ((cs & 0x20) ? 1 : 0);
    uint16_t rsel = (rs & 0x40) ? 2 : ((rs & 0x20) ? 1 : 0);
    hda_write8(HDA_CORBSIZE, (uint8_t)((cs & 0xF8) | csel));
    hda_write8(HDA_RIRBSIZE, (uint8_t)((rs & 0xF8) | rsel));

    uint16_t csz = hda_read8(HDA_CORBSIZE) & 3;
    uint16_t rsz = hda_read8(HDA_RIRBSIZE) & 3;
    uint16_t ccount = csz == 2 ? 256 : (csz == 1 ? 16 : 2);
    uint16_t rcount = rsz == 2 ? 256 : (rsz == 1 ? 16 : 2);

    hda_write32(HDA_CORB_LO, (uint32_t)hda_corb_pa);
    hda_write32(HDA_CORB_HI, (uint32_t)(hda_corb_pa >> 32));
    hda_write32(HDA_RIRB_LO, (uint32_t)hda_rirb_pa);
    hda_write32(HDA_RIRB_HI, (uint32_t)(hda_rirb_pa >> 32));
    DbgPrint("hda: CORB PA=%p base=%08x:%08x size=%02x\n",
             (void *)hda_corb_pa,
             hda_read32(HDA_CORB_HI), hda_read32(HDA_CORB_LO),
             hda_read8(HDA_CORBSIZE));
    DbgPrint("hda: RIRB PA=%p base=%08x:%08x size=%02x\n",
             (void *)hda_rirb_pa,
             hda_read32(HDA_RIRB_HI), hda_read32(HDA_RIRB_LO),
             hda_read8(HDA_RIRBSIZE));

    /* Reset CORB read pointer; reset RIRB write pointer. */
    hda_write16(HDA_CORBRP, 0x8000);
    if (hda_wait16(HDA_CORBRP, 0x8000, 0x8000)) {
        DbgPrint("hda: CORB read-pointer reset timed out\n");
        return -1;
    }
    hda_write16(HDA_CORBRP, 0);
    hda_write16(HDA_CORBWP, 0);

    /* Reset is complete when the self-clearing bit returns to zero. */
    hda_write16(HDA_RIRBWP, 0x8000);
    if (hda_wait16(HDA_RIRBWP, 0x8000, 0)) {
        DbgPrint("hda: RIRB write-pointer reset did not clear\n");
        return -1;
    }
    hda_write16(HDA_RIRBWP, 0);
    hda_write16(HDA_RINTCNT, 1);

    hda_corb_wp = 0;
    hda_rirb_last = 0;

    /* Enable response DMA, then command DMA. Interrupts remain disabled. */
    hda_write8(HDA_RIRBCTL, 0x03);
    hda_write8(HDA_CORBCTL, 0x02);

    if (((hda_read8(HDA_CORBCTL) & 0x02) == 0) ||
        ((hda_read8(HDA_RIRBCTL) & 0x02) == 0)) {
        DbgPrint("hda: ring DMA failed to start\n");
        hda_write8(HDA_CORBCTL, 0);
        hda_write8(HDA_RIRBCTL, 0);
        return -1;
    }

    DbgPrint("hda: CORB/RIRB started (%u/%u entries)\n",
             ccount, rcount);

    uint32_t value = 0;

    if (hda_codec_verb(0, 0, 0xF00, 0x00, &value)) {
        DbgPrint("hda: vendor ID query timed out\n");
        return -1;
    }

    DbgPrint("hda: codec 0 vendor/device ID = %08x\n", value);

    DbgPrint("hda: post-verb status CORBSTS=%02x RIRBSTS=%02x "
             "CORBCTL=%02x RIRBCTL=%02x CORBRP=%04x RIRBWP=%04x\n",
             hda_read8(0x4D), hda_read8(0x5D),
             hda_read8(HDA_CORBCTL), hda_read8(HDA_RIRBCTL),
             hda_read16(HDA_CORBRP), hda_read16(HDA_RIRBWP));

    if (hda_codec_verb(0, 0, 0xF00, 0x04, &value)) {
        DbgPrint("hda: root-node function-group query failed\n");
        return -1;
    }

    uint8_t fg_start = (uint8_t)(value >> 16);
    uint8_t fg_count = (uint8_t)(value & 0xFF);

    DbgPrint("hda: function groups start=%u count=%u\n",
             fg_start, fg_count);

    for (uint16_t i = 0; i < fg_count; i++) {
        uint8_t fg = (uint8_t)(fg_start + i);
        uint32_t type = 0;
        uint32_t nodes = 0;

        if (hda_codec_verb(0, fg, 0xF00, 0x05, &type)) {
            DbgPrint("hda: function group %u type query failed\n", fg);
            continue;
        }

        if ((type & 0xFF) != 0x01) {
            DbgPrint("hda: function group %u type=%08x (not audio)\n",
                     fg, type);
            continue;
        }

        if (hda_codec_verb(0, fg, 0xF00, 0x04, &nodes)) {
            DbgPrint("hda: function group %u node query failed\n", fg);
            continue;
        }

        uint8_t first = (uint8_t)(nodes >> 16);
        uint8_t count = (uint8_t)(nodes & 0xFF);

        DbgPrint("hda: function group %u widgets start=%u count=%u\\n",
                 fg, first, count);

        for (uint16_t j = 0; j < count; j++) {
            uint8_t nid = (uint8_t)(first + j);
            uint32_t caps = 0;
            uint32_t name = 0;

            if (hda_codec_verb(0, nid, 0xF00, 0x09, &caps)) {
                DbgPrint("hda: widget nid=%u capabilities query failed\\n", nid);
                continue;
            }

            /*
             * Connection List Length is a dedicated GET verb (0xF02),
             * not GET_PARAMETER (0xF00, parameter 0x04).
             */
            if (hda_codec_verb(0, nid, 0xF02, 0x00, &name)) {
                DbgPrint("hda: widget nid=%u connection-list query failed\\n",
                         nid);
                continue;
            }

            DbgPrint("hda: widget nid=%u caps=%08x conn_length=%08x\\n",
                     nid, caps, name);

            /*
             * GET_CONNECTION_LIST_ENTRY (0xF03):
             * query each entry only when the reported length is nonzero.
             */
            uint32_t conn_length = name & 0x7F;
            if (conn_length > 16)
                conn_length = 16;

            for (uint32_t ci = 0; ci < conn_length; ci++) {
                uint32_t entry = 0;
                if (hda_codec_verb(0, nid, 0xF03,
                                   (uint8_t)ci, &entry)) {
                    DbgPrint("hda: nid=%u connection entry %u failed\\n",
                             nid, ci);
                    break;
                }

                DbgPrint("hda: nid=%u connection[%u]=%08x\\n",
                         nid, ci, entry);
            }
        }
    }

    return 0;
}

static int hda_init(void) {
    hda_detected = 0;
    hda_bar0 = 0;
    hda_regs = 0;

    DbgPrint("hda: scanning PCI for HD Audio controllers\n");

    for (uint16_t bus = 0; bus < 256; bus++) {
        for (uint8_t slot = 0; slot < 32; slot++) {
            uint32_t id = pci_cfg_read((uint8_t)bus, slot, 0, 0);
            if ((id & 0xFFFF) == 0xFFFF)
                continue;

            uint8_t header = pci_cfg_read8((uint8_t)bus, slot, 0, 0x0E);
            uint8_t funcs = (header & 0x80) ? 8 : 1;

            for (uint8_t func = 0; func < funcs; func++) {
                id = pci_cfg_read((uint8_t)bus, slot, func, 0);
                if ((id & 0xFFFF) == 0xFFFF)
                    continue;

                uint32_t classreg =
                    pci_cfg_read((uint8_t)bus, slot, func, 0x08);
                uint8_t class_code = (uint8_t)(classreg >> 24);
                uint8_t subclass = (uint8_t)(classreg >> 16);

                if (class_code != 0x04 || subclass != 0x03)
                    continue;

                uint32_t barlo =
                    pci_cfg_read((uint8_t)bus, slot, func, 0x10);
                if ((barlo & 1) || !barlo)
                    continue;

                uint64_t bar = barlo & ~0xFULL;
                if ((barlo & 0x6) == 0x4) {
                    uint32_t barhi =
                        pci_cfg_read((uint8_t)bus, slot, func, 0x14);
                    bar |= (uint64_t)barhi << 32;
                }
                if (!bar)
                    continue;

                uint16_t vendor = (uint16_t)id;
                uint16_t device = (uint16_t)(id >> 16);

                hda_bus = (uint8_t)bus;
                hda_slot = slot;
                hda_func = func;
                hda_bar0 = bar;
                hda_detected = 1;

                DbgPrint(
                    "hda: found %04x:%04x at %02x:%02x.%u BAR0=%p\n",
                    vendor, device, bus, slot, func, (void *)bar);

                /* Enable PCI memory-space and bus mastering.
                   Write zero to the status half to avoid clearing W1C flags. */
                uint32_t cmd =
                    pci_cfg_read((uint8_t)bus, slot, func, 0x04) & 0xFFFF;
                pci_cfg_write((uint8_t)bus, slot, func, 0x04,
                              (cmd | 0x0006) & 0xFFFF);

                hda_regs = (volatile uint8_t *)
                    vb_map_bar(bar, 0x4000);
                goto controller_found;
            }
        }
    }

    DbgPrint("hda: no usable HD Audio controller found\n");
    return -1;

controller_found:
    DbgPrint("hda: MMIO mapped at %p\n", (void *)hda_regs);

    /* Reset the controller: CRST must transition low, then high. */
    uint32_t gctl = hda_read32(HDA_REG_GCTL);
    hda_write32(HDA_REG_GCTL, gctl & ~HDA_REG_GCTL_CRST);

    if (hda_wait_bit(HDA_REG_GCTL, HDA_REG_GCTL_CRST, 0)) {
        DbgPrint("hda: timeout waiting for controller reset\n");
        return -1;
    }

    /* Give the reset transition a short settling period. */
    for (volatile uint32_t i = 0; i < 10000; i++)
        __asm__ volatile("pause");

    hda_write32(HDA_REG_GCTL,
                hda_read32(HDA_REG_GCTL) | HDA_REG_GCTL_CRST);

    if (hda_wait_bit(HDA_REG_GCTL, HDA_REG_GCTL_CRST, 1)) {
        DbgPrint("hda: controller failed to leave reset\n");
        return -1;
    }

    for (volatile uint32_t i = 0; i < 10000; i++)
        __asm__ volatile("pause");

    uint32_t gcap = hda_read32(HDA_REG_GCAP);
    uint16_t statests = hda_read16(HDA_REG_STATESTS);

    DbgPrint("hda: controller reset complete, GCAP=%08x STATESTS=%04x\n",
             gcap, statests);

    if (!statests) {
        DbgPrint("hda: no codec detected in STATESTS\n");
        return -1;
    }

    for (unsigned i = 0; i < 15; i++) {
        if (statests & (1u << i))
            DbgPrint("hda: codec present at address %u\n", i);
    }

    DbgPrint("hda: controller initialization milestone passed\n");
    return hda_codec_probe();
}
